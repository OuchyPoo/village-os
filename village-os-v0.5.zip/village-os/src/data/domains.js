// Life domains mapped onto buildings. This is the seam where Village OS will connect to real data:
// each domain will later pull projects and tasks from Claude / connected tools.
// Edit freely: ids are referenced by buildings in src/world/layout.js.
export const DOMAINS = {
  home: {
    title: 'Home',
    kind: 'Your cottage',
    blurb: 'Household, relationships and everyday life.',
    sections: [
      { label: 'Projects', items: ['Home purchase before the lease renewal'] },
      { label: 'Next up', items: ['Nothing scheduled yet'] },
    ],
  },
  work: {
    title: 'Work',
    kind: 'The workshop on the square',
    blurb: 'Coles Relay refit program: sites, overnight refits and travel.',
    sections: [
      { label: 'Projects', items: ['Coles Relay'] },
      { label: 'Next up', items: ['Connect your calendar to see upcoming refits'] },
    ],
  },
  stay: {
    title: 'Sleepover by the Yarra',
    kind: 'Riverside guesthouse',
    blurb: 'Short stay hosting: guests, cleans, pricing and reviews.',
    sections: [
      { label: 'Projects', items: ['Guest messaging', 'Cleaning schedule', 'Pricing'] },
      { label: 'Next up', items: ['Link the booking calendar to show arrivals here'] },
    ],
  },
  money: {
    title: 'Finances',
    kind: 'Town hall',
    blurb: 'Budget, savings, mortgage and investments.',
    sections: [
      { label: 'Projects', items: ['Deposit and offset planning'] },
      { label: 'Next up', items: ['Nothing scheduled yet'] },
    ],
  },
  taxes: {
    title: 'Taxes',
    kind: 'Records office',
    blurb: 'Returns, receipts and deductions.',
    sections: [
      { label: 'Projects', items: ['2025/26 return'] },
      { label: 'Next up', items: ['Lodgement deadline 31 October'] },
    ],
  },
  health: {
    title: 'Health',
    kind: 'Apothecary garden',
    blurb: 'Energy, food and wellbeing.',
    sections: [
      { label: 'Projects', items: ['Nothing tracked yet'] },
      { label: 'Next up', items: ['Nothing scheduled yet'] },
    ],
  },
  ideas: {
    title: 'Village OS',
    kind: 'Forest workshop',
    blurb: 'Where the village itself gets built. New ideas start here.',
    sections: [
      { label: 'Projects', items: ['Village OS world build'] },
      { label: 'Next up', items: ['Wire buildings to live data'] },
    ],
  },
};

export const EMPTY_PLOT = {
  title: 'Empty cottage',
  kind: 'Unclaimed',
  blurb: 'Ready for a new life domain, project or person.',
  sections: [],
};
