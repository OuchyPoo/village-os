// Post-processing: N8AO ambient occlusion for the soft "clay" contact shading, SMAA,
// a gentle tilt-shift for the miniature look of the reference, then tone mapping.
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { SMAAPass } from 'three/addons/postprocessing/SMAAPass.js';
import { N8AOPass } from 'n8ao';

export function createPostFX(renderer, scene, camera, quality) {
  const composer = new EffectComposer(renderer);
  let ao = null;
  if (quality !== 'low') {
    ao = new N8AOPass(scene, camera, innerWidth, innerHeight);
    ao.configuration.aoRadius = 2.2;
    ao.configuration.distanceFalloff = 1.0;
    ao.configuration.intensity = 2.8;
    ao.configuration.halfRes = true;
    ao.configuration.depthAwareUpsampling = true;
    ao.configuration.gammaCorrection = false;
    ao.setQualityMode('Medium');
    composer.addPass(ao);
  } else {
    composer.addPass(new RenderPass(scene, camera));
  }
  // Tilt-shift with a wide, perfectly sharp focus band: only the top and bottom edges of the frame
  // soften, and only slightly, so the miniature feel stays without blurring the village.
  const tiltShader = (dir) => ({
    uniforms: { tDiffuse: { value: null }, px: { value: 1 / 1000 }, centre: { value: 0.5 }, band: { value: 0.32 }, amount: { value: 0.6 } },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
    fragmentShader: `uniform sampler2D tDiffuse; uniform float px, centre, band, amount; varying vec2 vUv;
      void main(){
        float k = max(0.0, abs(vUv.y - centre) - band) / (0.5 - band);
        float d = px * amount * k * k * 4.0;
        vec2 o = ${dir === 'h' ? 'vec2(d, 0.0)' : 'vec2(0.0, d)'};
        vec4 c = texture2D(tDiffuse, vUv) * 0.2270270270;
        c += (texture2D(tDiffuse, vUv + o * 1.3846153846) + texture2D(tDiffuse, vUv - o * 1.3846153846)) * 0.3162162162;
        c += (texture2D(tDiffuse, vUv + o * 3.2307692308) + texture2D(tDiffuse, vUv - o * 3.2307692308)) * 0.0702702703;
        gl_FragColor = c;
      }`,
  });
  const hts = new ShaderPass(tiltShader('h'));
  const vts = new ShaderPass(tiltShader('v'));
  const setTS = () => {
    hts.uniforms.px.value = 1 / innerWidth;
    vts.uniforms.px.value = 1 / innerHeight;
  };
  setTS();
  composer.addPass(hts);
  composer.addPass(vts);
  composer.addPass(new OutputPass());
  // pastel grade (display space): soften saturation, lift shadows towards lavender, warm the highlights
  const grade = new ShaderPass({
    uniforms: { tDiffuse: { value: null }, sat: { value: 1.0 } },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
    fragmentShader: `uniform sampler2D tDiffuse; uniform float sat; varying vec2 vUv;
      void main(){
        vec3 c = texture2D(tDiffuse, vUv).rgb;
        float l = dot(c, vec3(0.299, 0.587, 0.114));
        c = mix(vec3(l), c, sat);
        c = c * 0.97 + vec3(0.022, 0.02, 0.036) * (1.0 - l);
        c += vec3(0.02, 0.012, 0.0) * smoothstep(0.55, 1.0, l);
        gl_FragColor = vec4(c, 1.0);
      }`,
  });
  composer.addPass(grade);
  let smaa = null;
  if (quality !== 'low') { smaa = new SMAAPass(innerWidth * renderer.getPixelRatio(), innerHeight * renderer.getPixelRatio()); composer.addPass(smaa); }
  return {
    composer,
    ao,
    resize(w, h) { composer.setSize(w, h); ao && ao.setSize(w, h); setTS(); },
    render(dt) { composer.render(dt); },
  };
}
