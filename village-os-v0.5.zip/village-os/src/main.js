// Village OS bootstrap: renderer, lighting, asset loading, world build, player, game loop.
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { buildWorld } from './world/index.js';
import { Collision } from './systems/collision.js';
import { Input } from './systems/input.js';
import { Interactions } from './systems/interactions.js';
import { Character } from './player/character.js';
import { PlayerController } from './player/controller.js';
import { FollowCamera } from './player/camera.js';
import { HUD } from './ui/hud.js';
import { createPostFX } from './core/postfx.js';
import { PACK_MODELS } from './world/packs.js';
import { setEnvironment } from './world/materials.js';

const params = new URLSearchParams(location.search);
const QUALITY = params.get('quality') || 'high';

const canvas = document.getElementById('scene');
const loadingEl = document.getElementById('loading');
const statusEl = loadingEl.querySelector('.status');
const fillEl = loadingEl.querySelector('.fill');

const renderer = new THREE.WebGLRenderer({ canvas, antialias: QUALITY === 'low', powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, QUALITY === 'low' ? 1 : 1.5));
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
scene.fog = new THREE.Fog('#dde3ee', 230, 1800);
const camera = new THREE.PerspectiveCamera(42, innerWidth / innerHeight, 0.2, 3500);

// warm late-morning sun from behind-right of the default view, soft sky fill
const sunDir = new THREE.Vector3(0.55, 0.78, -0.42).normalize();
const hemi = new THREE.HemisphereLight('#eaf0ff', '#bfcd9f', 1.3);
scene.add(hemi);
const sun = new THREE.DirectionalLight('#ffeed8', 2.75);
sun.castShadow = true;
sun.shadow.mapSize.set(QUALITY === 'low' ? 1024 : 4096, QUALITY === 'low' ? 1024 : 4096);
const SH = 55;
Object.assign(sun.shadow.camera, { left: -SH, right: SH, top: SH, bottom: -SH, near: 1, far: 260 });
sun.shadow.bias = -0.0003;
sun.shadow.normalBias = 0.035;
sun.shadow.radius = 3;
scene.add(sun, sun.target);

async function loadAssets() {
  const loader = new GLTFLoader();
  const base = import.meta.env.BASE_URL + 'assets/models/';
  const files = { character: 'character.glb', grass: 'grass.glb', grassSmall: 'grass-small.glb', pine: 'pine.glb', fountain: 'fountain.glb' };
  for (const p of PACK_MODELS) files['pack:' + p] = 'packs/' + p + '.glb';
  const out = { packs: {} };
  let done = 0;
  const n = Object.keys(files).length;
  // Hosts that can't serve .glb files may embed them as base64 in window.VOS_MODEL_DATA.
  const embedded = window.VOS_MODEL_DATA;
  const fromBase64 = (b64) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0)).buffer;
  await Promise.all(Object.entries(files).map(async ([k, f]) => {
    const g = embedded?.[f] ? await loader.parseAsync(fromBase64(embedded[f]), '') : await loader.loadAsync(base + f);
    if (k.startsWith('pack:')) out.packs[k.slice(5)] = g; else out[k] = g;
    done++;
    fillEl.style.width = `${(done / n) * 60}%`;
  }));
  return out;
}

const frame = () => new Promise((r) => requestAnimationFrame(() => r()));

async function start() {
  const assets = await loadAssets();
  statusEl.textContent = 'Shaping the valley…';
  await frame();
  const t0 = performance.now();
  const world = buildWorld(assets, sunDir);
  scene.add(world.root);
  fillEl.style.width = '90%';
  console.info('[village] built in', Math.round(performance.now() - t0), 'ms', world.stats);

  // a soft sky environment for glass reflections
  {
    const pm = new THREE.PMREMGenerator(renderer);
    const envScene = new THREE.Scene();
    envScene.add(world.sky.clone());
    const ground = new THREE.Mesh(new THREE.CircleGeometry(3000, 16).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: '#b9c9a2' }));
    ground.position.y = -5;
    envScene.add(ground);
    setEnvironment(pm.fromScene(envScene, 0.02, 1, 5000).texture);
    pm.dispose();
  }

  const collision = new Collision(world);
  const input = new Input(canvas);
  const hud = new HUD();
  const character = new Character(assets.character);
  scene.add(character.root, character.blob);
  const player = new PlayerController(character, collision, input);
  const home = world.houses.find((h) => h.domain === 'home');
  const [sx, sz] = home.toWorld(home.doorLocal[0] - 1.5, home.doorLocal[1] + 6);
  player.teleport(sx, sz, home.rot + Math.PI);
  const follow = new FollowCamera(camera, collision, input);
  follow.yaw = home.rot + 0.9;
  follow.pitch = 0.66;
  follow.dist = follow.targetDist = follow.curDist = 20;
  const interactions = new Interactions({ world, player, hud, camera, input, scene });
  const fx = createPostFX(renderer, scene, camera, QUALITY);

  // river shader fog follows scene fog
  const riverMesh = world.root.getObjectByName('river');
  if (riverMesh) {
    riverMesh.material.uniforms.fogColor.value.copy(scene.fog.color);
    riverMesh.material.uniforms.fogNear.value = scene.fog.near;
    riverMesh.material.uniforms.fogFar.value = scene.fog.far;
  }

  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
    fx.resize(innerWidth, innerHeight);
  });

  // Distance culling for small ground clutter (ferns, flowers, mushrooms, pebbles...): whole instanced
  // tiles beyond ~110 m are skipped; at that range they are only a few pixels and sit in the haze.
  const clutter = [];
  world.root.traverse((o) => {
    if (!o.isInstancedMesh || !o.geometry) return;
    for (let p = o.parent; p; p = p.parent) if (p.name === 'trees' || p.name === 'pines' || p.name === 'farPines') return;
    if (!o.geometry.boundingSphere) o.geometry.computeBoundingSphere();
    if (o.geometry.boundingSphere.radius > 1.5) return;
    if (!o.boundingSphere) o.computeBoundingSphere();
    o.updateWorldMatrix(true, false);
    // low swaying plants rely on AO for contact shading rather than casting shadow-map shadows
    if (o.geometry.boundingSphere.radius < 0.8 && o.material && o.material.onBeforeCompile && o.material.onBeforeCompile.toString().length > 40) o.castShadow = false;
    clutter.push({ o, c: o.boundingSphere.center.clone().applyMatrix4(o.matrixWorld), r: o.boundingSphere.radius });
  });
  const CLUTTER_DIST = QUALITY === 'low' ? 80 : 110;
  const cullClutter = () => {
    const p = camera.position;
    for (const k of clutter) k.o.visible = k.c.distanceTo(p) - k.r < CLUTTER_DIST;
  };

  const clock = new THREE.Clock();
  let time = 0;
  const MANUAL = params.has('manual'); // automation: advance frames explicitly via VOS.step()
  const tick = (dt) => {
    time += dt;
    player.locked = hud.panelOpen;
    player.update(dt, follow.yaw);
    follow.update(dt, player.pos, hud.panelOpen);
    interactions.update(dt, time);
    world.update(time, dt);
    // shadow frustum follows the player, snapped to texels to avoid shimmering
    const texel = (SH * 2) / sun.shadow.mapSize.x;
    const fx0 = Math.round(player.pos.x / texel) * texel, fz0 = Math.round(player.pos.z / texel) * texel;
    sun.target.position.set(fx0, player.pos.y, fz0);
    sun.position.copy(sun.target.position).addScaledVector(sunDir, 140);
    world.sky.position.copy(camera.position);
    cullClutter();
    input.endFrame();
  };
  const loop = () => {
    tick(Math.min(clock.getDelta(), 1 / 20));
    fx.render();
    requestAnimationFrame(loop);
  };

  // warm-up render so shaders compile behind the loading screen
  statusEl.textContent = 'Lighting the lamps…';
  await frame();
  renderer.compile(scene, camera);
  fillEl.style.width = '100%';
  if (!MANUAL) loop();
  loadingEl.classList.add('done');
  if (MANUAL) loadingEl.style.display = 'none';
  setTimeout(() => (loadingEl.style.display = 'none'), 800);
  canvas.focus();

  // small debug / automation surface
  window.VOS = {
    THREE, scene, camera, renderer, world, player, follow, input, hud, interactions, collision, fx,
    // free camera for inspection shots: freeCam([x,y,z],[tx,ty,tz]) renders once from there
    freeCam(p, t) { camera.position.set(...p); camera.lookAt(...t); cullClutter(); world.sky.position.copy(camera.position); fx.render(); },
    step(n = 1, dt = 1 / 60, render = true) { for (let i = 0; i < n; i++) tick(dt); if (render) fx.render(); },
  };
  if (MANUAL) VOS.step(1);
  window.DONE = true;
}

start().catch((e) => {
  console.error(e);
  statusEl.textContent = 'Something went wrong building the village. Check the console for details.';
});
