// Shared building palette and surface materials: a pastel European village.
// Warm creams, butter, peach, powder blue, mint and lavender plaster; muted terracotta, dusty rose
// and slate roofs; white trim. Surfaces get soft, low-contrast canvas textures (plaster mottling,
// timber grain, irregular stone, varied roof tiles) mapped with world-space box UVs by the Batcher.
import * as THREE from 'three';
import { mulberry32 } from '../core/math.js';
import { RUBBLE, PLASTER } from './textures-data.js';

const HAS_DOM = typeof document !== 'undefined';

function canvasTex(w, h, draw, { repeat = true } = {}) {
  if (!HAS_DOM) return null;
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const g = c.getContext('2d');
  draw(g, w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  return t;
}

// Soft lime-plaster mottling: mostly white with gentle warm and cool blooms.
const plasterTex = canvasTex(256, 256, (g, w, h) => {
  const r = mulberry32(41);
  g.fillStyle = '#ffffff'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 260; i++) {
    const x = r() * w, y = r() * h, rad = 6 + r() * 34;
    const grd = g.createRadialGradient(x, y, 0, x, y, rad);
    const a = 0.025 + r() * 0.035;
    grd.addColorStop(0, r() < 0.4 ? `rgba(190,170,150,${a * 0.8})` : `rgba(255,252,246,${a * 1.6})`);
    grd.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = grd;
    for (const ox of [-w, 0, w]) for (const oy of [-h, 0, h]) { g.beginPath(); g.arc(x + ox, y + oy, rad, 0, 6.29); g.fill(); }
  }
  for (let i = 0; i < 900; i++) { g.fillStyle = `rgba(160,140,120,${0.015 + r() * 0.02})`; g.fillRect(r() * w, r() * h, 1, 1); }
});

// Timber grain: long soft streaks with a few knots.
const timberTex = canvasTex(128, 512, (g, w, h) => {
  const r = mulberry32(17);
  g.fillStyle = '#ffffff'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 70; i++) {
    const x = r() * w, a = 0.04 + r() * 0.08;
    g.strokeStyle = `rgba(110,75,50,${a})`;
    g.lineWidth = 0.6 + r() * 1.8;
    g.beginPath();
    g.moveTo(x, 0);
    for (let y = 0; y <= h; y += 16) g.lineTo(x + Math.sin(y * 0.02 + i) * 2.5, y);
    g.stroke();
  }
  for (let i = 0; i < 4; i++) {
    const x = r() * w, y = r() * h;
    g.strokeStyle = 'rgba(100,65,45,0.18)';
    g.beginPath(); g.ellipse(x, y, 3, 8, 0, 0, 6.29); g.stroke();
  }
});

// Irregular rubble stone with mortar joints and colour variation.
const stoneTex = canvasTex(256, 256, (g, w, h) => {
  const r = mulberry32(23);
  g.fillStyle = '#c9c1b5'; g.fillRect(0, 0, w, h);
  let y = 0;
  while (y < h) {
    const rh = 22 + r() * 26;
    let x = -r() * 30;
    while (x < w) {
      const sw = 26 + r() * 46;
      const l = 0.9 + r() * 0.16;
      const tint = r();
      g.fillStyle = `rgb(${Math.round(240 * l - tint * 12)},${Math.round(236 * l - tint * 6)},${Math.round(228 * l)})`;
      g.beginPath();
      g.roundRect(x + 2, y + 2, sw - 4, rh - 4, 7 + r() * 6);
      g.fill();
      if (x + sw > w) { g.beginPath(); g.roundRect(x + 2 - w, y + 2, sw - 4, rh - 4, 8); g.fill(); }
      x += sw;
    }
    y += rh;
  }
});

// Clay roof tiles: two rows per texture, staggered, each tile with its own tone.
const roofTex = canvasTex(256, 256, (g, w, h) => {
  const r = mulberry32(31);
  g.fillStyle = '#b9a79c'; g.fillRect(0, 0, w, h);
  const rows = 4, cols = 4, th = h / rows, tw = w / cols;
  for (let j = 0; j < rows; j++) for (let i = -1; i <= cols; i++) {
    const x = i * tw + (j % 2) * tw / 2, y = j * th;
    const l = 0.86 + r() * 0.16, warm = r() * 10;
    const grd = g.createLinearGradient(0, y, 0, y + th);
    grd.addColorStop(0, `rgb(${Math.round(255 * l)},${Math.round(246 * l - warm)},${Math.round(240 * l - warm)})`);
    grd.addColorStop(0.8, `rgb(${Math.round(242 * l)},${Math.round(230 * l - warm)},${Math.round(222 * l - warm)})`);
    grd.addColorStop(1, `rgb(${Math.round(200 * l)},${Math.round(184 * l)},${Math.round(176 * l)})`);
    g.fillStyle = grd;
    g.beginPath();
    g.roundRect(x + 1.5, y + 1, tw - 3, th - 2, [2, 2, 10, 10]);
    g.fill();
  }
});

// Hand-painted CC0 textures (Quaternius Medieval Village MegaKit), graded to light multiply maps.
// ?tex=canvas falls back to the procedural canvas textures for comparison.
const USE_PAINTED = HAS_DOM && new URLSearchParams(location.search).get('tex') !== 'canvas';
function imageTex(uri) {
  const t = new THREE.TextureLoader().load(uri);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  return t;
}
const rubbleTex = USE_PAINTED ? imageTex(RUBBLE) : stoneTex;
const plasterPaint = USE_PAINTED ? imageTex(PLASTER) : plasterTex;

const std = (color, o = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.88, metalness: 0, ...o });
// boxUV: metres per texture repeat (world-space box projection in the Batcher)
const tex = (m, map, metres) => { if (map) { m.map = map; m.userData.boxUV = metres; } return m; };

export const PALETTE = {
  wall: {
    cream: '#f6ead2', white: '#f7f2e8', yellow: '#f4e2a8', butter: '#f3e3ae', pink: '#f1d0cb', peach: '#f5d3b8',
    powder: '#d3e2ef', mint: '#d4eadb', lavender: '#e0d6ee',
  },
  roof: { orange: '#e39a6e', terracotta: '#d0866a', rose: '#d99c98', slate: '#8f9db1' },
  shutter: { green: '#97b89a', blue: '#93b4d2', lavender: '#b6a6d6', pink: '#e2a9b2' },
  door: { green: '#8fb59a', blue: '#7fa2c4', lavender: '#a594c9', terracotta: '#c98463', wood: '#b0835e', cream: '#efe1c5' },
};

// Environment map for glass reflections (set from main.js once the renderer exists).
export const ENV = { map: null };

export const MAT = {
  trim: std('#fcf9f2', { roughness: 0.8 }),
  stone: tex(std('#ddd5c9', { roughness: 0.95 }), rubbleTex, USE_PAINTED ? 2.6 : 2.2),
  stoneDark: tex(std('#bdb3a6', { roughness: 0.95 }), rubbleTex, USE_PAINTED ? 2.6 : 2.2),
  stoneTrim: tex(std('#e9e2d6', { roughness: 0.9 }), stoneTex, 3.5),
  wood: tex(std('#c79b72'), timberTex, 1.2),
  woodDark: tex(std('#9c785c'), timberTex, 1.2),
  timber: tex(std('#a98266'), timberTex, 1.0),
  door: tex(std('#b0835e'), timberTex, 1.0),
  glass: new THREE.MeshPhysicalMaterial({ color: '#6f8799', roughness: 0.06, metalness: 0.0, transparent: true, opacity: 0.55, reflectivity: 0.6, envMapIntensity: 1.0, depthWrite: false }),
  interior: std('#4b5560', { roughness: 1 }),
  curtain: std('#f4ece0', { roughness: 1 }),
  frameDark: std('#5c6370'),
  chimneyCap: tex(std('#b4a79b'), stoneTex, 1.5),
  pot: std('#d48e6c'),
  gutter: std('#8e8f93', { roughness: 0.55, metalness: 0.2 }),
  lamp: new THREE.MeshStandardMaterial({ color: '#fff0c8', emissive: '#ffd98a', emissiveIntensity: 1.0, roughness: 0.4 }),
  brass: std('#d6b878', { metalness: 0.6, roughness: 0.35 }),
  iron: std('#6f7480', { metalness: 0.3, roughness: 0.5 }),
  flowerPink: std('#f2b3c3'),
  flowerRed: std('#e59b8f'),
  flowerWhite: std('#fcf8f2'),
  flowerYellow: std('#f4dd8c'),
  flowerLavender: std('#c4b2e4'),
  flowerBlue: std('#a9c4e6'),
  leaf: std('#9cc28c'),
  leafDark: std('#82ab7b'),
  hedge: std('#8db783', { roughness: 0.95 }),
  soil: std('#a58c74', { roughness: 1 }),
  awningA: std('#f6f1e8'),
  clockFace: std('#fbf6ea'),
};
for (const [k, v] of Object.entries(PALETTE.wall)) MAT['wall_' + k] = tex(std(v, { roughness: 0.93 }), plasterPaint, USE_PAINTED ? 3.2 : 2.6);
for (const [k, v] of Object.entries(PALETTE.roof)) MAT['roof_' + k] = std(v, { roughness: 0.82, map: roofTex });
for (const [k, v] of Object.entries(PALETTE.roof)) MAT['ridge_' + k] = std(new THREE.Color(v).multiplyScalar(0.88), { roughness: 0.8 });
for (const [k, v] of Object.entries(PALETTE.shutter)) MAT['shutter_' + k] = tex(std(v), timberTex, 1.0);
for (const [k, v] of Object.entries(PALETTE.door)) MAT['door_' + k] = tex(std(v), timberTex, 1.0);
for (const [k, v] of Object.entries(PALETTE.shutter)) MAT['awning_' + k] = std(v);

export function setEnvironment(envMap) {
  ENV.map = envMap;
  MAT.glass.envMap = envMap;
  MAT.glass.needsUpdate = true;
}
