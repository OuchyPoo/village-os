// Lanes, garden walkways and the bridge crossings. Lanes are smoothed, given a height profile
// over the terrain, and turned into paved / cobbled / trail ribbons with kerbs.
import * as THREE from 'three';
import { SQUARE } from './layout.js';
import { riverQuery, halfWidth, waterLevel } from './river.js';
import { slabTexture, cobbleTexture, trailTexture } from './textures.js';

export function makeLaneCurves(lanes) {
  return lanes.map((l) => {
    const curve = new THREE.CatmullRomCurve3(l.pts.map(([x, z]) => new THREE.Vector3(x, 0, z)), false, 'centripetal', 0.5);
    const n = Math.max(2, Math.round(curve.getLength() / 1.0));
    const curvePts = curve.getSpacedPoints(n).map((p) => [p.x, p.z]);
    return { ...l, curvePts };
  });
}

export function makeWalkways(houses, lanes) {
  const out = [];
  const nearestLane = (x, z) => {
    let best = Infinity, bp = null, bl = null;
    for (const l of lanes) for (const p of l.curvePts) {
      const d = (p[0] - x) ** 2 + (p[1] - z) ** 2;
      if (d < best) { best = d; bp = p; bl = l; }
    }
    return { d: Math.sqrt(best), p: bp, l: bl };
  };
  for (const h of houses) {
    if (!h.door) continue;
    const [dlx, dlz] = h.doorLocal;
    const A = h.toWorld(dlx, dlz + 1.0); // just beyond the doorstep
    const nA = nearestLane(A[0], A[1]);
    if (nA.d > 45) continue;
    // depth of the front garden along the door axis: stop short of the lane
    let depth = 2.6;
    for (let t = 0.5; t <= 2.6; t += 0.1) {
      const [x, z] = h.toWorld(dlx, dlz + t);
      const n = nearestLane(x, z);
      if (n.d < n.l.w / 2 + 0.9) { depth = t - 0.4; break; }
    }
    h.yardDepth = Math.max(0.9, depth);
    const G = h.toWorld(dlx, dlz + h.yardDepth); // gate on the door axis
    const nG = nearestLane(G[0], G[1]);
    // straight down the door axis to the gate, then a smooth curve that leaves the gate square to the
    // fence and meets the lane square to its edge (no doglegs or sharp kinks)
    const last = h.yardDepth > 1.1 ? G : A;
    const curvePts = [];
    const seg = (x0, z0, x1, z1) => { const n = Math.max(1, Math.ceil(Math.hypot(x1 - x0, z1 - z0) / 0.8)); for (let i = 0; i < n; i++) curvePts.push([x0 + (x1 - x0) * (i / n), z0 + (z1 - z0) * (i / n)]); };
    if (last !== A) seg(A[0], A[1], G[0], G[1]);
    const dist = Math.hypot(nG.p[0] - last[0], nG.p[1] - last[1]);
    if (dist > nG.l.w / 2 + 0.3) {
      const ci = nG.l.curvePts.indexOf(nG.p), cp = nG.l.curvePts;
      const a = cp[Math.max(0, ci - 1)], b = cp[Math.min(cp.length - 1, ci + 1)];
      let tx = b[0] - a[0], tz = b[1] - a[1]; const tl = Math.hypot(tx, tz) || 1; tx /= tl; tz /= tl;
      let nx = -tz, nz = tx; // lane normal, pointing towards the house
      if ((last[0] - nG.p[0]) * nx + (last[1] - nG.p[1]) * nz < 0) { nx = -nx; nz = -nz; }
      const E = [nG.p[0] + nx * (nG.l.w / 2 - 0.35), nG.p[1] + nz * (nG.l.w / 2 - 0.35)];
      const [ax, az] = [Math.sin(h.rot), Math.cos(h.rot)]; // door axis (local +z) in world space
      const L = Math.hypot(E[0] - last[0], E[1] - last[1]), k = Math.min(L * 0.45, 3);
      const P1 = [last[0] + ax * k, last[1] + az * k], P2 = [E[0] + nx * k, E[1] + nz * k];
      const n = Math.max(2, Math.ceil(L / 0.6));
      for (let i = 0; i < n; i++) {
        const t = i / n, u = 1 - t;
        curvePts.push([u * u * u * last[0] + 3 * u * u * t * P1[0] + 3 * u * t * t * P2[0] + t * t * t * E[0], u * u * u * last[1] + 3 * u * u * t * P1[1] + 3 * u * t * t * P2[1] + t * t * t * E[1]]);
      }
      curvePts.push(E);
    } else curvePts.push(last);
    if (curvePts.length < 2) continue;
    h.walkLane = nG.l;
    h.gate = h.yardDepth > 1.1 ? { x: G[0], z: G[1] } : null;
    h.walkway = true;
    out.push({ id: 'walk', type: h.clearing || nG.l.type === 'trail' ? 'trail' : 'slab', walk: true, w: 1.5, curvePts, house: h });
  }
  return out;
}

// Height profile along each lane, bridge detection and smoothing.
export function profileLanes(hf, lanes) {
  const q = {};
  const bridges = [];
  for (const l of lanes) {
    const S = l.curvePts.map(([x, z]) => {
      riverQuery(x, z, q);
      const hw = halfWidth(q.z);
      return { x, z, y: hf.sample(x, z), bridge: !l.walk && q.d < hw + 4.2, plaza: Math.hypot(x - SQUARE.x, z - SQUARE.z) < SQUARE.r - 0.6, len: 0 };
    });
    for (let i = 1; i < S.length; i++) S[i].len = S[i - 1].len + Math.hypot(S[i].x - S[i - 1].x, S[i].z - S[i - 1].z);
    // smooth heights (walkways keep their ends pinned to the door and lane)
    const R = l.walk ? 1 : 5;
    const ys = S.map((s) => s.y);
    for (let i = 0; i < S.length; i++) {
      if (S[i].bridge) continue;
      let sum = 0, c = 0;
      for (let k = -R; k <= R; k++) { const j = i + k; if (j < 0 || j >= S.length || S[j].bridge) continue; sum += ys[j]; c++; }
      S[i].y = sum / c;
    }
    if (l.walk) {
      // an even gradient from the doorstep (house pad) to the lane it joins: no humps or dips
      const y0 = l.house && l.house.groundY !== undefined ? l.house.groundY : ys[0];
      const lane = l.house && l.house.walkLane && l.house.walkLane.samples;
      let y1 = ys[ys.length - 1];
      if (lane) { const e = S[S.length - 1]; let bd = 1e9; for (const q of lane) { const d = (q.x - e.x) ** 2 + (q.z - e.z) ** 2; if (d < bd) { bd = d; y1 = q.y; } } }
      const total = S[S.length - 1].len || 1;
      for (const s of S) s.y = y0 + (y1 - y0) * (s.len / total);
    }
    // bridges: contiguous runs flagged as bridge
    for (let i = 0; i < S.length; i++) {
      if (!S[i].bridge) continue;
      let j = i;
      while (j + 1 < S.length && S[j + 1].bridge) j++;
      const a = S[Math.max(0, i - 1)], b = S[Math.min(S.length - 1, j + 1)];
      for (let k = i; k <= j; k++) {
        const t = (S[k].len - a.len) / (b.len - a.len || 1);
        S[k].y = a.y + (b.y - a.y) * t;
      }
      riverQuery((a.x + b.x) / 2, (a.z + b.z) / 2, q);
      bridges.push({ a: [a.x, a.y, a.z], b: [b.x, b.y, b.z], water: waterLevel(q.z), lane: l.id, w: l.w + 0.6 });
      i = j;
    }
    l.samples = S;
  }
  return bridges;
}

const MATS = {};
function laneMaterial(type) {
  if (MATS[type]) return MATS[type];
  const common = { roughness: 0.95, metalness: 0, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 };
  if (type === 'slab') MATS[type] = new THREE.MeshStandardMaterial({ map: slabTexture(), ...common });
  else if (type === 'cobble') MATS[type] = new THREE.MeshStandardMaterial({ map: cobbleTexture(), ...common });
  else {
    const map = trailTexture();
    // soft edges: alpha via a horizontal gradient baked into a second texture
    const c = document.createElement('canvas'); c.width = 64; c.height = 4;
    const g = c.getContext('2d');
    const grd = g.createLinearGradient(0, 0, 64, 0);
    grd.addColorStop(0, '#000'); grd.addColorStop(0.22, '#fff'); grd.addColorStop(0.78, '#fff'); grd.addColorStop(1, '#000');
    g.fillStyle = grd; g.fillRect(0, 0, 64, 4);
    const alphaMap = new THREE.CanvasTexture(c);
    alphaMap.channel = 1; // ribbons copy uv into uv1; junction nodes use a radial uv1
    MATS[type] = new THREE.MeshStandardMaterial({ map, alphaMap, transparent: true, depthWrite: false, ...common });
  }
  return MATS[type];
}
export const kerbMaterial = new THREE.MeshStandardMaterial({ color: '#e9e5dd', roughness: 0.9, side: THREE.DoubleSide });

export function buildLaneMeshes(lanes, hf) {
  H = hf;
  const group = new THREE.Group();
  group.name = 'lanes';
  const byType = { slab: [], cobble: [], trail: [] };
  const kerbs = [];
  const all = lanes;
  const main = lanes.filter((l) => !l.walk);
  const nearOtherLane = (l, x, z) => {
    for (const o of all) {
      if (o === l) continue;
      for (let i = 0; i < o.samples.length; i += 2) {
        const s = o.samples[i];
        if ((s.x - x) ** 2 + (s.z - z) ** 2 < (o.w / 2 + 0.7) ** 2) return true;
      }
    }
    return Math.hypot(x - SQUARE.x, z - SQUARE.z) < SQUARE.r + 0.2;
  };

  // Junctions: where a lane ends on or beside another lane, lay a round paved node in the higher-grade
  // material that covers both ribbon ends, so lanes meet as one surface instead of overlapping caps.
  const rank = { trail: 0, cobble: 1, slab: 2 };
  const nodes = [];
  for (const l of main) for (const end of [l.samples[0], l.samples[l.samples.length - 1]]) {
    if (end.bridge || end.plaza || Math.hypot(end.x - SQUARE.x, end.z - SQUARE.z) < SQUARE.r + 2) continue;
    let hit = null;
    for (const o of main) {
      if (o === l) continue;
      for (const q of o.samples) if (Math.hypot(q.x - end.x, q.z - end.z) < o.w / 2 + 1.5) { hit = o; break; }
      if (hit) break;
    }
    if (!hit) continue;
    let n = nodes.find((m) => Math.hypot(m.x - end.x, m.z - end.z) < 4.5);
    if (!n) { n = { x: end.x, z: end.z, k: 0, sx: 0, sz: 0, w: 0, type: 'trail', lanes: new Set() }; nodes.push(n); }
    n.sx += end.x; n.sz += end.z; n.k++; n.x = n.sx / n.k; n.z = n.sz / n.k;
    for (const q of [l, hit]) { n.lanes.add(q); if (rank[q.type] > rank[n.type]) n.type = q.type; n.w = Math.max(n.w, q.w); }
  }
  for (const n of nodes) {
    n.r = n.w / 2 + (n.type === 'trail' ? 0.9 : 0.55);
    byType[n.type].push(junctionDisc(n.x, n.z, n.r, n.w, n.type === 'trail' ? 0.074 : 0.09));
  }
  lanes.forEach((l, li) => {
    const S = l.samples;
    const lift = l.walk ? 0.035 : 0.05 + (li % 5) * 0.004;
    const endJoined = (p) => main.some((o) => o !== l && o.samples.some((q) => Math.hypot(q.x - p.x, q.z - p.z) < o.w / 2 + 1.5));
    let run = [];
    const flush = () => {
      if (run.length >= 2) {
        // trails feather out only at their true ends, never where they meet a bridge or the square
        const tp = l.type === 'trail' && !l.walk;
        byType[l.type].push(ribbon(run, l.w, lift, tp && run[0] === S[0] && !endJoined(S[0]), tp && run[run.length - 1] === S[S.length - 1] && !endJoined(S[S.length - 1])));
        if (l.type === 'slab') for (const side of [-1, 1]) {
          let seg = [];
          for (const s of run) {
            const ox = s.x + s.nx * side * (l.w / 2 + 0.09), oz = s.z + s.nz * side * (l.w / 2 + 0.09);
            if (l.walk || nearOtherLane(l, ox, oz) || nodes.some((n) => Math.hypot(ox - n.x, oz - n.z) < n.r + 0.4)) { if (seg.length >= 2) kerbs.push(kerb(seg, side, l.w)); seg = []; }
            else seg.push(s);
          }
          if (seg.length >= 2) kerbs.push(kerb(seg, side, l.w));
        }
      }
      run = [];
    };
    for (let i = 0; i < S.length; i++) {
      const s = S[i];
      const p = S[Math.max(0, i - 1)], n = S[Math.min(S.length - 1, i + 1)];
      const tx = n.x - p.x, tz = n.z - p.z, tl = Math.hypot(tx, tz) || 1;
      s.nx = -tz / tl; s.nz = tx / tl;
      if (s.bridge || (s.plaza && !l.walk)) {
        // carry the surface one sample onto the bridge or square so it meets the deck/paving with no grass seam
        if (run.length) run.push(s);
        flush();
        continue;
      }
      if (!run.length && i > 0) { const q = S[i - 1]; if (q.bridge || (q.plaza && !l.walk)) run.push(q); }
      run.push(s);
    }
    flush();
  });

  group.userData.junctions = nodes.map((n) => ({ x: n.x, z: n.z, r: n.r, type: n.type }));
  // trail ends that run into a junction should not feather
  for (const n of nodes) for (const l of n.lanes) l.joined = (l.joined || 0) + 1;

  for (const [type, geos] of Object.entries(byType)) {
    if (!geos.length) continue;
    const m = new THREE.Mesh(mergeSimple(geos), laneMaterial(type));
    m.receiveShadow = true;
    m.renderOrder = type === 'trail' ? 1 : 0;
    group.add(m);
  }
  if (kerbs.length) {
    const m = new THREE.Mesh(mergeSimple(kerbs), kerbMaterial);
    m.receiveShadow = true; m.castShadow = true;
    group.add(m);
  }
  return group;
}

let H = null;
const groundAt = (x, z, fallback) => (H ? H.sample(x, z) : fallback);
// Round junction node conforming to the terrain; planar UVs at the lane texture scale, and a radial
// second UV for the soft trail edge.
function junctionDisc(cx, cz, R, w, lift) {
  const RINGS = 7, SEG = 40;
  const pos = [], uv = [], uv1 = [], idx = [];
  for (let i = 0; i <= RINGS; i++) {
    const rr = (i / RINGS) * R;
    for (let j = 0; j < SEG; j++) {
      const a = (j / SEG) * Math.PI * 2, x = cx + Math.cos(a) * rr, z = cz + Math.sin(a) * rr;
      pos.push(x, groundAt(x, z, 0) + lift, z);
      uv.push(x / w, z / w);
      uv1.push(0.5 + 0.5 * (i / RINGS), 0.5);
      if (i > 0) { const a0 = (i - 1) * SEG, b0 = i * SEG, jn = (j + 1) % SEG; idx.push(a0 + j, b0 + j, a0 + jn, a0 + jn, b0 + j, b0 + jn); }
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setAttribute('uv1', new THREE.Float32BufferAttribute(uv1, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

function ribbon(run, w, lift, taperStart = false, taperEnd = false) {
  // 5 vertices across the path, each sitting on the (path-shaped) terrain, so the surface can never
  // sink into the ground or hover over it at junctions and on cambered slopes
  // Densify along the run so the surface follows terrain curvature between lane samples (the
  // terrain grid is 1.25 m; vertices every ~0.5 m keep a convex rise from poking through).
  const ACROSS = 6;
  const dense = [];
  run.forEach((s, i) => {
    if (i > 0) {
      const p = run[i - 1], n = Math.ceil(Math.hypot(s.x - p.x, s.z - p.z) / 0.5);
      for (let k = 1; k < n; k++) {
        const t = k / n, nx = p.nx + (s.nx - p.nx) * t, nz = p.nz + (s.nz - p.nz) * t, nl = Math.hypot(nx, nz) || 1;
        dense.push({ x: p.x + (s.x - p.x) * t, z: p.z + (s.z - p.z) * t, y: p.y + (s.y - p.y) * t, nx: nx / nl, nz: nz / nl });
      }
    }
    dense.push(s);
  });
  run = dense;
  const pos = [], uv = [], idx = [];
  let v = 0;
  const total = run.length - 1;
  run.forEach((s, i) => {
    if (i > 0) v += Math.hypot(s.x - run[i - 1].x, s.z - run[i - 1].z) / w;
    const k = Math.min(1, taperStart ? 0.25 + i / 6 : 1, taperEnd ? 0.25 + (total - i) / 6 : 1);
    for (let c = 0; c <= ACROSS; c++) {
      const f = (c / ACROSS) * 2 - 1;
      const x = s.x + s.nx * f * w * k / 2, z = s.z + s.nz * f * w * k / 2;
      pos.push(x, groundAt(x, z, s.y) + lift, z);
      uv.push(c / ACROSS, v);
    }
    if (i > 0) {
      const a = (i - 1) * (ACROSS + 1), b = i * (ACROSS + 1);
      for (let c = 0; c < ACROSS; c++) idx.push(a + c, a + c + 1, b + c, a + c + 1, b + c + 1, b + c);
    }
  });
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

function kerb(seg, side, w) {
  // rounded-ish kerb: 4 profile points (outer bottom, outer top, inner top, inner bottom)
  const prof = [[0.2, -0.15], [0.2, 0.13], [0.05, 0.17], [-0.06, 0.13], [-0.06, -0.15]];
  const pos = [], idx = [];
  seg.forEach((s, i) => {
    for (const [o, y] of prof) {
      const off = (w / 2 + 0.06 + o) * side;
      const kx = s.x + s.nx * off, kz = s.z + s.nz * off;
      pos.push(kx, groundAt(s.x + s.nx * (w / 2 + 0.06) * side, s.z + s.nz * (w / 2 + 0.06) * side, s.y) + y, kz);
    }
    if (i > 0) {
      const a = (i - 1) * prof.length, b = i * prof.length;
      for (let k = 0; k < prof.length - 1; k++) {
        if (side > 0) idx.push(a + k, b + k, a + k + 1, a + k + 1, b + k, b + k + 1);
        else idx.push(a + k, a + k + 1, b + k, a + k + 1, b + k + 1, b + k);
      }
    }
  });
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(new Array((pos.length / 3) * 2).fill(0), 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

export function mergeSimple(geos) {
  // merge indexed geometries that share position/uv(/normal) attributes
  let vcount = 0, icount = 0;
  for (const g of geos) { vcount += g.attributes.position.count; icount += g.index.count; }
  const pos = new Float32Array(vcount * 3), nor = new Float32Array(vcount * 3), uv = new Float32Array(vcount * 2);
  const idx = new Uint32Array(icount);
  const uv1 = geos.some((g) => g.attributes.uv1) ? new Float32Array(vcount * 2) : null;
  let vo = 0, io = 0;
  for (const g of geos) {
    pos.set(g.attributes.position.array, vo * 3);
    nor.set(g.attributes.normal.array, vo * 3);
    uv.set(g.attributes.uv.array, vo * 2);
    if (uv1) uv1.set((g.attributes.uv1 || g.attributes.uv).array, vo * 2);
    const gi = g.index.array;
    for (let i = 0; i < gi.length; i++) idx[io + i] = gi[i] + vo;
    vo += g.attributes.position.count; io += gi.length;
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  out.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  if (uv1) out.setAttribute('uv1', new THREE.BufferAttribute(uv1, 2));
  out.setIndex(new THREE.BufferAttribute(idx, 1));
  return out;
}
