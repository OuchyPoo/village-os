// Collects many small static meshes and merges them per material: keeps draw calls low
// while letting builders work with simple primitives and transforms.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export class Batcher {
  constructor() { this.parts = new Map(); }
  add(geometry, matrix, material) {
    let g = geometry.index ? geometry.toNonIndexed() : geometry.clone();
    for (const name of Object.keys(g.attributes)) if (!['position', 'normal', 'uv'].includes(name)) g.deleteAttribute(name);
    if (!g.attributes.uv) g.setAttribute('uv', new THREE.Float32BufferAttribute(new Float32Array(g.attributes.position.count * 2), 2));
    g.applyMatrix4(matrix);
    if (material.userData && material.userData.boxUV) boxProjectUV(g, material.userData.boxUV);
    if (!this.parts.has(material)) this.parts.set(material, []);
    this.parts.get(material).push(g);
  }
  build(name = 'batch', { castShadow = true, receiveShadow = true } = {}) {
    const group = new THREE.Group();
    group.name = name;
    for (const [mat, geos] of this.parts) {
      const merged = mergeGeometries(geos, false);
      const mesh = new THREE.Mesh(merged, mat);
      mesh.castShadow = castShadow;
      mesh.receiveShadow = receiveShadow;
      group.add(mesh);
      geos.forEach((g) => g.dispose());
    }
    this.parts.clear();
    return group;
  }
}

// Spatially tiled batching: one Batcher per square tile (by each part's placement), so whole tiles can
// be frustum culled by the camera and by the sun's shadow camera instead of drawing the village at once.
export class TiledBatcher {
  constructor(size = 56) { this.size = size; this.tiles = new Map(); }
  add(geometry, matrix, material) {
    const k = Math.floor(matrix.elements[12] / this.size) + ',' + Math.floor(matrix.elements[14] / this.size);
    if (!this.tiles.has(k)) this.tiles.set(k, new Batcher());
    this.tiles.get(k).add(geometry, matrix, material);
  }
  build(name = 'batch', opts) {
    const group = new THREE.Group();
    group.name = name;
    for (const b of this.tiles.values()) group.add(b.build(name + '-tile', opts));
    this.tiles.clear();
    return group;
  }
}

const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler(), _s = new THREE.Vector3(1, 1, 1), _p = new THREE.Vector3();
export function mat4(x, y, z, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1) {
  _e.set(rx, ry, rz, 'YXZ');
  _q.setFromEuler(_e);
  _p.set(x, y, z);
  _s.set(sx, sy, sz);
  return new THREE.Matrix4().compose(_p, _q, _s);
}

// World-space box projection so plaster, timber and stone keep a constant texel size on any part.
export function boxProjectUV(g, metres) {
  const p = g.attributes.position, n = g.attributes.normal, uv = g.attributes.uv;
  const k = 1 / metres;
  // texture streaks run vertically on walls and along the longest axis of beams
  for (let i = 0; i < p.count; i++) {
    const ax = Math.abs(n.getX(i)), ay = Math.abs(n.getY(i)), az = Math.abs(n.getZ(i));
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    if (ay >= ax && ay >= az) uv.setXY(i, x * k, z * k);
    else if (ax >= az) uv.setXY(i, z * k, y * k);
    else uv.setXY(i, x * k, y * k);
  }
  uv.needsUpdate = true;
}
