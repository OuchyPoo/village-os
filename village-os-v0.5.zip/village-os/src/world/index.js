// Assembles the whole world: terrain, river, lanes, bridges, houses, props, vegetation, sky.
// Returns render groups plus the gameplay data (colliders, walkable surfaces, interactables).
import * as THREE from 'three';
import { mulberry32, noise, smoothstep } from '../core/math.js';
import { LANES, SQUARE, CLEARING_COTTAGES, buildLayout, forestPatch } from './layout.js';
import { samples, waterLevel, halfWidth, rapidness, CASCADES, riverQuery } from './river.js';
import { Heightfield, baseHeight } from './heightfield.js';
import { makeLaneCurves, makeWalkways, profileLanes, buildLaneMeshes, kerbMaterial } from './paths.js';
import { buildTerrain, buildFarTerrain } from './terrain.js';
import { buildRiver, buildFoamRings, buildSpray } from './water.js';
import { planHouse, buildHouse } from './buildings.js';
import { Footprints, footprintGround } from './placement.js';
import { buildBridge } from './bridges.js';
import { Batcher, TiledBatcher, mat4 } from './batcher.js';
import { buildRocks } from './rocks.js';
import { buildTrees, buildPines, buildGrass, buildFlowers, timeUniform } from './vegetation.js';
import { addFence, addGate, addStoneWall, addHedgeRow, addLampPost, makeHangingSign, addBench, addMailbox, addNoticeboard } from './props.js';
import { plazaTexture, softDot } from './textures.js';
import { buildSky, buildClouds } from './sky.js';
import { DOMAINS, EMPTY_PLOT } from '../data/domains.js';
import { enrichWorld, reserveSpots } from './enrich.js';
import { scatter } from './kit.js';
import { grassTuft } from './assets.js';

export function buildWorld(assets, sunDir) {
  const root = new THREE.Group();
  root.name = 'world';
  const rand = mulberry32(99);
  const colliders = { obbs: [], circles: [], segs: [] };
  const footprints = new Footprints(colliders);
  const surfaces = [];
  const interactables = [];
  const animated = [];

  // 1. plan: lanes, houses, walkways
  const lanes = makeLaneCurves(LANES);
  const houses = buildLayout(lanes).map(planHouse);
  const walkways = makeWalkways(houses, lanes);

  // 2. terrain shaping
  const hf = new Heightfield();
  // the square sits as a gentle dais at the mean height of its surroundings, never in a hollow
  let rim = 0;
  for (let i = 0; i < 24; i++) { const a = (i / 24) * Math.PI * 2; rim += hf.sample(SQUARE.x + Math.cos(a) * (SQUARE.r + 3), SQUARE.z + Math.sin(a) * (SQUARE.r + 3)); }
  const squareY = Math.max(hf.sample(SQUARE.x, SQUARE.z), rim / 24) + 0.12;
  hf.applyDisc(SQUARE.x, SQUARE.z, SQUARE.r + 0.5, squareY, 7);
  for (const h of houses) {
    const [cx, cz] = h.toWorld(0, h.pad.oz);
    h.groundY = hf.sample(h.x, h.z);
    // a house sits at a height its walkway can reach at a gentle gradient (no ramps steeper than ~1 in 5)
    const wk = walkways.find((w) => w.house === h);
    if (wk) {
      const E = wk.curvePts[wk.curvePts.length - 1];
      let L = 0; for (let i = 1; i < wk.curvePts.length; i++) L += Math.hypot(wk.curvePts[i][0] - wk.curvePts[i - 1][0], wk.curvePts[i][1] - wk.curvePts[i - 1][1]);
      const ly = hf.sample(E[0], E[1]) + 0.05, rise = 0.12 + 0.2 * L;
      h.groundY = Math.min(ly + rise, Math.max(ly - rise * 0.6, h.groundY));
    }
    hf.applyPad(cx, cz, h.rot, h.pad.hx, h.pad.hz, h.groundY, 5);
  }
  const allLanes = [...lanes, ...walkways];
  const bridgeData = profileLanes(hf, allLanes);
  // second pass now the lanes have their final heights: any house still too far above or below the
  // lane its walkway joins is re-levelled, and the walkway regraded to an even slope
  for (const w of walkways) {
    const h = w.house, S = w.samples;
    if (!h || !S || S.length < 2) continue;
    const L = S[S.length - 1].len || 1, y1 = S[S.length - 1].y, rise = 0.12 + 0.2 * L;
    const ny = Math.min(y1 + rise, Math.max(y1 - rise * 0.6, h.groundY));
    if (Math.abs(ny - h.groundY) < 0.02) continue;
    h.groundY = ny;
    const [cx, cz] = h.toWorld(0, h.pad.oz);
    hf.applyPad(cx, cz, h.rot, h.pad.hx, h.pad.hz, h.groundY, 5);
    for (const q of S) q.y = ny + (y1 - ny) * (q.len / L);
  }
  hf.applyPaths(allLanes);
  // re-assert the square after pads and lanes so nothing carves into or buries the paving; the short
  // blend never reaches into a house pad
  hf.forCellsInRadius(SQUARE.x, SQUARE.z, SQUARE.r + 3, (k, x, z) => {
    if (hf.mask[k] & 2) return;
    const d = Math.max(0, Math.hypot(x - SQUARE.x, z - SQUARE.z) - (SQUARE.r + 0.6));
    const t = 1 - smoothstep(0, 2.4, d);
    if (t > 0) hf.h[k] += (squareY - hf.h[k]) * t;
  });

  // 3. terrain + river
  root.add(buildTerrain(hf));
  root.add(buildFarTerrain(hf));
  const river = buildRiver(sunDir);
  root.add(river);
  animated.push((t) => { river.material.uniforms.uTime.value = t; });

  // 4. bridges
  const bridges = bridgeData.map(buildBridge);
  for (const b of bridges) {
    root.add(b.group);
    surfaces.push(b.surface);
    colliders.segs.push(...b.segs);
    hf.forCellsInRadius(b.mid.x, b.mid.z, b.L / 2 + 2, (k) => { hf.mask[k] |= 16; });
  }

  // 5. lanes and the square
  root.add(buildLaneMeshes(allLanes, hf));
  {
    const disc = new THREE.Mesh(new THREE.CircleGeometry(SQUARE.r, 64).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ map: plazaTexture(), roughness: 0.95, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 }));
    disc.position.set(SQUARE.x, squareY + 0.06, SQUARE.z);
    disc.receiveShadow = true;
    root.add(disc);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(SQUARE.r + 0.05, 0.12, 6, 96).rotateX(Math.PI / 2), kerbMaterial);
    ring.scale.y = 0.8;
    ring.position.set(SQUARE.x, squareY + 0.05, SQUARE.z);
    ring.receiveShadow = true;
    root.add(ring);
  }

  // 6. houses
  const batch = new TiledBatcher(56);
  const add = (g, m, mat) => batch.add(g, m, mat);
  const doorPivots = new THREE.Group();
  doorPivots.name = 'doors';
  const domainSigns = [];
  for (const h of houses) {
    const res = buildHouse(h, add, h.groundY);
    colliders.obbs.push(...res.colliders.map((c) => ({ ...c, house: h })));
    surfaces.push(...res.surfaces);
    doorPivots.add(res.doorPivot);
    h.doorObj = res.door;
    h.ridgeY = res.ridgeY;
    const info = h.domain ? DOMAINS[h.domain] : EMPTY_PLOT;
    const [fx, fz] = h.door.front;
    interactables.push({
      id: 'door:' + (h.domain || `${Math.round(h.x)},${Math.round(h.z)}`),
      kind: 'door', x: fx, z: fz, y: hf.sample(fx, fz), r: 2.4,
      label: h.domain ? `Enter ${info.title}` : 'Knock',
      info, house: h,
    });
    if (h.domain) domainSigns.push(h);
  }

  // 7. props
  const fenceSegs = [];
  // inside any building footprint (with a small margin), for keeping boundaries off structures
  const insideBuilding = (x, z, except = null, margin = 0.35) => colliders.obbs.some((o) => {
    if (o.house === except) return false;
    const dx = x - o.x, dz = z - o.z, c = Math.cos(o.rot), s2 = Math.sin(o.rot);
    const lx = dx * c - dz * s2, lz = dx * s2 + dz * c;
    return Math.abs(lx) < o.hx + margin && Math.abs(lz) < o.hz + margin;
  });
  const audit = { gates: { placed: 0, onWalkway: 0 } };
  for (const h of houses) {
    if (!h.garden) continue;
    // a front garden: returns from the front corners of the house, out to a front line with the gate on the
    // door axis exactly where the walkway runs through it
    const depth = h.yardDepth ?? 2.4;
    const frontLine = h.doorLocal[1] + depth;
    // no room for a front garden, or no gate on the walkway: leave the frontage open rather than wall off the door
    if (frontLine - h.d / 2 < 1.0 || !h.gate) continue;
    const annexR = h.domain === 'health' ? 3.2 : 0, annexL = h.domain === 'work' || h.details?.leanTo ? 2.8 : 0;
    const xL = -h.w / 2 - 1.4 - annexL, xR = h.w / 2 + 1.4 + annexR;
    const zBack = h.d / 2 - 0.1;
    const doorX = h.doorLocal[0];
    const P = (lx, lz) => h.toWorld(lx, lz);
    const kind = ['white', 'wood', 'hedge', 'wall', 'white', 'wood'][(h.seed || 0) % 6];
    h.boundary = kind;
    h.arch = kind !== 'wall' && (h.seed || 0) % 5 < 3 && !!h.gate;
    // half opening: hedges and walls are thick, so their ends step back to keep a clear 2 m way through
    const gap = h.gate ? { hedge: 1.4, wall: 1.25 }[kind] || 1.0 : 0;
    const left = [P(-h.w / 2 - annexL, zBack), P(xL, zBack), P(xL, frontLine)];
    const right = [P(xR, frontLine), P(xR, zBack), P(h.w / 2 + annexR, zBack)];
    left.push(P(doorX - gap, frontLine)); right.unshift(P(doorX + gap, frontLine));
    const wr = mulberry32(h.seed || 3);
    const blocked = (x, z) => insideBuilding(x, z, h);
    for (const pts of [left, right]) {
      if (pts.length < 2) continue;
      if (kind === 'hedge') addHedgeRow(add, hf, pts, fenceSegs, { rand: wr, blocked });
      else if (kind === 'wall') addStoneWall(add, hf, pts, fenceSegs, { rand: wr, blocked });
      else addFence(add, hf, pts, fenceSegs, { white: kind === 'white', blocked });
    }
    if (h.gate && kind !== 'hedge') {
      addGate(add, hf, h.gate.x, h.gate.z, h.rot + Math.PI / 2, kind === 'white', 2 * gap - 0.1, colliders.circles, kind === 'wall');
      audit.gates.placed++;
      if (hf.maskAt(h.gate.x, h.gate.z) & 1) audit.gates.onWalkway++;
    }
  }
  colliders.segs.push(...fenceSegs);

  // lamp posts along paved lanes
  for (const l of lanes) {
    if (l.type === 'trail') continue;
    let acc = 6;
    let side = 1;
    for (let i = 1; i < l.samples.length; i++) {
      const s = l.samples[i];
      acc += 1;
      if (acc < 19 || s.bridge || s.plaza) continue;
      const x = s.x + s.nx * side * (l.w / 2 + 0.55), z = s.z + s.nz * side * (l.w / 2 + 0.55);
      if (hf.maskAt(x, z) & (1 | 2 | 8 | 16) || hf.riverDist(x, z) < 1) continue;
      addLampPost(add, x, hf.sample(x, z), z);
      colliders.circles.push({ x, z, r: 0.22 });
      acc = 0; side = -side;
    }
  }
  // hanging signs for domain houses, mailboxes for the rest
  for (const h of houses) {
    const [lx, lz] = [h.doorLocal[0] + (h.domain === 'home' ? 2.5 : 1.7), h.d / 2 + h.wingD + (h.domain === 'home' ? 2.6 : 2.0)]; // clear of the home porch
    const [x, z] = h.toWorld(lx, lz);
    if (hf.maskAt(x, z) & 1) continue;
    if (h.domain) {
      const sign = makeHangingSign(DOMAINS[h.domain].title, x, hf.sample(x, z), z, h.rot);
      root.add(sign);
      animated.push((t) => { sign.userData.swing.rotation.x = Math.sin(t * 1.3 + h.x) * 0.06; });
      colliders.circles.push({ x, z, r: 0.2 });
    } else if (rand() < 0.6) {
      addMailbox(add, x, hf.sample(x, z), z, h.rot + Math.PI);
      colliders.circles.push({ x, z, r: 0.2 });
    }
  }
  // square: fountain (Kenney CC0), benches, noticeboard
  {
    const f = assets.fountain.scene.clone();
    f.scale.setScalar(6.5);
    f.position.set(SQUARE.x, squareY + 0.02, SQUARE.z);
    f.traverse((o) => {
      if (o.isMesh) {
        o.castShadow = o.receiveShadow = true;
        o.material = o.material.clone();
        o.material.color.set('#fffaf2');
      }
    });
    // strip the asset's square paving tile (our round plaza replaces it) and sit the basin on the cobbles
    f.traverse((o) => {
      if (!o.isMesh) return;
      const g = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone();
      const p = g.attributes.position;
      const keep = [];
      for (let t = 0; t < p.count; t += 3) {
        let low = true, cx = 0, cz = 0;
        for (let k = 0; k < 3; k++) { if (p.getY(t + k) > 0.051) low = false; cx += p.getX(t + k) / 3; cz += p.getZ(t + k) / 3; }
        if (!(low && Math.max(Math.abs(cx), Math.abs(cz)) > 0.36)) keep.push(t);
      }
      const ng = new THREE.BufferGeometry();
      for (const [name, attr] of Object.entries(g.attributes)) {
        const arr = new attr.array.constructor(keep.length * 3 * attr.itemSize);
        keep.forEach((t, i) => { for (let k = 0; k < 3 * attr.itemSize; k++) arr[i * 3 * attr.itemSize + k] = attr.array[t * attr.itemSize + k]; });
        ng.setAttribute(name, new THREE.BufferAttribute(arr, attr.itemSize, attr.normalized));
      }
      o.geometry = ng;
    });
    f.position.y -= 0.05 * 6.5;
    root.add(f);
    colliders.circles.push({ x: SQUARE.x, z: SQUARE.z, r: 2.6 });
    const spray = fountainSpray(SQUARE.x, squareY + 2.4, SQUARE.z);
    root.add(spray);
    animated.push((t) => { spray.material.uniforms.uTime.value = t; });
    interactables.push({ id: 'fountain', kind: 'fountain', x: SQUARE.x, z: SQUARE.z + 3.4, y: squareY, r: 3.2, label: 'Toss a coin', target: new THREE.Vector3(SQUARE.x, squareY + 1.2, SQUARE.z) });

    for (let i = 0; i < 4; i++) {
      const a = i * Math.PI / 2 + Math.PI / 4;
      const x = SQUARE.x + Math.cos(a) * 7.2, z = SQUARE.z + Math.sin(a) * 7.2;
      const rot = Math.atan2(SQUARE.x - x, SQUARE.z - z); // face the fountain
      addBench(add, x, squareY + 0.05, z, rot);
      colliders.obbs.push({ x, z, rot, hx: 0.9, hz: 0.35, y0: squareY, y1: squareY + 0.9 });
      interactables.push({ id: 'bench' + i, kind: 'bench', x: x + Math.sin(rot) * 1.0, z: z + Math.cos(rot) * 1.0, y: squareY, r: 1.8, label: 'Sit', seat: { x: x + Math.sin(rot) * 0.05, z: z + Math.cos(rot) * 0.05, y: squareY + 0.05, rot } });
    }
    const nbA = -0.9;
    const nx = SQUARE.x + Math.cos(nbA) * (SQUARE.r - 1.4), nz = SQUARE.z + Math.sin(nbA) * (SQUARE.r - 1.4);
    const nrot = Math.atan2(SQUARE.x - nx, SQUARE.z - nz);
    addNoticeboard(add, nx, squareY, nz, nrot);
    colliders.obbs.push({ x: nx, z: nz, rot: nrot, hx: 1.2, hz: 0.25, y0: squareY, y1: squareY + 2.4 });
    interactables.push({ id: 'noticeboard', kind: 'noticeboard', x: nx + Math.sin(nrot) * 1.4, z: nz + Math.cos(nrot) * 1.4, y: squareY, r: 2.4, label: 'Read the noticeboard' });
  }
  // riverside benches along the promenade
  {
    const prom = lanes.find((l) => l.id === 'promenade');
    for (let i = 16; i < prom.samples.length - 10; i += 23) {
      const s = prom.samples[i];
      const q = riverQuery(s.x, s.z, {});
      const toR = Math.sign((q.x - s.x) * s.nx + (q.z - s.z) * s.nz) || 1;
      const x = s.x + s.nx * toR * (prom.w / 2 + 1.0), z = s.z + s.nz * toR * (prom.w / 2 + 1.0);
      if (hf.riverDist(x, z) < 1.5 || hf.maskAt(x, z) & (1 | 2 | 16)) continue;
      const rot = Math.atan2(s.nx * toR, s.nz * toR); // back to the lane, facing the river
      if (!footprints.fits(x, z, 0.9)) continue;
      const g = footprintGround(hf, x, z, rot, 0.85, 0.3);
      if (g.tilt > 0.2) continue; // too steep for a level bench
      const y = g.y;
      addBench(add, x, y, z, rot);
      colliders.obbs.push({ x, z, rot, hx: 0.9, hz: 0.35, y0: y, y1: y + 0.9 });
      interactables.push({ id: 'pbench' + i, kind: 'bench', x: s.x, z: s.z, y: s.y, r: 2.4, label: 'Sit by the river', seat: { x: x + Math.sin(rot) * 0.05, z: z + Math.cos(rot) * 0.05, y, rot } });
    }
  }
  root.add(batch.build('houses+props'));
  root.add(doorPivots);

  // 8. rocks along the river
  const rocks = [];
  const inRiver = [];
  const nearBridge = (x, z) => bridges.some((b) => Math.hypot(x - b.mid.x, z - b.mid.z) < b.L / 2 + 1.5);
  for (let i = 0; i < samples.length; i++) {
    const s = samples[i];
    if (s.z < -230 || s.z > 230) continue;
    const hw = halfWidth(s.z), W = waterLevel(s.z), rp = rapidness(s.z);
    const cascade = CASCADES.some((c) => s.z > c.z0 - 3 && s.z < c.z1 + 6);
    if (i % 2 === 0) for (const side of [-1, 1]) {
      if (rand() > 0.22 + rp * 0.45 + (cascade ? 0.6 : 0)) continue;
      const off = (hw + (rand() - 0.35) * 1.8) * side;
      const x = s.x - s.tz * off, z = s.z + s.tx * off;
      if (nearBridge(x, z)) continue;
      const sz = (0.45 + rand() * 0.8) * (cascade ? 1.7 : 1);
      rocks.push({ x, y: W - 0.15 + rand() * 0.2, z, s: sz, rot: rand() * 6.28 });
      if (Math.abs(off) > hw + 0.3 && sz > 0.6) colliders.circles.push({ x, z, r: sz * 0.85 });
    }
    if (rp > 0.45 && i % 5 === 0 && rand() < rp * 0.55) {
      const off = (rand() * 2 - 1) * (hw - 1.2);
      const x = s.x - s.tz * off, z = s.z + s.tx * off;
      if (nearBridge(x, z)) continue;
      const sz = 0.45 + rand() * 0.7;
      const r = { x, y: W - 0.12, z, s: sz, rot: rand() * 6.28, water: W };
      rocks.push(r); inRiver.push(r);
    }
  }
  for (const c of CASCADES) {
    // lip of boulders across the top of each cascade
    for (let k = -3; k <= 3; k++) {
      const z = c.z0 + 2 + rand() * 2;
      const s = samples.reduce((b, p) => (Math.abs(p.z - z) < Math.abs(b.z - z) ? p : b));
      const hw = halfWidth(z);
      const off = (k / 3) * (hw - 0.6);
      const r = { x: s.x - s.tz * off, y: waterLevel(z) - 0.25, z: s.z + s.tx * off, s: 0.8 + rand() * 0.7, rot: rand() * 6.28, water: waterLevel(z) };
      rocks.push(r); inRiver.push(r);
    }
    // stepped boulders on the cascade banks
    for (let k = 0; k < 12; k++) {
      const z = c.z0 + rand() * (c.z1 - c.z0 + 6);
      const s = samples.reduce((b, p) => (Math.abs(p.z - z) < Math.abs(b.z - z) ? p : b));
      const side = k % 2 ? 1 : -1;
      const off = side * (halfWidth(z) + 0.5 + rand() * 2.2);
      const x = s.x - s.tz * off, zz = s.z + s.tx * off;
      const sz = 1.2 + rand() * 1.4;
      rocks.push({ x, y: hf.sample(x, zz) - sz * 0.15, z: zz, s: sz, rot: rand() * 6.28 });
      colliders.circles.push({ x, z: zz, r: sz * 0.9 });
    }
  }
  // scattered boulders in meadows and forest
  for (let i = 0; i < 160; i++) {
    const a = rand() * Math.PI * 2, r = 30 + rand() * 180;
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (hf.maskAt(x, z) || hf.riverDist(x, z) < 3) continue;
    if (houses.some((h) => Math.hypot(h.x - x, h.z - z) < h.r + 4)) continue;
    const sz = 0.4 + rand() * rand() * 2.2;
    if (!footprints.fits(x, z, sz * 0.85)) continue;
    rocks.push({ x, y: hf.sample(x, z) - sz * 0.2, z, s: sz, rot: rand() * 6.28 });
    if (sz > 0.6) colliders.circles.push({ x, z, r: sz * 0.85 });
  }
  root.add(buildRocks(rocks));
  const foam = buildFoamRings(inRiver);
  root.add(foam);
  const spray = buildSpray();
  root.add(spray);
  animated.push((t) => { foam.material.uniforms.uTime.value = t; spray.material.uniforms.uTime.value = t; });

  // 9. vegetation
  const occ = makeOccupancy(hf, houses, allLanes);
  const trees = [], pines = [], grass = [], flowers = [];
  const villageAnchors = [[SQUARE.x, SQUARE.z], [-30, -32], [25, 15], [2, 45], [-45, 26], [-12, -62], [40, 10], [-60, 5]];
  const villageDist = (x, z) => Math.min(...villageAnchors.map(([ax, az]) => Math.hypot(x - ax, z - az)));
  const clearings = [...CLEARING_COTTAGES, { x: 112, z: 22 }];
  const free = (x, z, pad = 0) => occ.get(x, z, pad) === 0;
  const reserved = reserveSpots({ hf, occ, rand, villageDist });
  const addTree = (kind, x, z, s, extra = {}) => {
    // trunks never stand inside a building, wall, fence, prop or another trunk
    if (!footprints.fits(x, z, kind === 'bush' ? 0.3 * s : 0.35 * s)) return;
    const y = hf.sample(x, z);
    trees.push({ kind, x, y, z, s, rot: rand() * 6.28, ...extra });
    // trunks block; large bushes block at their woody core; small shrubs stay walk-through
    if (kind !== 'bush') colliders.circles.push({ x, z, r: 0.35 * s });
    else if (s > 0.8) colliders.circles.push({ x, z, r: 0.32 * s });
    occ.mark(x, z, kind === 'bush' ? 1 : 1.6);
  };
  // forest
  for (let gx = -212; gx <= 212; gx += 3.7) for (let gz = -212; gz <= 212; gz += 3.7) {
    const x = gx + (rand() - 0.5) * 3.2, z = gz + (rand() - 0.5) * 3.2;
    const R = Math.hypot(x, z);
    if (R > 214) continue;
    const vd = villageDist(x, z);
    // forests in patches with open meadows between, denser towards the valley sides
    const patch = forestPatch(x, z);
    let dens = smoothstep(26, 70, vd) * (0.03 + 1.0 * patch);
    const cl = Math.min(...clearings.map((c) => Math.hypot(x - c.x, z - c.z)));
    dens *= smoothstep(14, 24, cl);
    if (rand() > dens) continue;
    if (!free(x, z, 1) || hf.riverDist(x, z) < 2.5 || hf.slope(x, z) > 1.1) continue;
    // stands: species follow broad noise zones (conifer, broadleaf, mixed) instead of a random mix
    const zone = noise(x * 0.011 + 50, z * 0.011 - 20) + 0.25 * noise(x * 0.04, z * 0.04);
    const age = 0.85 + 0.35 * (noise(x * 0.02 - 7, z * 0.02 + 3) * 0.5 + 0.5); // older, larger trees in stand cores
    const r = rand();
    let kind;
    if (zone > 0.18) kind = r < 0.55 ? 'pine' : r < 0.9 ? 'spruce' : 'tieredTall';
    else if (zone < -0.15) kind = r < 0.35 ? 'oak' : r < 0.6 ? 'linden' : r < 0.82 ? 'round' : r < 0.92 ? 'tiered' : 'bush';
    else kind = r < 0.3 ? 'pine' : r < 0.5 ? 'tieredTall' : r < 0.65 ? 'tiered' : r < 0.78 ? 'round' : r < 0.88 ? 'linden' : r < 0.94 ? 'spruce' : 'bush';
    if (kind === 'pine') {
      const s = (3.0 + rand() * 1.8) * age;
      const y = hf.sample(x, z);
      pines.push({ x, y, z, s, rot: rand() * 6.28 });
      colliders.circles.push({ x, z, r: 0.12 * s });
      occ.mark(x, z, 1.4);
    } else if (kind === 'oak') { addTree('oak', x, z, (0.75 + rand() * 0.3) * age); occ.mark(x, z, 3); }
    else addTree(kind, x, z, (kind === 'bush' ? 0.9 + rand() * 0.8 : 0.85 + rand() * 0.4) * age);
    // forest edges get an understorey of shrubs so trees grow out of the ground, not off it
    if (patch < 0.75 && kind !== 'bush' && rand() < 0.45) {
      for (let k = 0; k < 1 + Math.floor(rand() * 2); k++) {
        const a = rand() * 6.28, d = 1.4 + rand() * 1.4;
        const bx = x + Math.cos(a) * d, bz = z + Math.sin(a) * d;
        if (occ.get(bx, bz, 0) !== 1 && occ.get(bx, bz, 0) !== 3 && hf.riverDist(bx, bz) > 2) trees.push({ kind: 'bush', x: bx, y: hf.sample(bx, bz), z: bz, s: 0.6 + rand() * 0.6, rot: rand() * 6.28, dark: rand() < 0.4 });
      }
    }
  }
  // gardens: a feature tree or two, bushes and flowers by every house
  for (const h of houses) {
    const spots = [[-h.w / 2 - 3.2, h.d / 2 + 0.5], [h.w / 2 + 3.2, -h.d / 4], [-h.w / 2 - 2.5, -h.d / 2 - 2.5], [h.w / 2 + 2.4, h.d / 2 + h.wingD + 0.8], [0, -h.d / 2 - 3.5]];
    spots.forEach(([lx, lz], i) => {
      const [x, z] = h.toWorld(lx + (rand() - 0.5), lz + (rand() - 0.5));
      if (!free(x, z, 0.8) || hf.riverDist(x, z) < 2) return;
      if (i < 2 && rand() < 0.75) { const sp = ['tiered', 'round', 'linden', 'round', 'oak'][Math.floor(rand() * 5)]; addTree(sp, x, z, (sp === 'oak' ? 0.55 : 0.75) + rand() * 0.3); }
      else addTree('bush', x, z, 0.8 + rand() * 0.6);
    });
    const nf = h.garden ? 12 : 5;
    for (let k = 0; k < nf; k++) {
      const lx = (rand() - 0.5) * (h.w + 3), lz = h.d / 2 + h.wingD + 0.6 + rand() * 1.4;
      const [x, z] = h.toWorld(lx, lz);
      if (!free(x, z, 0.2) || hf.maskAt(x, z) & 1) continue;
      flowers.push({ x, z, y: hf.sample(x, z), s: 0.9 + rand() * 0.6 });
    }
  }
  // the square is framed by four round trees
  for (let i = 0; i < 4; i++) {
    const a = i * Math.PI / 2;
    const x = SQUARE.x + Math.cos(a) * (SQUARE.r + 2.8), z = SQUARE.z + Math.sin(a) * (SQUARE.r + 2.8);
    if (free(x, z, 0.5)) addTree('linden', x, z, 0.8);
  }
  // promenade trees
  {
    const prom = lanes.find((l) => l.id === 'promenade');
    for (let i = 8; i < prom.samples.length; i += 11) {
      const s = prom.samples[i];
      for (const side of [-1, 1]) {
        const x = s.x + s.nx * side * (prom.w / 2 + 2.2), z = s.z + s.nz * side * (prom.w / 2 + 2.2);
        if (free(x, z, 1) && hf.riverDist(x, z) > 2.5 && rand() < 0.6) addTree(['tiered', 'tieredTall', 'linden', 'round'][Math.floor(rand() * 4)], x, z, 0.8 + rand() * 0.3);
      }
    }
  }
  // a poplar avenue framing the south lane, and a few solitary oaks on the village greens
  for (const l of lanes) {
    if (l.id !== 'south' && l.id !== 'eastHill') continue;
    for (let i = 6; i < l.samples.length - 4; i += 7) {
      const s = l.samples[i];
      if (s.bridge) continue;
      for (const side of [-1, 1]) {
        const off = l.w / 2 + 2.1;
        const x = s.x + s.nx * side * off, z = s.z + s.nz * side * off;
        if (free(x, z, 1) && hf.riverDist(x, z) > 3 && hf.slope(x, z) < 0.6) addTree('poplar', x, z, 0.85 + rand() * 0.25);
      }
    }
  }
  for (let t = 0, n = 0; t < 600 && n < 10; t++) {
    const a = rand() * 6.28, d = 25 + rand() * 60;
    const x = -10 + Math.cos(a) * d, z = 5 + Math.sin(a) * d;
    if (!free(x, z, 4) || hf.riverDist(x, z) < 5 || hf.slope(x, z) > 0.4) continue;
    addTree('oak', x, z, 0.9 + rand() * 0.3); occ.mark(x, z, 4.5); n++;
    for (let k = 0; k < 3; k++) { const b = rand() * 6.28, r2 = 3 + rand() * 1.5; const bx = x + Math.cos(b) * r2, bz = z + Math.sin(b) * r2; if (free(bx, bz, 0)) trees.push({ kind: 'bush', x: bx, y: hf.sample(bx, bz), z: bz, s: 0.7 + rand() * 0.5, rot: rand() * 6.28 }); }
  }

  // lawn grass and meadow flowers
  for (let i = 0; i < 14000 && grass.length < 4200; i++) {
    const a = rand() * Math.PI * 2, r = Math.sqrt(rand()) * 160;
    const x = Math.cos(a) * r - 10, z = Math.sin(a) * r;
    const m = hf.maskAt(x, z);
    if (m || hf.riverDist(x, z) < 0.8) continue;
    const o = occ.get(x, z, 1);
    if (occ.get(x, z, 0) === 3) continue; // under buildings
    // tufts gather along edges: paths, fences, houses, tree bases and the river bank
    const edge = o > 0 || hf.riverDist(x, z) < 4 || noise(x * 0.08, z * 0.08) > 0.45;
    if (!edge && rand() > 0.12) continue;
    grass.push({ x, z, y: hf.sample(x, z), s: 0.9 + rand() * 0.9, rot: rand() * 6.28 });
  }
  for (let i = 0; i < 600; i++) {
    const a = rand() * Math.PI * 2, r = 25 + Math.sqrt(rand()) * 140;
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (noise(x * 0.04, z * 0.04) < 0.15) continue;
    if (!free(x, z, 0.3) || hf.riverDist(x, z) < 1.5) continue;
    flowers.push({ x, z, y: hf.sample(x, z), s: 0.8 + rand() * 0.5 });
  }
  // mountain forests (no shadows, far away)
  const farPines = [];
  for (let i = 0; i < 9000; i++) {
    const a = rand() * Math.PI * 2, r = 214 + rand() * 380;
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    const y = baseHeight(x, z);
    const yx = baseHeight(x + 3, z), yz = baseHeight(x, z + 3);
    const slope = Math.hypot(yx - y, yz - y) / 3;
    if (slope > 1.35 || y > 110 + noise(x * 0.01, z * 0.01) * 25) continue;
    if (riverQuery(x, z, {}).d < 12) continue;
    farPines.push({ x, y, z, s: 3.4 + rand() * 2.4, rot: rand() * 6.28 });
  }

  // 9b. environmental enrichment: gardens, woodland floor, meadows, riverbanks, village life
  const enrich = enrichWorld({ footprints, hf, houses, lanes: allLanes, bridges, occ, rand, colliders, interactables, surfaces, villageDist, animated, packs: assets.packs || {}, reserved });
  root.add(enrich.root);

  root.add(buildTrees(trees));
  root.add(buildPines(assets.pine, pines));
  const far = buildPines(assets.pine, farPines, { castShadow: false });
  far.name = 'farPines';
  root.add(far);
  {
    // lawn and verge grass: short blade clumps in three greens (replaces the old rounded tufts)
    const byV = [[], [], []];
    grass.forEach((g, i) => byV[i % 3].push({ ...g, s: g.s * 1.1 }));
    byV.forEach((list, v) => root.add(scatter(grassTuft(v), list, { mat: 'grass', shadow: false, tile: 128, name: 'grass' })));
  }
  root.add(buildFlowers(flowers));

  // 10. sky and clouds
  const sky = buildSky();
  root.add(sky);
  const clouds = buildClouds();
  root.add(clouds);

  return {
    root, hf, houses, lanes: allLanes, bridges, colliders, surfaces, interactables, sky, clouds,
    update(t, dt) {
      timeUniform.value = t;
      for (const f of animated) f(t);
      clouds.userData.update(dt);
    },
    audit,
    stats: { reserved: Object.keys(reserved).join(','), assetTypes: Object.keys(enrich.counts).length, enrich: enrich.counts, houses: houses.length, trees: trees.length, pines: pines.length + farPines.length, rocks: rocks.length, grass: grass.length, flowers: flowers.length, bridges: bridges.length },
  };
}

// Coarse occupancy grid (1 m) so vegetation avoids paths, houses, the square and each other.
function makeOccupancy(hf, houses, lanes) {
  const S = 440, O = 220;
  const g = new Uint8Array(S * S);
  const set = (x, z, v) => { const i = Math.floor(x + O), j = Math.floor(z + O); if (i >= 0 && j >= 0 && i < S && j < S) g[j * S + i] = Math.max(g[j * S + i], v); };
  const disc = (x, z, r, v) => { for (let dz = -r; dz <= r; dz += 1) for (let dx = -r; dx <= r; dx += 1) if (dx * dx + dz * dz <= r * r) set(x + dx, z + dz, v); };
  for (const l of lanes) for (const s of l.samples) disc(s.x, s.z, l.w / 2 + 1.2, 1);
  disc(SQUARE.x, SQUARE.z, SQUARE.r + 1.5, 1);
  for (const h of houses) {
    for (let lz = -h.d / 2 - 1; lz <= h.d / 2 + h.wingD + 1.2; lz += 0.8) for (let lx = -h.w / 2 - 1; lx <= h.w / 2 + 1; lx += 0.8) {
      const [x, z] = h.toWorld(lx, lz); set(x, z, 3);
    }
  }
  return {
    get(x, z, pad = 0) {
      let m = 0;
      const r = Math.ceil(pad);
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        const i = Math.floor(x + dx + O), j = Math.floor(z + dz + O);
        if (i < 0 || j < 0 || i >= S || j >= S) continue;
        m = Math.max(m, g[j * S + i]);
      }
      return m;
    },
    mark(x, z, r) { disc(x, z, r, 2); },
  };
}

function fountainSpray(x, y, z) {
  const n = 220;
  const pos = new Float32Array(n * 3), seed = new Float32Array(n);
  for (let i = 0; i < n; i++) { pos[i * 3] = x; pos[i * 3 + 1] = y; pos[i * 3 + 2] = z; seed[i] = Math.random(); }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
  const mat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false,
    uniforms: { uTime: { value: 0 }, uTex: { value: softDot() } },
    vertexShader: `attribute float aSeed; uniform float uTime; varying float vA;
      void main(){ float t = fract(uTime*0.7 + aSeed); float a = aSeed*6.2831*7.0;
        vec3 p = position + vec3(cos(a)*t*1.6, t*1.8 - t*t*2.6, sin(a)*t*1.6);
        vA = 1.0 - t; vec4 mv = modelViewMatrix*vec4(p,1.0); gl_PointSize = 90.0*(0.4+aSeed*0.4)/-mv.z; gl_Position = projectionMatrix*mv; }`,
    fragmentShader: `uniform sampler2D uTex; varying float vA; void main(){ vec4 t = texture2D(uTex, gl_PointCoord); gl_FragColor = vec4(0.92,0.97,1.0, t.a*vA*0.75); }`,
  });
  const p = new THREE.Points(geo, mat);
  p.frustumCulled = false;
  return p;
}
