// Village props: picket fences, lamp posts, hanging domain signs, benches, mailboxes,
// the noticeboard and the square's fountain.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mat4 } from './batcher.js';
import { MAT } from './materials.js';

import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
const fenceWood = new THREE.MeshStandardMaterial({ color: '#c8a17a', roughness: 0.88, map: MAT.timber.map });
fenceWood.userData.boxUV = 1.0;
const fenceWhite = new THREE.MeshStandardMaterial({ color: '#f6f2ea', roughness: 0.8 });
const postMat = new THREE.MeshStandardMaterial({ color: '#76887f', roughness: 0.6, metalness: 0.2 });
const whitePaint = new THREE.MeshStandardMaterial({ color: '#f6f2ea', roughness: 0.7 });
// picket with a pointed top; post with a pyramid cap
const picket = mergeGeometries([
  new THREE.BoxGeometry(0.04, 0.78, 0.09).translate(0, -0.05, 0),
  new THREE.ConeGeometry(0.064, 0.12, 4).rotateY(Math.PI / 4).scale(0.45, 1, 1).translate(0, 0.4, 0),
].map((g) => g.toNonIndexed()));
const post = mergeGeometries([
  new THREE.BoxGeometry(0.13, 1.0, 0.13).translate(0, -0.05, 0),
  new THREE.BoxGeometry(0.17, 0.05, 0.17).translate(0, 0.47, 0),
  new THREE.ConeGeometry(0.11, 0.13, 4).rotateY(Math.PI / 4).translate(0, 0.56, 0),
].map((g) => g.toNonIndexed()));
const lampCap = new THREE.ConeGeometry(0.28, 0.25, 4);
const mailGeo = new RoundedBoxGeometry(1, 1, 1, 2, 0.15);
const unitBox = new THREE.BoxGeometry(1, 1, 1);
const cyl = new THREE.CylinderGeometry(1, 1, 1, 10);
const wallBlock = new RoundedBoxGeometry(1, 1, 1, 2, 0.08);
const ball = new THREE.IcosahedronGeometry(1, 2);

// Shared boundary walker: steps along a polyline, skips blocked ground (lanes, water, other buildings)
// and reports continuous runs, so every visible section gets exactly one matching collider.
function walkBoundary(hf, pts, step, blocked, onPiece, onRun) {
  const ok = (x, z) => !(hf.maskAt(x, z) & (1 | 8 | 16)) && hf.riverDist(x, z) > 1.2 && !(blocked && blocked(x, z));
  for (let i = 0; i < pts.length - 1; i++) {
    const [x0, z0] = pts[i], [x1, z1] = pts[i + 1];
    const len = Math.hypot(x1 - x0, z1 - z0);
    if (len < 0.05) continue;
    const ang = Math.atan2(x1 - x0, z1 - z0);
    const n = Math.max(1, Math.round(len / step));
    let run = null;
    const close = () => { if (run && run.b - run.a > 1e-3) onRun(run.ax, run.az, run.bx, run.bz, ang, Math.hypot(run.bx - run.ax, run.bz - run.az)); run = null; };
    for (let k = 0; k <= n; k++) {
      const t = k / n, x = x0 + (x1 - x0) * t, z = z0 + (z1 - z0) * t;
      if (!ok(x, z)) { close(); continue; }
      if (!run) run = { a: t, ax: x, az: z, b: t, bx: x, bz: z };
      run.b = t; run.bx = x; run.bz = z;
      onPiece(x, z, ang, k, n, len / n);
    }
    close();
  }
}

// Picket fence along a polyline of [x,z].
export function addFence(add, hf, pts, colliders, { white = false, blocked = null } = {}) {
  const wood = white ? fenceWhite : fenceWood;
  walkBoundary(hf, pts, 0.17, blocked, (x, z, ang, k, n) => {
    const y = hf.sample(x, z);
    if (k % 12 === 0 || k === n || k === 0) add(post, mat4(x, y + 0.5, z, 0, ang, 0), wood);
    else add(picket, mat4(x, y + 0.45 + (k % 2) * 0.015, z, 0, ang, 0), wood);
  }, (ax, az, bx, bz, ang, rl) => {
    if (rl < 0.25) return;
    for (const ry of [0.26, 0.62]) {
      const mx = (ax + bx) / 2, mz = (az + bz) / 2;
      const my = (hf.sample(ax, az) + hf.sample(bx, bz)) / 2;
      const tilt = Math.atan2(hf.sample(bx, bz) - hf.sample(ax, az), rl);
      add(unitBox, mat4(mx, my + ry, mz, 0, ang, 0).multiply(mat4(-0.05, 0, 0, -tilt, 0, 0, 0.04, 0.08, rl)), wood);
    }
    colliders.push({ x0: ax, z0: az, x1: bx, z1: bz, r: 0.12 });
  });
}

// A garden gate between two posts; the leaf is folded right back against the fence so the
// opening stays fully walkable.
export function addGate(add, hf, x, z, ang, white = false, gap = 1.9, colliders = null, stone = false) {
  const wood = white ? fenceWhite : fenceWood;
  const dx = Math.sin(ang), dz = Math.cos(ang);
  for (const s of [-1, 1]) {
    const px = x + dx * s * gap / 2, pz = z + dz * s * gap / 2, y = hf.sample(px, pz);
    if (stone) {
      // dressed stone piers to match a garden wall, with a capping stone and ball finial
      add(wallBlock, mat4(px + dx * s * 0.12, y + 0.5, pz + dz * s * 0.12, 0, ang, 0, 0.46, 1.3, 0.46), MAT.stone);
      add(wallBlock, mat4(px + dx * s * 0.12, y + 1.2, pz + dz * s * 0.12, 0, ang, 0, 0.56, 0.12, 0.56), MAT.stoneTrim);
      add(ball, mat4(px + dx * s * 0.12, y + 1.38, pz + dz * s * 0.12, 0, 0, 0, 0.14, 0.14, 0.14), MAT.stoneTrim);
      if (colliders) colliders.push({ x: px + dx * s * 0.12, z: pz + dz * s * 0.12, r: 0.3 });
      continue;
    }
    add(unitBox, mat4(px, y + 0.6, pz, 0, ang, 0, 0.18, 1.2, 0.18), wood);
    add(ball, mat4(px, y + 1.28, pz, 0, 0, 0, 0.1, 0.1, 0.1), wood);
    if (colliders) colliders.push({ x: px, z: pz, r: 0.14 });
  }
  // Two half-width leaves hung on the posts, opened outwards (towards the lane) and folded back flat
  // against the outside of the fence or wall: they never swing into the garden, the walkway arch or
  // the house, and a short leaf needs almost no room.
  const nx = Math.sin(ang - Math.PI / 2), nz = Math.cos(ang - Math.PI / 2); // outward, away from the house
  const off = stone ? 0.32 : 0.12; // clear of the wall face or the fence rails
  const lw = gap / 2 - 0.12;
  for (const s of [-1, 1]) {
    const px = x + dx * s * gap / 2 + nx * off, pz = z + dz * s * gap / 2 + nz * off, y = hf.sample(px, pz);
    // folded back ~165 degrees: lies along the fence line on the far side of its post, toed out slightly
    const vx = dx * s * Math.cos(0.2) + nx * Math.sin(0.2), vz = dz * s * Math.cos(0.2) + nz * Math.sin(0.2);
    const yaw = Math.atan2(-vz, vx);
    const L = (lx, ly, sx, sy, sz, rz = 0) => add(unitBox, mat4(px, y, pz, 0, yaw, 0).multiply(mat4(lx, ly, 0, 0, 0, rz, sx, sy, sz)), wood);
    L(lw / 2 + 0.06, 0.3, lw, 0.08, 0.05);
    L(lw / 2 + 0.06, 0.78, lw, 0.08, 0.05);
    const n = Math.max(3, Math.round(lw / 0.13));
    for (let i = 0; i < n; i++) L(0.12 + i * (lw - 0.08) / (n - 1), 0.52, 0.07, 0.8, 0.04);
    L(lw / 2 + 0.06, 0.54, 0.06, Math.hypot(lw, 0.48), 0.04, -Math.atan2(lw, 0.48));
  }
}

// Low dry-stone garden wall with rounded capping stones, stepping with the ground.
export function addStoneWall(add, hf, pts, colliders, { rand = Math.random, blocked = null } = {}) {
  walkBoundary(hf, pts, 1.0, blocked, (x, z, ang, k, n, seg) => {
    const y = hf.sample(x, z), hgt = 0.62 + rand() * 0.08;
    add(wallBlock, mat4(x, y + hgt / 2 - 0.15, z, 0, ang, 0, 0.46, hgt + 0.3, seg + 0.06), MAT.stone);
    add(wallBlock, mat4(x, y + hgt, z, 0, ang, 0, 0.56, 0.14, seg + 0.07), MAT.stoneTrim);
    if (rand() < 0.3) add(ball, mat4(x + (rand() - 0.5) * 0.2, y + hgt + 0.08, z, 0, 0, 0, 0.22, 0.08, 0.3), MAT.leafDark);
  }, (ax, az, bx, bz) => colliders.push({ x0: ax, z0: az, x1: bx, z1: bz, r: 0.3 }));
}

// Clipped hedge following the boundary, with a soft lumpy top.
export function addHedgeRow(add, hf, pts, colliders, { rand = Math.random, blocked = null } = {}) {
  walkBoundary(hf, pts, 0.9, blocked, (x, z, ang, k, n, seg) => {
    const y = hf.sample(x, z);
    add(wallBlock, mat4(x, y + 0.55, z, 0, ang, 0, 0.8, 1.1, seg + 0.14), k % 2 ? MAT.leafDark : MAT.hedge);
    add(ball, mat4(x + (rand() - 0.5) * 0.15, y + 1.08, z, 0, ang, 0, 0.42, 0.14, 0.55), MAT.hedge);
  }, (ax, az, bx, bz) => colliders.push({ x0: ax, z0: az, x1: bx, z1: bz, r: 0.42 }));
}

export function addLampPost(add, x, y, z) {
  add(cyl, mat4(x, y + 0.15, z, 0, 0, 0, 0.16, 0.3, 0.16), postMat);
  add(cyl, mat4(x, y + 1.6, z, 0, 0, 0, 0.06, 3.0, 0.06), postMat);
  add(cyl, mat4(x, y + 3.15, z, 0, 0, 0, 0.2, 0.08, 0.2), postMat);
  add(unitBox, mat4(x, y + 3.38, z, 0, Math.PI / 4, 0, 0.26, 0.4, 0.26), MAT.lamp);
  add(lampCap, mat4(x, y + 3.7, z, 0, Math.PI / 4, 0), postMat);
}

function signTexture(title) {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = '#f7f1e3';
  g.beginPath(); g.arc(128, 128, 124, 0, Math.PI * 2); g.fill();
  g.strokeStyle = '#6f9a5e'; g.lineWidth = 10;
  g.beginPath(); g.arc(128, 128, 108, 0, Math.PI * 2); g.stroke();
  g.fillStyle = '#4b5a4f';
  g.font = '600 34px Georgia, serif';
  g.textAlign = 'center'; g.textBaseline = 'middle';
  const words = title.split(' ');
  const lines = [];
  let line = '';
  for (const w of words) { if ((line + ' ' + w).trim().length > 11) { lines.push(line.trim()); line = w; } else line += ' ' + w; }
  lines.push(line.trim());
  lines.forEach((l, i) => g.fillText(l, 128, 128 + (i - (lines.length - 1) / 2) * 38));
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

// White post with a hanging round sign, as in the reference image. Returns a Group (sign swings).
export function makeHangingSign(title, x, y, z, rot) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = rot;
  const p = new THREE.Mesh(new RoundedBoxGeometry(0.16, 3.1, 0.16, 1, 0.04), whitePaint);
  p.position.y = 1.55; p.castShadow = true;
  const arm = new THREE.Mesh(new RoundedBoxGeometry(1.25, 0.12, 0.12, 1, 0.03), whitePaint);
  arm.position.set(0.58, 2.95, 0); arm.castShadow = true;
  const hang = new THREE.Group();
  hang.position.set(0.85, 2.88, 0);
  const tex = signTexture(title);
  const faceMat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.75 });
  // rim + two upright faces (text reads correctly from both sides)
  const disc = new THREE.Group();
  const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.06, 32, 1, true), whitePaint);
  rim.rotation.x = Math.PI / 2;
  rim.castShadow = true;
  disc.add(rim);
  for (const side of [1, -1]) {
    const face = new THREE.Mesh(new THREE.CircleGeometry(0.42, 32), faceMat);
    face.position.z = side * 0.03;
    if (side < 0) face.rotation.y = Math.PI;
    disc.add(face);
  }
  disc.position.y = -0.55;
  for (const s of [-1, 1]) {
    const chain = new THREE.Mesh(cyl, postMat);
    chain.scale.set(0.012, 0.16, 0.012);
    chain.position.set(s * 0.22, -0.08, 0);
    hang.add(chain);
  }
  hang.add(disc);
  g.add(p, arm, hang);
  g.userData.swing = hang;
  return g;
}

export function addBench(add, x, y, z, rot) {
  const f = (lx, ly, lz, sx, sy, sz, m) => add(unitBox, mat4(x, y, z, 0, rot, 0).multiply(mat4(lx, ly, lz, 0, 0, 0, sx, sy, sz)), m);
  for (const s of [-0.75, 0.75]) { f(s, 0.22, 0, 0.08, 0.44, 0.42, postMat); f(s, 0.62, -0.22, 0.08, 0.5, 0.06, postMat); }
  for (let i = 0; i < 3; i++) f(0, 0.46, -0.14 + i * 0.14, 1.7, 0.05, 0.11, MAT.wood);
  for (let i = 0; i < 2; i++) f(0, 0.66 + i * 0.16, -0.25, 1.7, 0.1, 0.04, MAT.wood);
}

export function addMailbox(add, x, y, z, rot) {
  const f = (lx, ly, lz, sx, sy, sz, m, g = unitBox) => add(g, mat4(x, y, z, 0, rot, 0).multiply(mat4(lx, ly, lz, 0, 0, 0, sx, sy, sz)), m);
  f(0, 0.5, 0, 0.1, 1.0, 0.1, MAT.wood);
  f(0, 1.08, 0, 0.36, 0.3, 0.5, whitePaint, mailGeo);
  f(0.2, 1.18, 0.12, 0.02, 0.18, 0.04, MAT.flowerRed);
}

export function addNoticeboard(add, x, y, z, rot) {
  const f = (lx, ly, lz, sx, sy, sz, m, g = unitBox) => add(g, mat4(x, y, z, 0, rot, 0).multiply(mat4(lx, ly, lz, 0, 0, 0, sx, sy, sz)), m);
  for (const s of [-1, 1]) f(s * 1.05, 1.1, 0, 0.14, 2.2, 0.14, MAT.woodDark);
  f(0, 1.35, 0, 2.0, 1.3, 0.08, MAT.wood);
  f(0, 1.35, 0.05, 1.8, 1.1, 0.02, new THREE.MeshStandardMaterial({ color: '#d9b98a', roughness: 0.95 }));
  const notes = ['#fffaf0', '#f9e7a6', '#d8ecf7', '#fde2e2', '#fffaf0'];
  notes.forEach((c, i) => f(-0.6 + i * 0.3, 1.25 + (i % 2) * 0.3, 0.07, 0.24, 0.32, 0.01, new THREE.MeshStandardMaterial({ color: c, roughness: 0.9 })));
  f(0, 2.3, 0, 2.5, 0.12, 0.7, MAT.roof_terracotta);
}
