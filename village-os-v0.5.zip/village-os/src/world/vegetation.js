// Trees, bushes, grass and flowers. Custom soft "stacked" trees match the reference;
// Kenney's CC0 pine and grass tufts fill the forests and lawns. Everything is instanced and sways.
import * as THREE from 'three';
import { mergeGeometries, mergeVertices, deinterleaveAttribute } from 'three/addons/utils/BufferGeometryUtils.js';
import { mulberry32, makeNoise2D } from '../core/math.js';
import { MAT } from './materials.js';
import { SimplifyModifier } from 'three/addons/modifiers/SimplifyModifier.js';

export const timeUniform = { value: 0 };

// Adds wind sway to a material (works for instanced and plain meshes).
export function addSway(mat, base = 0.5, amp = 0.035) {
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = timeUniform;
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nuniform float uTime;')
      .replace('#include <begin_vertex>', `#include <begin_vertex>
        #ifdef USE_INSTANCING
          vec3 ip = vec3(instanceMatrix[3][0], instanceMatrix[3][1], instanceMatrix[3][2]);
        #else
          vec3 ip = vec3(modelMatrix[3][0], modelMatrix[3][1], modelMatrix[3][2]);
        #endif
        float sw = max(0.0, position.y - ${base.toFixed(2)}) * ${amp.toFixed(3)};
        transformed.x += sin(uTime*1.3 + ip.x*0.31 + ip.z*0.17) * sw;
        transformed.z += cos(uTime*1.05 + ip.x*0.13 + ip.z*0.29) * sw * 0.7;`);
  };
  mat.customProgramCacheKey = () => 'sway' + base + amp;
  return mat;
}

function tieredCanopy(tiers, height, radius) {
  // envelope of stacked ellipsoids -> soft "dollop" tiers like the reference
  const pts = [];
  const yMin = tiers[0].c - tiers[0].h, yMax = tiers[tiers.length - 1].c + tiers[tiers.length - 1].h;
  const N = 34;
  for (let i = 0; i <= N; i++) {
    const y = yMin + (yMax - yMin) * (i / N);
    let r = 0;
    for (const t of tiers) {
      const q = 1 - ((y - t.c) / t.h) ** 2;
      if (q > 0) r = Math.max(r, t.R * Math.pow(q, 0.55));
    }
    pts.push(new THREE.Vector2(Math.max(r * radius, i === 0 || i === N ? 0 : 0.02), (y - yMin) * height));
  }
  const g = new THREE.LatheGeometry(pts, 16);
  return g;
}

function blobCanopy(rand, count, spread, rMin, rMax, flat = 1) {
  const geos = [];
  for (let i = 0; i < count; i++) {
    const r = rMin + rand() * (rMax - rMin);
    const s = new THREE.IcosahedronGeometry(r, 2);
    const a = rand() * Math.PI * 2, d = i === 0 ? 0 : spread * (0.55 + rand() * 0.45);
    s.scale(1, flat, 1);
    s.translate(Math.cos(a) * d, r * 0.9 + (i === 0 ? spread * 0.6 : rand() * spread * 0.8) * flat, Math.sin(a) * d);
    geos.push(s);
  }
  return mergeGeometries(geos.map((x) => { x.deleteAttribute('uv'); return x; }));
}

// Lumpy organic volume: an icosphere displaced by noise (keeps smooth shading).
function lumpy(rx, ry, rz, amp, seed, detail = 3) {
  const n = makeNoise2D(seed);
  let g = new THREE.IcosahedronGeometry(1, detail);
  g.deleteAttribute('uv'); g.deleteAttribute('normal');
  g = mergeVertices(g);
  const p = g.attributes.position, v = new THREE.Vector3();
  for (let i = 0; i < p.count; i++) {
    v.fromBufferAttribute(p, i);
    const d = 1 + amp * (n(v.x * 2.1 + v.y, v.z * 2.1 - v.y) * 0.7 + n(v.x * 4.3, v.z * 4.3 + v.y * 3) * 0.3);
    p.setXYZ(i, v.x * rx * d, v.y * ry * d, v.z * rz * d);
  }
  g.computeVertexNormals();
  return g;
}

// Foliage shading baked into vertex colours: darker, cooler undersides and interiors,
// lighter sunlit crowns, and a slight per-volume tonal shift so canopies read as layered.
function shadeFoliage(g, rand, { hue = 0 } = {}) {
  if (g.index) g = g.toNonIndexed();
  g.computeBoundingBox();
  const b = g.boundingBox, p = g.attributes.position, n = g.attributes.normal;
  const col = new Float32Array(p.count * 3);
  const c = new THREE.Color();
  const cx = (b.min.x + b.max.x) / 2, cz = (b.min.z + b.max.z) / 2, rad = Math.max(b.max.x - b.min.x, b.max.z - b.min.z) / 2 || 1;
  // jitter per triangle-cluster (every 60 verts ~ one lump region) for tonal variety
  let jitter = 0;
  for (let i = 0; i < p.count; i++) {
    if (i % 240 === 0) jitter = (rand() - 0.5) * 0.08;
    const t = (p.getY(i) - b.min.y) / (b.max.y - b.min.y || 1);
    const radial = Math.min(1, Math.hypot(p.getX(i) - cx, p.getZ(i) - cz) / rad);
    let l = 0.72 + 0.34 * t + 0.08 * radial + jitter;
    l += Math.max(0, n.getY(i)) * 0.06 - Math.max(0, -n.getY(i)) * 0.1;
    c.setRGB(l * (1 - hue * 0.04), l, l * (1 + hue * 0.03));
    col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
  }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  return g;
}

function trunkWithBranches(rand, { h = 1.8, r0 = 0.27, r1 = 0.17, branches = 0, spread = 1, lean = 0 }) {
  const parts = [];
  const t = new THREE.CylinderGeometry(r1, r0, h, 9);
  t.translate(0, h / 2, 0);
  if (lean) t.rotateZ(lean);
  parts.push(t);
  for (let i = 0; i < branches; i++) {
    const a = (i / branches) * Math.PI * 2 + rand() * 0.8, len = 0.9 + rand() * 0.8 * spread;
    const b = new THREE.CylinderGeometry(r1 * 0.35, r1 * 0.7, len, 6);
    b.translate(0, len / 2, 0);
    b.rotateZ(0.7 + rand() * 0.35);
    b.rotateY(a);
    b.translate(0, h * (0.75 + rand() * 0.2), 0);
    parts.push(b);
  }
  return mergeGeometries(parts.map((x) => { x.deleteAttribute('uv'); return x; }));
}


// Branching trees: a gently bent trunk, main limbs at varied heights and angles, secondary limbs, and
// irregular leaf clumps at the limb ends. Gaps between clumps show the branches, so every tree has its
// own organic silhouette instead of a uniform fluffy ball.
const _up = new THREE.Vector3(0, 1, 0), _q = new THREE.Quaternion();
export function growTree(r, P) {
  const { H = 4, trunkR = 0.26, nMain = 5, pitch = [0.5, 0.9], len = [1.4, 2], start = [0.5, 0.85], clump = [0.9, 1.3], flat = 0.8, leader = true, second = 1, topClump = 1, lean = 0.12 } = P;
  const wood = [], clumps = [];
  const seg = (a, b, r0, r1) => {
    const d = b.clone().sub(a), L = d.length();
    const g = new THREE.CylinderGeometry(r1, r0, L, 6);
    g.translate(0, L / 2, 0);
    g.applyQuaternion(_q.setFromUnitVectors(_up, d.normalize()));
    g.translate(a.x, a.y, a.z);
    wood.push(g);
  };
  const lerp = (a, b, t) => a + (b - a) * t;
  // trunk: three gently bent segments
  const la = r() * Math.PI * 2, lt = r() * lean;
  const T = [new THREE.Vector3(0, 0, 0)];
  for (let i = 1; i <= 3; i++) T.push(new THREE.Vector3(Math.cos(la) * lt * i * 0.5 + (r() - 0.5) * 0.12, H * (i / 3), Math.sin(la) * lt * i * 0.5 + (r() - 0.5) * 0.12));
  for (let i = 0; i < 3; i++) seg(T[i], T[i + 1], trunkR * (1 - i * 0.25), trunkR * (1 - (i + 1) * 0.25) + 0.03);
  const onTrunk = (h) => { const t = Math.min(0.999, h / H) * 3, i = Math.floor(t); return T[i].clone().lerp(T[i + 1], t - i); };
  const golden = 2.39996;
  const a0 = r() * 6.28;
  for (let i = 0; i < nMain; i++) {
    const f = nMain > 1 ? i / (nMain - 1) : 0.5;
    const h = H * Math.min(0.97, lerp(start[0], start[1], f) + (r() - 0.5) * 0.06);
    const base = onTrunk(h);
    const az = a0 + i * golden + (r() - 0.5) * 0.5;
    const pt = lerp(pitch[1], pitch[0], f) + (r() - 0.5) * 0.15; // lower limbs spread wider
    const L = lerp(len[0], len[1], r()) * (1.15 - f * 0.3);
    const dir = new THREE.Vector3(Math.sin(pt) * Math.cos(az), Math.cos(pt), Math.sin(pt) * Math.sin(az));
    const mid = base.clone().addScaledVector(dir, L * 0.55);
    const tip = base.clone().addScaledVector(dir, L).add(new THREE.Vector3(0, L * 0.12, 0)); // limbs curve upward
    const rb = trunkR * (0.55 - f * 0.2);
    seg(base, mid, rb, rb * 0.7);
    seg(mid, tip, rb * 0.7, rb * 0.4);
    const cr = lerp(clump[0], clump[1], r());
    clumps.push([tip, cr]);
    for (let k = 0; k < second; k++) {
      const s2 = az + (k % 2 ? 1 : -1) * (0.6 + r() * 0.5);
      const d2 = new THREE.Vector3(Math.sin(pt + 0.2) * Math.cos(s2), Math.cos(pt + 0.2) + 0.25, Math.sin(pt + 0.2) * Math.sin(s2)).normalize();
      const t2 = mid.clone().addScaledVector(d2, L * (0.4 + r() * 0.2));
      seg(mid, t2, rb * 0.5, rb * 0.25);
      clumps.push([t2, cr * (0.65 + r() * 0.2)]);
    }
  }
  if (leader) {
    const top = T[3].clone().add(new THREE.Vector3((r() - 0.5) * 0.3, 0.5, (r() - 0.5) * 0.3));
    seg(T[3], top, trunkR * 0.3, trunkR * 0.15);
    for (let k = 0; k < topClump; k++) clumps.push([top.clone().add(new THREE.Vector3((r() - 0.5) * 0.6, k * 0.7, (r() - 0.5) * 0.6)), lerp(clump[0], clump[1], r()) * (1 - k * 0.2)]);
  }
  // a fuller inner mass behind the limb-end clumps so the crown reads as one tree, still with an uneven edge
  const cen = clumps.reduce((a, [c]) => a.add(c), new THREE.Vector3()).multiplyScalar(1 / clumps.length);
  const avg = clumps.reduce((a, [, cr]) => a + cr, 0) / clumps.length;
  const ext = Math.max(...clumps.map(([c]) => Math.hypot(c.x - cen.x, c.z - cen.z)));
  clumps.push([cen.clone().add(new THREE.Vector3(0, -avg * 0.1, 0)), Math.max(avg * 1.1, ext * 0.62)]);
  if (P.parts) return { clumps: clumps.map(([c, cr], i) => lumpy(cr * (0.9 + r() * 0.2), cr * flat * (0.85 + r() * 0.3), cr * (0.9 + r() * 0.2), 0.32, 900 + i * 17 + r() * 999, cr > 1.2 ? 2 : 1).rotateY(r() * 6.28).translate(c.x, c.y + cr * flat * 0.3, c.z)), wood, tips: clumps };
  const leaves = clumps.map(([c, cr], i) => lumpy(cr * (0.9 + r() * 0.2), cr * flat * (0.85 + r() * 0.3), cr * (0.9 + r() * 0.2), 0.32, 700 + i * 13 + r() * 999, cr > 1.2 ? 2 : 1)
    .rotateY(r() * 6.28).translate(c.x, c.y + cr * flat * 0.3, c.z));
  return { canopy: mergeGeometries(leaves), trunk: mergeGeometries(wood.map((g) => { g.deleteAttribute('uv'); return g; })) };
}
const grown = new Map();
const branchy = (name, P) => [(r, v) => { const t = growTree(r, P); grown.set(name + v, t); return t.canopy; }, (r, v) => grown.get(name + v).trunk];

let kindsCache = null;
export function makeTreeKinds() {
  if (kindsCache) return kindsCache;
  const rand = mulberry32(77);
  const trunkMat = new THREE.MeshStandardMaterial({ color: '#b0907a', roughness: 0.92, map: MAT.timber.map });
  const leafMat = addSway(new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.86, vertexColors: true }), 0.4, 0.03);
  const plainTrunk = trunkWithBranches(rand, {});
  const kinds = {};
  const V = 3; // geometry variants per species
  const add = (name, makeCanopy, makeTrunk, colours, hue = 0) => {
    kinds[name] = { variants: [], colours: colours.map((c) => new THREE.Color(c)) };
    for (let v = 0; v < V; v++) {
      const r = mulberry32(1000 + v * 97 + name.length * 7);
      const canopy = shadeFoliage(makeCanopy(r, v), r, { hue });
      kinds[name].variants.push({ canopy, low: lowPoly(canopy), trunk: makeTrunk ? makeTrunk(r, v) : null });
    }
  };
  const LEAF = ['#b3d696', '#c0dea3', '#a6cf8e', '#cbe4af', '#9cc889', '#bcdcaa'];
  add('tiered', ...branchy('maple', { H: 3.6, nMain: 5, pitch: [0.55, 0.95], len: [1.3, 1.9], start: [0.5, 0.85], clump: [0.85, 1.2], flat: 0.8 }), LEAF);
  add('tieredTall', ...branchy('ash', { H: 5.2, trunkR: 0.24, nMain: 6, pitch: [0.35, 0.75], len: [1.3, 2.0], start: [0.45, 0.9], clump: [0.75, 1.05], flat: 0.85, topClump: 2 }), LEAF);
  add('round', ...branchy('apple', { H: 2.2, trunkR: 0.2, nMain: 4, pitch: [0.8, 1.1], len: [1.0, 1.4], start: [0.75, 0.95], clump: [0.7, 0.95], flat: 0.75, second: 1 }), LEAF);
  add('oak', ...branchy('oak', { H: 3.0, trunkR: 0.4, nMain: 6, pitch: [0.85, 1.25], len: [1.9, 2.8], start: [0.6, 0.9], clump: [0.95, 1.35], flat: 0.68, second: 2, lean: 0.2 }), ['#a9cc8e', '#9fc488', '#b2d196', '#a3c78f'], 0.5);
  add('linden', ...branchy('linden', { H: 4.4, trunkR: 0.3, nMain: 7, pitch: [0.45, 0.8], len: [1.2, 1.8], start: [0.4, 0.9], clump: [0.95, 1.25], flat: 0.95, topClump: 2 }), ['#bcdca0', '#c6e2aa', '#b5d79a']);
  add('poplar', ...branchy('poplar', { H: 6.5, trunkR: 0.22, nMain: 8, pitch: [0.18, 0.34], len: [0.8, 1.2], start: [0.25, 0.95], clump: [0.55, 0.75], flat: 1.5, second: 0, topClump: 2, lean: 0.05 }), ['#c9dc96', '#bfd890', '#c4dc9e']);
  // fir: stacked, drooping branch skirts with jagged, irregular edges and a leader tip
  add('spruce', (r) => {
    const n = 6 + Math.floor(r() * 3), H = 7 + r() * 2.2, base = 0.9;
    const pos = [];
    for (let i = 0; i < n; i++) {
      const t = i / n, R = 1.75 * (1 - t * 0.82) * (0.92 + r() * 0.16);
      const y0 = base + t * (H - base - 0.6), y1 = y0 + (H - base) / n * 1.55;
      const lobes = 7 + Math.floor(r() * 3), N = lobes * 2, rot = r() * 6.28;
      const ring = [];
      for (let k = 0; k < N; k++) {
        const a = rot + (k / N) * Math.PI * 2, tip = k % 2 === 0;
        const rr = R * (tip ? 0.95 + r() * 0.2 : 0.62 + r() * 0.12);
        ring.push([Math.cos(a) * rr, y0 - (tip ? 0.18 + r() * 0.12 : 0.02), Math.sin(a) * rr]);
      }
      for (let k = 0; k < N; k++) {
        const p0 = ring[k], p1 = ring[(k + 1) % N];
        pos.push(0, y1, 0, ...p1, ...p0); // upper surface
        pos.push(0, y0 + 0.22, 0, ...p0, ...p1); // underside
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.computeVertexNormals();
    return g;
  }, (r) => trunkWithBranches(r, { h: 2.2, r0: 0.25, r1: 0.12 }), ['#9dbfa5', '#93b79c', '#a6c4a9'], -0.6);
  add('bush', (r) => blobCanopy(r, 3 + Math.floor(r() * 3), 0.45 + r() * 0.15, 0.4, 0.62, 0.85).translate(0, -0.22, 0), null, LEAF);
  return kindsCache = { trunkMat, leafMat, kinds };
}

// Far-distance canopy: the same silhouette and vertex shading at roughly a third of the triangles.
const simplifier = new SimplifyModifier();
function lowPoly(g) {
  try {
    const src = mergeVertices(g.index ? g : g, 1e-4);
    const n = src.attributes.position.count;
    const low = simplifier.modify(src, Math.floor(n * 0.62));
    low.computeVertexNormals();
    return low.attributes.position.count > 12 ? low : g;
  } catch (e) { return g; }
}

// instances: [{kind, x, y, z, s, rot, v?}]
// Each tile is a THREE.LOD: full canopies near the camera, simplified canopies without shadow casting beyond.
const TREE_LOD_DIST = 115;
function buildTreesTile(instances) {
  const cx = instances.reduce((a, it) => a + it.x, 0) / instances.length, cz = instances.reduce((a, it) => a + it.z, 0) / instances.length;
  const lod = new THREE.LOD();
  lod.name = 'trees';
  lod.position.set(cx, 0, cz);
  const hi = buildTreesLevel(instances, false); hi.position.set(-cx, 0, -cz);
  const lo = buildTreesLevel(instances, true); lo.position.set(-cx, 0, -cz);
  lod.addLevel(hi, 0);
  lod.addLevel(lo, TREE_LOD_DIST);
  return lod;
}
function buildTreesLevel(instances, far) {
  const { trunkMat, leafMat, kinds } = makeTreeKinds();
  const group = new THREE.Group();
  group.name = 'trees';
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), p = new THREE.Vector3(), s = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0);
  const rand = mulberry32(5);
  const buckets = new Map();
  for (const it of instances) {
    const k = kinds[it.kind] || kinds.round;
    const v = it.v ?? Math.floor(((Math.abs(it.x * 13.7 + it.z * 7.3)) % 1000) / 1000 * k.variants.length);
    const key = (kinds[it.kind] ? it.kind : 'round') + ':' + v;
    if (!buckets.has(key)) buckets.set(key, { k, v: k.variants[v], items: [] });
    buckets.get(key).items.push(it);
  }
  const c = new THREE.Color();
  for (const { k, v, items } of buckets.values()) {
    const mesh = new THREE.InstancedMesh(far ? v.low : v.canopy, leafMat, items.length);
    const tr = v.trunk ? new THREE.InstancedMesh(v.trunk, trunkMat, items.length) : null;
    items.forEach((it, i) => {
      q.setFromAxisAngle(up, it.rot);
      p.set(it.x, it.y, it.z);
      s.set(it.s * (0.9 + rand() * 0.2), it.s * (0.88 + rand() * 0.24), it.s * (0.9 + rand() * 0.2));
      m.compose(p, q, s);
      mesh.setMatrixAt(i, m);
      c.copy(k.colours[Math.floor(rand() * k.colours.length)]);
      c.offsetHSL((rand() - 0.5) * 0.02, (rand() - 0.5) * 0.06, (rand() - 0.5) * 0.04);
      if (it.dark) c.multiplyScalar(0.85);
      mesh.setColorAt(i, c);
      if (tr) tr.setMatrixAt(i, m);
    });
    mesh.castShadow = !far; mesh.receiveShadow = true;
    mesh.computeBoundingSphere();
    group.add(mesh);
    if (tr) { tr.castShadow = !far; tr.receiveShadow = true; tr.computeBoundingSphere(); group.add(tr); }
  }
  return group;
}

// Kenney pine (CC0): instanced from the GLB's meshes.
const pineCache = new WeakMap();
function pineParts(gltf) {
  if (pineCache.has(gltf)) return pineCache.get(gltf);
  const parts = [];
  gltf.scene.updateMatrixWorld(true);
  gltf.scene.traverse((o) => {
    if (!o.isMesh) return;
    // smooth the faceted normals so the asset sits with the soft, rounded village style
    let geo = new THREE.BufferGeometry();
    for (const [name, attr] of Object.entries(o.geometry.attributes)) if (name !== 'normal') geo.setAttribute(name, attr.isInterleavedBufferAttribute ? deinterleaveAttribute(attr) : attr.clone());
    if (o.geometry.index) geo.setIndex(o.geometry.index.clone());
    geo.applyMatrix4(o.matrixWorld);
    geo = mergeVertices(geo, 1e-3);
    geo.computeVertexNormals();
    const mat = addSway(o.material.clone(), 0.6, 0.02);
    mat.roughness = 0.85;
    if (mat.map) mat.map = pastelTexture(mat.map); // soften the asset's saturated teal into sage
    parts.push({ geo, mat });
  });
  pineCache.set(gltf, parts);
  return parts;
}

function buildPinesTile(gltf, instances, { castShadow = true } = {}) {
  const group = new THREE.Group();
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), p = new THREE.Vector3(), s = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0);
  const rand = mulberry32(11);
  const tints = ['#ffffff', '#e8f5e0', '#d9ecd0', '#f2fbe9'].map((c) => new THREE.Color(c));
  for (const { geo, mat } of pineParts(gltf)) {
    const mesh = new THREE.InstancedMesh(geo, mat, instances.length);
    instances.forEach((it, i) => {
      q.setFromAxisAngle(up, it.rot);
      p.set(it.x, it.y - 0.1, it.z);
      s.setScalar(it.s);
      m.compose(p, q, s);
      mesh.setMatrixAt(i, m);
      mesh.setColorAt(i, tints[Math.floor(rand() * tints.length)]);
    });
    mesh.castShadow = castShadow;
    mesh.receiveShadow = true;
    mesh.computeBoundingSphere();
    group.add(mesh);
  }
  return group;
}

// Kenney grass tufts (CC0), recoloured to the lawn palette.
const grassCache = new WeakMap();
function grassParts(gltf) {
  if (grassCache.has(gltf)) return grassCache.get(gltf);
  const parts = [];
  gltf.scene.updateMatrixWorld(true);
  gltf.scene.traverse((o) => {
    if (!o.isMesh) return;
    const geo = o.geometry.clone().applyMatrix4(o.matrixWorld);
    const mat = addSway(new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.9 }), 0.0, 0.25);
    parts.push({ geo, mat });
  });
  grassCache.set(gltf, parts);
  return parts;
}

function buildGrassTile(gltfs, instances) {
  const group = new THREE.Group();
  const cols = ['#b4d99a', '#c3e0a8', '#a9d18f', '#cfe6b2'].map((c) => new THREE.Color(c));
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), p = new THREE.Vector3(), s = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0);
  const rand = mulberry32(19);
  gltfs.forEach((gltf, gi) => {
    const list = instances.filter((_, i) => i % gltfs.length === gi);
    if (!list.length) return;
    for (const { geo, mat } of grassParts(gltf)) {
      const mesh = new THREE.InstancedMesh(geo, mat, list.length);
      list.forEach((it, i) => {
        q.setFromAxisAngle(up, it.rot);
        p.set(it.x, it.y - 0.03, it.z);
        s.setScalar(it.s);
        m.compose(p, q, s);
        mesh.setMatrixAt(i, m);
        mesh.setColorAt(i, cols[Math.floor(rand() * cols.length)]);
      });
      mesh.receiveShadow = true;
      mesh.computeBoundingSphere();
      group.add(mesh);
    }
  });
  return group;
}

// Flower clumps: a small leafy mound dotted with blossoms.
const blossom = new THREE.IcosahedronGeometry(0.1, 1);
const mound = new THREE.IcosahedronGeometry(0.32, 2).scale(1, 0.55, 1);
let blossomMat, moundMat;
function buildFlowersTile(instances) {
  const group = new THREE.Group();
  const rand = mulberry32(31);
  blossomMat ??= addSway(new THREE.MeshStandardMaterial({ color: '#fff', roughness: 0.7 }), 0, 0.2);
  moundMat ??= new THREE.MeshStandardMaterial({ color: '#8fbb7e', roughness: 0.9 });
  const bm = new THREE.InstancedMesh(blossom, blossomMat, instances.length * 7);
  const mm = new THREE.InstancedMesh(mound, moundMat, instances.length);
  const palettes = [['#f2b6c8', '#fbe6ec'], ['#fbf6ee', '#f4dd8c'], ['#eda98f', '#f8d2c2'], ['#c4b0e6', '#f1eafb'], ['#b7d1ec', '#f4f8fd']].map((p) => p.map((c) => new THREE.Color(c)));
  const m = new THREE.Matrix4();
  let bi = 0;
  instances.forEach((it, i) => {
    m.makeScale(it.s, it.s, it.s).setPosition(it.x, it.y + 0.05, it.z);
    mm.setMatrixAt(i, m);
    const pal = palettes[Math.floor(rand() * palettes.length)];
    for (let k = 0; k < 7; k++) {
      const a = rand() * Math.PI * 2, r = rand() * 0.3 * it.s;
      m.makeScale(it.s, it.s, it.s).setPosition(it.x + Math.cos(a) * r, it.y + 0.18 * it.s + rand() * 0.08, it.z + Math.sin(a) * r);
      bm.setMatrixAt(bi, m);
      bm.setColorAt(bi, pal[k % 3 === 0 ? 1 : 0]);
      bi++;
    }
  });
  bm.count = bi;
  bm.computeBoundingSphere(); mm.computeBoundingSphere();
  mm.receiveShadow = true;
  group.add(mm, bm);
  return group;
}

// Spatial tiles so frustum culling (camera and sun shadow camera) can skip whole groups.
function tiled(instances, size, build, name) {
  const tiles = new Map();
  for (const it of instances) {
    const k = Math.floor(it.x / size) + ',' + Math.floor(it.z / size);
    if (!tiles.has(k)) tiles.set(k, []);
    tiles.get(k).push(it);
  }
  const g = new THREE.Group();
  g.name = name;
  for (const list of tiles.values()) g.add(build(list));
  return g;
}
export const buildTrees = (instances) => tiled(instances, 72, buildTreesTile, 'trees');
export const buildPines = (gltf, instances, opts) => tiled(instances, opts?.castShadow === false ? 160 : 48, (l) => buildPinesTile(gltf, l, opts), 'pines');
export const buildGrass = (gltfs, instances) => tiled(instances, 40, (l) => buildGrassTile(gltfs, l), 'grass');
export const buildFlowers = (instances) => tiled(instances, 48, buildFlowersTile, 'flowers');

// Regrade a palette texture in place (canvas) towards the pastel world: lower saturation, lift darks,
// shift greens slightly towards sage.
const pastelCache = new WeakMap();
export function pastelTexture(tex) {
  if (pastelCache.has(tex)) return pastelCache.get(tex);
  const img = tex.image;
  if (!img || !img.width) return tex;
  const c = document.createElement('canvas');
  c.width = img.width; c.height = img.height;
  const g = c.getContext('2d');
  g.drawImage(img, 0, 0);
  const d = g.getImageData(0, 0, c.width, c.height);
  const col = new THREE.Color();
  const hsl = {};
  for (let i = 0; i < d.data.length; i += 4) {
    col.setRGB(d.data[i] / 255, d.data[i + 1] / 255, d.data[i + 2] / 255, THREE.SRGBColorSpace);
    col.getHSL(hsl, THREE.SRGBColorSpace);
    let h = hsl.h;
    if (h > 0.25 && h < 0.5) h = h * 0.75 + 0.3 * 0.25; // teal-green -> sage-green
    col.setHSL(h, hsl.s * 0.42, 0.3 + hsl.l * 0.66, THREE.SRGBColorSpace);
    const out = col.getStyle(THREE.SRGBColorSpace).match(/[\d.]+/g).map(Number);
    d.data[i] = out[0]; d.data[i + 1] = out[1]; d.data[i + 2] = out[2];
  }
  g.putImageData(d, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.flipY = tex.flipY;
  t.magFilter = tex.magFilter; t.minFilter = tex.minFilter;
  t.wrapS = tex.wrapS; t.wrapT = tex.wrapT;
  pastelCache.set(tex, t);
  return t;
}
