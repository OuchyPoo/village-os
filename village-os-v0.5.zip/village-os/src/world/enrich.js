// Environmental enrichment: places the asset library through the valley so each area has its own
// character. Woodland is layered, meadows drift with wildflowers, gardens overflow, the square is
// busy with market life and the riverbanks are full of reeds, lilies and pebbles.
import * as THREE from 'three';
import { noise, smoothstep } from '../core/math.js';
import { SQUARE, LANES, forestPatch } from './layout.js';
import { samples, waterLevel, halfWidth, rapidness, CASCADES } from './river.js';
import { scatter, scatterGLTF, kit, M, G, kitMaterial } from './kit.js';
import * as A from './assets.js';
import { PAL } from './assets.js';
import { Batcher, mat4 } from './batcher.js';
import { MAT } from './materials.js';
import { planHouse, buildHouse } from './buildings.js';
import { Footprints, footprintGround } from './placement.js';
import { insects } from './insects.js';

// Reserve ground for landmarks before trees are scattered, so forests grow around them.
export function reserveSpots({ hf, occ, rand, villageDist }) {
  const R = {};
  const okArea = (x, z, rad, maxSlope) => {
    for (let k = 0; k <= 12; k++) {
      const b = (k / 12) * 6.28, d = k === 12 ? 0 : rad;
      const px = x + Math.cos(b) * d, pz = z + Math.sin(b) * d;
      if (hf.maskAt(px, pz) & (1 | 2 | 8 | 16) || hf.riverDist(px, pz) < 2 || hf.slope(px, pz) > maxSlope || occ.get(px, pz, 0) === 3) return false;
    }
    return true;
  };
  const claim = (x, z, r) => { for (let a = 0; a < 6.28; a += 0.4) for (let d = 0; d <= r; d += 1) occ.mark(x + Math.cos(a) * d, z + Math.sin(a) * d, 1); };
  // watermill on the east bank of the calm stretch below the second falls
  const zs = []; for (let z = 104; z <= 126; z += 2) zs.push(z, 208 - z);
  for (const zTry of zs) {
    if (R.mill) break;
    const s = samples.reduce((b, p) => (Math.abs(p.z - zTry) < Math.abs(b.z - zTry) ? p : b));
    const hw = halfWidth(s.z), nx = -s.tz, nz = s.tx;
    for (const side of [1, -1]) {
      const x = s.x + nx * side * (hw + 5.6), z = s.z + nz * side * (hw + 5.6);
      if (!okArea(x, z, 3.2, 0.9)) continue;
      R.mill = { x, z, s, side }; claim(x, z, 6); break;
    }
  }
  for (let t = 0; t < 2000 && !R.windmill; t++) {
    const a = rand() * 6.28, d = 60 + rand() * 80, x = Math.cos(a) * d, z = Math.sin(a) * d;
    if (forestPatch(x, z) > 0.3 || villageDist(x, z) < 45 || hf.riverDist(x, z) < 12 || !okArea(x, z, 5, 0.45)) continue;
    R.windmill = { x, z }; claim(x, z, 9);
  }
  R.market = [];
  for (let t = 0; t < 1500 && R.market.length < 3; t++) {
    const a = rand() * 6.28, d = SQUARE.r + 5 + rand() * 12;
    const x = SQUARE.x + Math.cos(a) * d, z = SQUARE.z + Math.sin(a) * d;
    if (!okArea(x, z, 2.6, 0.3) || R.market.some((m) => Math.hypot(m.x - x, m.z - z) < 6.5)) continue;
    R.market.push({ x, z }); claim(x, z, 3.5);
  }
  for (const [cx, cz, key, rad] of [[70, -40, 'orchard', 14], [-70, 70, 'hay', 12]]) {
    for (let t = 0; t < 1500 && !R[key]; t++) {
      const a = rand() * 6.28, d = rand() * 50, x = cx + Math.cos(a) * d, z = cz + Math.sin(a) * d;
      if (!okArea(x, z, rad, 0.4) || (R.windmill && Math.hypot(R.windmill.x - x, R.windmill.z - z) < rad + 12)) continue;
      R[key] = { x, z }; claim(x, z, rad);
    }
  }
  return R;
}

export function enrichWorld(ctx) {
  const { hf, houses, lanes, bridges, occ, rand, colliders, interactables, surfaces, villageDist, animated, packs = {} } = ctx;
  const root = new THREE.Group();
  root.name = 'enrichment';
  const LOW = typeof location !== 'undefined' && new URLSearchParams(location.search).get('quality') === 'low';
  const dens = LOW ? 0.4 : 1; // ground clutter density
  const PLANT = { mat: 'sway', shadow: true };
  const LOWP = { mat: 'sway', shadow: false };
  const BLADES = { mat: 'grass', shadow: false };
  const PROP = { mat: 'solid', shadow: true };
  const TREE = { mat: 'swayTree', shadow: true };
  const sets = new Map();
  const counts = {};
  // Solid props never stand on a lane, walkway, the square's lane corridors or a bridge: anything a
  // visitor would expect to walk through stays clear, and the matching collider is skipped too.
  const onWalk = (x, z) => (hf.maskAt(x, z) & (1 | 16)) !== 0;
  const isSolid = (opts) => opts === PROP || (opts.mat === 'solid' && opts.shadow !== false) || (opts.mat === undefined && !opts.sway);
  // Every item is checked against the footprints of everything solid placed before it (houses, fences,
  // trees, props). Solid items also need their own footprint clear; a rejected item takes its collider
  // with it. `free: true` marks deliberate composites (a parasol over its table).
  const fp = ctx.footprints || new Footprints(colliders);
  const rejected = [];
  const wasRejected = (x, z) => rejected.some((p) => Math.abs(p[0] - x) < 0.02 && Math.abs(p[1] - z) < 0.02);
  const halfXZ = new Map();
  const extentOf = (key, obj) => {
    if (!halfXZ.has(key)) {
      const b = new THREE.Box3();
      if (obj.isBufferGeometry) { obj.computeBoundingBox(); b.copy(obj.boundingBox); } else b.setFromObject(obj);
      halfXZ.set(key, [Math.max(0.05, (b.max.x - b.min.x) / 2), Math.max(0.05, (b.max.z - b.min.z) / 2)]);
    }
    return halfXZ.get(key);
  };
  const accept = (item, opts, [hx, hz]) => {
    const solid = isSolid(opts);
    const sx = (item.sx ?? item.s ?? 1), sz = (item.sz ?? item.s ?? 1);
    // solid things on a base or legs rest on the lowest ground under their footprint (never float),
    // and are not placed where the ground under them is too steep
    if (solid && Math.abs(item.y - Y(item.x, item.z)) < 0.06 && Math.max(hx * sx, hz * sz) > 0.25) {
      const g = footprintGround(hf, item.x, item.z, item.rot ?? 0, hx * sx * 0.85, hz * sz * 0.85);
      if (g.tilt > 0.5 && !item.free) return false;
      item.y += g.y - Y(item.x, item.z);
    }
    if (item.free) return true;
    if (solid && onWalk(item.x, item.z)) return false;
    const half = Math.min(hx * sx, hz * sz);
    const r = solid ? half * 0.8 : Math.min(0.15, half * 0.5);
    return fp.fits(item.x, item.z, r);
  };
  const put = (name, geo, item, opts = {}) => {
    if (item.rot === undefined) item.rot = rand() * Math.PI * 2;
    if (!accept(item, opts, extentOf(geo.uuid, geo))) { rejected.push([item.x, item.z]); return false; }
    const key = name + '|' + geo.uuid;
    if (!sets.has(key)) sets.set(key, { geo, opts: { name, ...opts }, items: [] });
    sets.get(key).items.push({ rot: rand() * Math.PI * 2, s: 1, ...item });
    counts[name] = (counts[name] || 0) + 1;
    return true;
  };
  // glTF assets from the downloaded packs
  const gsets = new Map();
  const putG = (name, item, opts = {}) => {
    if (!packs[name]) return false;
    if (item.rot === undefined) item.rot = rand() * Math.PI * 2;
    if (!accept(item, opts, extentOf('g:' + name, packs[name].scene))) { rejected.push([item.x, item.z]); return false; }
    if (!gsets.has(name)) gsets.set(name, { opts, items: [] });
    gsets.get(name).items.push({ rot: rand() * Math.PI * 2, s: 1, ...item });
    counts[name] = (counts[name] || 0) + 1;
    return true;
  };
  const Y = (x, z) => hf.sample(x, z);
  const occAt = (x, z, pad = 0) => occ.get(x, z, pad);
  const freeOf = (x, z, pad = 0) => { const o = occAt(x, z, pad); return o !== 1 && o !== 3; }; // not path / house
  const clear = (x, z, pad = 0) => occAt(x, z, pad) === 0;
  const nearBridge = (x, z, extra = 2) => bridges.some((b) => Math.hypot(x - b.mid.x, z - b.mid.z) < b.L / 2 + extra);
  const pick = (arr) => arr[Math.floor(rand() * arr.length)];
  const circle = (x, z, r) => { if (!onWalk(x, z) && !wasRejected(x, z)) colliders.circles.push({ x, z, r }); };
  const isMeadow = (x, z) => forestPatch(x, z) < 0.3;


  // ---------------- WOODLAND ----------------
  for (let i = 0; i < 16000 * dens; i++) {
    const x = (rand() - 0.5) * 420, z = (rand() - 0.5) * 420;
    const R = Math.hypot(x, z);
    if (R > 206) continue;
    const fp = forestPatch(x, z);
    if (fp < 0.5 || villageDist(x, z) < 34) continue;
    if (!freeOf(x, z, 0) || hf.riverDist(x, z) < 2.5 || hf.slope(x, z) > 1.2) continue;
    const r = rand(), y = Y(x, z);
    if (r < 0.42) putG('n-fern', { x, y, z, s: 0.45 + rand() * 0.45 }, { sway: [0.2, 0.05], shadow: false });
    else if (r < 0.62) put('undergrowth', A.undergrowth(Math.floor(rand() * 2)), { x, y, z, s: 0.8 + rand() * 0.8 }, LOWP);
    else if (r < 0.72) put('mushrooms', A.mushrooms(Math.floor(rand() * 3)), { x, y, z, s: 0.9 + rand() * 0.8 }, PROP);
    else if (r < 0.77 && clear(x, z, 2)) {
      const v = Math.floor(rand() * 2), rot = rand() * 6.28;
      if (!put('fallenLog', A.fallenLog(v), { x, y: y - 0.05, z, rot, s: 0.9 + rand() * 0.3 }, PROP)) continue;
      const L = (3 + v * 1.2) / 2;
      colliders.segs.push({ x0: x - Math.cos(rot) * L, z0: z + Math.sin(rot) * L, x1: x + Math.cos(rot) * L, z1: z - Math.sin(rot) * L, r: 0.35 });
      occ.mark(x, z, 2);
    } else if (r < 0.83 && clear(x, z, 1)) {
      put('stump', A.stump(Math.floor(rand() * 2)), { x, y: y - 0.03, z, s: 0.8 + rand() * 0.6 }, PROP);
      circle(x, z, 0.45); occ.mark(x, z, 1);
    } else if (r < 0.88 && clear(x, z, 1.5)) {
      put('mossyBoulder', mossyBoulder(Math.floor(rand() * 3)), { x, y: y - 0.2, z, s: 0.9 + rand() * 1.1 }, PROP);
      circle(x, z, 1.0); occ.mark(x, z, 1.5);
    } else if (r < 0.95) putG('n-plant-7', { x, y, z, s: 0.7 + rand() * 0.6 }, { sway: [0.2, 0.05], shadow: false });
    else putG('n-fern', { x, y, z, s: 0.8 + rand() * 0.3 }, { sway: [0.2, 0.05], shadow: false });
  }
  // birch groves on forest edges
  for (let i = 0; i < 2600; i++) {
    const x = (rand() - 0.5) * 400, z = (rand() - 0.5) * 400;
    const fp = forestPatch(x, z);
    if (fp < 0.25 || fp > 0.6 || Math.hypot(x, z) > 200 || villageDist(x, z) < 30) continue;
    if (noise(x * 0.05 + 3, z * 0.05) < 0.1) continue;
    if (!clear(x, z, 1.5) || hf.riverDist(x, z) < 3 || hf.slope(x, z) > 1) continue;
    put('birch', A.birchTree(Math.floor(rand() * 2)), { x, y: Y(x, z), z, s: 0.85 + rand() * 0.45 }, TREE);
    circle(x, z, 0.2); occ.mark(x, z, 1.6);
  }

  // ---------------- MEADOWS ----------------
  const flowerKinds = ['daisy', 'poppy', 'cornflower', 'buttercup', 'foxglove'];
  for (let i = 0; i < 26000 * dens; i++) {
    const x = (rand() - 0.5) * 400, z = (rand() - 0.5) * 400;
    if (Math.hypot(x, z) > 200 || !isMeadow(x, z)) continue;
    const vd = villageDist(x, z);
    if (vd < 22) continue;
    if (!clear(x, z, 0) || hf.riverDist(x, z) < 2 || hf.maskAt(x, z)) continue;
    const y = Y(x, z);
    const drift = noise(x * 0.035, z * 0.035) * 0.5 + 0.5;
    // meadow plants grow in drifts and swathes; open grass in between
    const swathe = noise(x * 0.06 + 17, z * 0.06 - 5) + 0.4 * noise(x * 0.2, z * 0.2);
    if (swathe < 0.05 && rand() > 0.08) continue;
    const r = rand();
    if (r < 0.45) put('tallGrass', A.tallGrass(Math.floor(rand() * 3)), { x, y, z, s: 0.8 + rand() * 0.8 }, BLADES);
    else if (r < 0.45 + 0.35 * drift) {
      const kind = flowerKinds[Math.floor((noise(x * 0.02 + 9, z * 0.02) * 0.5 + 0.5) * 4.99)];
      put('wild-' + kind, A.wildflowers(kind, rand() < 0.3 ? 1 : 0), { x, y, z, s: 0.9 + rand() * 0.6 }, LOWP);
    } else if (r < 0.9) put('grassTuft', A.grassTuft(Math.floor(rand() * 3)), { x, y, z, s: 1.2 + rand() * 1.2 }, BLADES);
    else if (r < 0.94 && clear(x, z, 1)) { put('floweringShrub', A.floweringShrub(Math.floor(rand() * 3)), { x, y, z, s: 0.8 + rand() * 0.6 }, PLANT); occ.mark(x, z, 1); }
    else if (r < 0.955 && clear(x, z, 2.5) && vd > 40) { put('blossomTree', A.blossomTree(Math.floor(rand() * 3)), { x, y, z, s: 0.9 + rand() * 0.4 }, TREE); circle(x, z, 0.25); occ.mark(x, z, 2.5); }
  }
  // an orchard with beehives, and a hay field
  const findOpen = (cx, cz, rad, need) => {
    for (let t = 0; t < 400; t++) {
      const a = rand() * 6.28, d = rand() * rad;
      const x = cx + Math.cos(a) * d, z = cz + Math.sin(a) * d;
      let ok = true;
      for (let k = 0; k < 12 && ok; k++) {
        const b = (k / 12) * 6.28;
        const px = x + Math.cos(b) * need, pz = z + Math.sin(b) * need;
        if (occAt(px, pz, 0) === 1 || occAt(px, pz, 0) === 3 || hf.riverDist(px, pz) < 3 || hf.slope(px, pz) > 0.35) ok = false;
      }
      if (ok) return [x, z];
    }
    return null;
  };
  const orchard = ctx.reserved?.orchard ? [ctx.reserved.orchard.x, ctx.reserved.orchard.z] : null;
  if (orchard) {
    const [ox, oz] = orchard;
    for (let i = -2; i <= 2; i++) for (let j = -2; j <= 2; j++) {
      const x = ox + i * 5.5 + (rand() - 0.5), z = oz + j * 5.5 + (rand() - 0.5);
      if (occAt(x, z) === 3) continue;
      put('fruitTree', A.fruitTree((i + j) & 1), { x, y: Y(x, z), z, s: 0.9 + rand() * 0.25 }, TREE);
      circle(x, z, 0.25); occ.mark(x, z, 2);
    }
    for (let i = 0; i < 4; i++) {
      const x = ox + 16 + (i % 2) * 1.6, z = oz - 3 + i * 1.8;
      if (!freeOf(x, z, 0.5)) continue;
      put('beehive', A.beehive(i % 2), { x, y: Y(x, z), z, rot: -Math.PI / 2, s: 1 }, PROP);
      circle(x, z, 0.45);
    }
    interactables.push({ id: 'orchard', kind: 'toast', x: ox + 14, z: oz, y: Y(ox + 14, oz), r: 3, label: 'Listen to the bees', message: 'A gentle hum. The orchard is busy today.' });
  }
  const hay = ctx.reserved?.hay ? [ctx.reserved.hay.x, ctx.reserved.hay.z] : null;
  if (hay) {
    const [hx, hz] = hay;
    for (let i = 0; i < 9; i++) {
      const x = hx + (rand() - 0.5) * 20, z = hz + (rand() - 0.5) * 20;
      if (hf.slope(x, z) > 0.5) continue;
      put('hayBale', A.hayBale(i % 3 === 0 ? 1 : 0), { x, y: Y(x, z) - 0.05, z, s: 1 + rand() * 0.2 }, PROP);
      circle(x, z, 0.75); occ.mark(x, z, 1.6);
    }
  }

  // ---------------- RIVERBANKS ----------------
  for (let i = 0; i < samples.length; i += 1) {
    const s = samples[i];
    if (s.z < -205 || s.z > 205) continue;
    const hw = halfWidth(s.z), W = waterLevel(s.z), rp = rapidness(s.z);
    const cascade = CASCADES.some((c) => s.z > c.z0 - 4 && s.z < c.z1 + 8);
    for (const side of [-1, 1]) {
      const at = (off) => [s.x - s.tz * off * side, s.z + s.tx * off * side];
      if (rp < 0.6 && !cascade && rand() < 0.3) {
        const [x, z] = at(hw + (rand() - 0.3) * 1.2);
        if (!nearBridge(x, z) && occAt(x, z) !== 1) put('reeds', A.reeds(rand() < 0.5 ? 0 : 1), { x, y: Math.max(W - 0.1, Y(x, z) - 0.05), z, s: 0.8 + rand() * 0.6 }, BLADES);
      }
      if (rp < 0.5 && rand() < 0.07) {
        const [x, z] = at(hw + 0.6 + rand() * 0.8);
        if (!nearBridge(x, z) && occAt(x, z) !== 1) put('irises', A.irises(rand() < 0.75 ? 0 : 1), { x, y: Y(x, z), z, s: 0.9 + rand() * 0.5 }, PLANT);
      }
      if (rand() < 0.28) {
        const [x, z] = at(hw + 0.2 + rand() * 1.6);
        if (!nearBridge(x, z, 1) && occAt(x, z) !== 1) put('pebbles', A.pebbles(Math.floor(rand() * 2)), { x, y: Y(x, z), z, s: 0.8 + rand() * 0.8 }, { mat: 'solid', shadow: false });
      }
      if (rand() < 0.012) {
        const [x, z] = at(hw + 0.8 + rand());
        if (!nearBridge(x, z) && freeOf(x, z, 1)) put('branch', A.branch(), { x, y: Y(x, z), z, s: 0.8 + rand() * 0.5 }, PROP);
      }
    }
    if (rp < 0.25 && !cascade && i % 3 === 0 && rand() < 0.45) {
      const side = rand() < 0.5 ? -1 : 1, off = (hw - 1.2 - rand() * 1.5) * side;
      const x = s.x - s.tz * off, z = s.z + s.tx * off;
      if (!nearBridge(x, z, 3)) put('lilyPads', A.lilyPads(rand() < 0.5 ? 0 : 1), { x, y: W + 0.02, z, s: 0.8 + rand() * 0.6 }, { mat: 'solid', shadow: false });
    }
    // weeping willows along the village stretch of river
    if (s.z > -110 && s.z < 160 && i % 14 === 0) {
      const side = (i / 14) % 2 ? 1 : -1, off = (hw + 4.5 + rand() * 2) * side;
      const x = s.x - s.tz * off, z = s.z + s.tx * off;
      if (freeOf(x, z, 2) && occAt(x, z, 0) === 0 && !nearBridge(x, z, 4) && hf.slope(x, z) < 0.6) {
        put('willow', A.willowTree2(0), { x, y: Y(x, z), z, s: 0.9 + rand() * 0.3 }, TREE);
        circle(x, z, 0.45); occ.mark(x, z, 3);
      }
    }
  }
  // a little jetty with a rowboat on the calm stretch below the village
  {
    const s = samples.reduce((b, p) => (Math.abs(p.z - 22) < Math.abs(b.z - 22) ? p : b));
    const hw = halfWidth(s.z), W = waterLevel(s.z);
    const nx = -s.tz, nz = s.tx;
    const side = (s.x + nx * 5 < s.x - nx * 5) ? 1 : -1; // west bank
    const bx = s.x + nx * side * (hw + 1.2), bz = s.z + nz * side * (hw + 1.2);
    const rot = Math.atan2(-nx * side, -nz * side); // +z points into the river
    put('jetty', A.jetty(), { x: bx, y: W + 0.55, z: bz, rot, s: 1 }, PROP);
    const fx = Math.sin(rot), fz = Math.cos(rot);
    const boatX = bx + fx * 2.6 + s.tx * 1.7, boatZ = bz + fz * 2.6 + s.tz * 1.7;
    const boat = { x: boatX, y: W - 0.12, z: boatZ, rot: Math.atan2(s.tx, s.tz), s: 1 };
    put('rowboat', A.rowboat(0), boat, PROP);
    // walkable jetty deck
    surfaces.push({
      test(x, z) {
        const dx = x - bx, dz = z - bz;
        const u = dx * fx + dz * fz, v = dx * fz - dz * fx;
        if (u < -0.6 || u > 3.7 || Math.abs(v) > 0.8) return null;
        return W + 0.6;
      },
    });
    interactables.push({ id: 'jetty', kind: 'toast', x: bx + fx * 3.2, z: bz + fz * 3.2, y: W + 0.6, r: 1.8, label: 'Sit and watch the river', message: 'The water slides by. A dragonfly hovers over the lilies.' });
  }

  // ---------------- GARDENS ----------------
  const gardenRand = () => rand();
  for (const h of houses) {
    const T = (lx, lz) => h.toWorld(lx, lz);
    const front = h.d / 2 + h.wingD;
    const door = h.doorLocal;
    const yard = h.garden;
    // pots either side of the door, topiary for townhouses
    for (const sx of [-1, 1]) {
      const [x, z] = T(door[0] + sx * 1.15, door[1] + 0.75);
      if (occAt(x, z) === 1) continue;
      if (h.style === 'townhouse') put('topiary', A.topiary(sx > 0 ? 1 : 0), { x, y: Y(x, z), z, rot: h.rot, s: 0.85 }, PROP);
      else put('planter', A.planter(gardenRand() < 0.7 ? 0 : 1), { x, y: Y(x, z), z, s: 0.8 + gardenRand() * 0.3 }, PROP);
      circle(x, z, 0.3);
    }
    // planted beds along the front (and, for gardens, the sides): defined soil beds with plants in drifts
    // Bed planting palette: tall plants at the back, mid and low plants towards the path, each with
    // a footprint radius at scale 1 so spacing is believable. Each house picks its own few species.
    const SP = {
      hydrangea: { tier: 2, r: 0.5, s: 0.72, f: (v) => A.hydrangea(v), n: 3, name: 'hydrangea' },
      rose: { tier: 2, r: 0.42, s: 0.85, f: (v) => A.roseBush(v), n: 3, name: 'roseBush' },
      salvia: { tier: 1, r: 0.22, s: 1.0, f: (v) => A.salvia(v), n: 3, name: 'salvia' },
      allium: { tier: 2, r: 0.2, s: 1.0, f: (v) => A.cottageFlowers('allium', v), n: 2, name: 'allium' },
      peony: { tier: 1, r: 0.4, s: 0.85, f: (v) => A.peony(v), n: 3, name: 'peony' },
      lavender: { tier: 1, r: 0.26, s: 0.95, f: (v) => A.lavenderBush(v), n: 2, name: 'lavender' },
      daisy: { tier: 0, r: 0.18, s: 1.0, f: (v) => A.cottageFlowers('daisy', v), n: 2, name: 'daisy' },
      cosmos: { tier: 0, r: 0.18, s: 1.0, f: (v) => A.cottageFlowers('cosmos', v), n: 1, name: 'cosmos' },
      box: { tier: 0, r: 0.34, s: 0.7, f: (v) => A.boxBall(v), n: 2, name: 'boxBall', solid: true },
    };
    const pickN = (arr, n) => { const a = [...arr]; const out = []; while (out.length < n && a.length) out.push(a.splice(Math.floor(gardenRand() * a.length), 1)[0]); return out; };
    const backSp = pickN(['hydrangea', 'rose', 'salvia', 'allium', 'peony'], 2);
    const frontSp = pickN(['lavender', 'daisy', 'cosmos', 'box', 'lavender', 'daisy', 'cosmos'], 2);
    const beds = [];
    const fz = h.d / 2 + 0.6;
    const cuts = [[h.doorLocal[0] - 1.15, h.doorLocal[0] + 1.15]];
    if (h.cross) cuts.push([h.wingX - h.wingW / 2 - 0.3, h.wingX + h.wingW / 2 + 0.3]);
    let xs = [[-h.w / 2 + 0.25, h.w / 2 - 0.25]];
    for (const [c0, c1] of cuts) xs = xs.flatMap(([a, b]) => [[a, Math.min(b, c0)], [Math.max(a, c1), b]]).filter(([a, b]) => b - a > 0.9);
    for (const [a, b] of xs) beds.push({ cx: (a + b) / 2, cz: fz, len: b - a, rot: 0 });
    if (yard) for (const sx of [-1, 1]) {
      const side = sx > 0 ? 1 : 3;
      if (side === h.leanToSide || (h.domain === 'health' && side === 1) || (h.details?.bay && side === 1)) continue;
      beds.push({ cx: sx * (h.w / 2 + 0.6), cz: 0, len: h.d - 1.2, rot: Math.PI / 2, backSign: -sx });
    }
    for (const bd of beds) {
      const [x, z] = T(bd.cx, bd.cz);
      if (occAt(x, z) === 1 || hf.riverDist(x, z) < 1.5) continue;
      const brot = h.rot + bd.rot;
      put('gardenBed', A.gardenBed(h.boundary === 'wood' ? 1 : 0), { x, y: Y(x, z) - 0.02, z, rot: brot, s: 1, sx: bd.len, sz: 0.9 }, { mat: 'solid', shadow: false });
      // two rows planted in drifts of 2 to 4 of one species: tall at the back (towards the wall), low at
      // the front, staggered, spaced by each plant's size, with the odd gap; all in the bed's own frame
      const ca = Math.cos(brot), sa = Math.sin(brot);
      const back = bd.backSign ?? -1;
      const at = (t, u) => [x + t * ca + u * sa, z - t * sa + u * ca];
      for (const [row, list, u0] of [[0, backSp, 0.17 * back], [1, frontSp, -0.2 * back]]) {
        let t = -bd.len / 2 + (row ? 0.12 : 0.05);
        let drift = 0, sp = null, v = 0;
        while (t < bd.len / 2) {
          if (drift <= 0) { sp = SP[list[Math.floor(gardenRand() * list.length)]]; drift = sp.name === 'boxBall' ? 2 : 2 + Math.floor(gardenRand() * 3); v = Math.floor(gardenRand() * sp.n); if (gardenRand() < 0.12) { t += 0.25; } }
          const sc = sp.s * (0.85 + gardenRand() * 0.3), rad = sp.r * sc;
          const tc = t + rad;
          if (tc + rad * 0.6 > bd.len / 2) break;
          const u = u0 + (gardenRand() - 0.5) * 0.08;
          const [px, pz] = at(tc, u);
          put(sp.name, sp.f(v), { x: px, y: Y(px, pz) + 0.06, z: pz, s: sc }, sp.solid ? PROP : PLANT);
          t = tc + rad * (0.7 + gardenRand() * 0.2);
          drift--;
        }
      }
    }
    if (yard) {
      // a flowerbed in the front yard, beside the path
      const bx = door[0] + (door[0] > 0 ? -1 : 1) * (h.w * 0.32), bz = front + 1.6;
      const [x, z] = T(bx, bz);
      if (freeOf(x, z, 1)) { put('flowerbed', A.flowerbed(Math.floor(gardenRand() * 3)), { x, y: Y(x, z), z, rot: h.rot, s: 0.9 }, PROP); }
      // garden arch over the gate
      if (h.arch && h.yardDepth >= 2.2 && h.domain !== 'home') { // room for the arch to stand clear of the doorstep and hood
        // just inside the gate, straddling the walkway
        const gz = door[1] + h.yardDepth - 0.45;
        const [ax, az] = T(door[0], gz);
        if (occAt(ax, az) !== 3) {
          put('gardenArch', A.gardenArch(Math.floor(gardenRand() * 5)), { x: ax, y: Y(ax, az), z: az, rot: h.rot, s: 1 }, PLANT);
          for (const s of [-0.8, 0.8]) { const [px, pz] = T(door[0] + s, gz); colliders.circles.push({ x: px, z: pz, r: 0.12 }); }
        }
      }
      // garden furniture and tools in the side yard
      const side = gardenRand() < 0.5 ? -1 : 1;
      const [sx, sz] = T(side * (h.w / 2 + 2.6), h.d / 2 - 0.5);
      const r2 = gardenRand();
      if (freeOf(sx, sz, 1) && occAt(sx, sz, 0) === 0) {
        if (r2 < 0.35) { put('bistroSet', A.bistroSet(Math.floor(gardenRand() * 3)), { x: sx, y: Y(sx, sz), z: sz, s: 1 }, PROP); circle(sx, sz, 0.9); }
        else if (r2 < 0.55) { put('birdbath', A.birdbath(), { x: sx, y: Y(sx, sz), z: sz, s: 1 }, PROP); circle(sx, sz, 0.4); }
        else if (r2 < 0.75) { put('wheelbarrow', A.wheelbarrow(Math.floor(gardenRand() * 2)), { x: sx, y: Y(sx, sz), z: sz, s: 1 }, PROP); circle(sx, sz, 0.5); }
        else { put('bench2', A.bench2(Math.floor(gardenRand() * 3)), { x: sx, y: Y(sx, sz), z: sz, rot: h.rot, s: 1 }, PROP); circle(sx, sz, 0.6); }
        occ.mark(sx, sz, 1.2);
      }
      if (gardenRand() < 0.45) { const [x, z] = T(-side * (h.w / 2 + 1.2), h.d / 2 + 0.6); if (freeOf(x, z)) put('wateringCan', A.wateringCan(), { x, y: Y(x, z), z, s: 1 }, PROP); }
    } else if (gardenRand() < 0.6) {
      // tidy box hedges along the plot sides
      for (const sx of [-1, 1]) for (let k = 0; k < 2; k++) {
        const [x, z] = T(sx * (h.w / 2 + 1.8), -h.d / 2 + 1 + k * 2.05);
        if (!freeOf(x, z, 0) || hf.riverDist(x, z) < 1.5) continue;
        put('hedge', A.hedge(k % 2), { x, y: Y(x, z), z, rot: h.rot + Math.PI / 2, s: 1 }, PROP);
        circle(x, z, 0.5);
      }
    }
    // back yard life: laundry, woodpiles, churns, barrels
    const r3 = gardenRand();
    const [bx, bz] = T((gardenRand() - 0.5) * h.w * 0.5, -h.d / 2 - 2.6);
    if (freeOf(bx, bz, 1) && occAt(bx, bz, 0) === 0 && hf.riverDist(bx, bz) > 2) {
      if (r3 < 0.3) { if (put('laundryLine', A.laundryLine(Math.floor(gardenRand() * 4)), { x: bx, y: Y(bx, bz), z: bz, rot: h.rot, s: 1 }, PLANT)) for (const s of [-1.8, 1.8]) { const [px, pz] = T(s, -h.d / 2 - 2.6); circle(px, pz, 0.1); } }
      else if (r3 < 0.5) { const [wx, wz] = T(h.w / 2 + 0.55, -h.d / 4); if (freeOf(wx, wz)) { put('woodpile', A.woodpile(), { x: wx, y: Y(wx, wz), z: wz, rot: h.rot + Math.PI / 2, s: 1 }, PROP); circle(wx, wz, 0.8); } }
      else if (r3 < 0.62) { put('milkChurns', A.milkChurns(), { x: bx, y: Y(bx, bz), z: bz, s: 1 }, PROP); circle(bx, bz, 0.5); }
      else if (r3 < 0.8) { put('barrel', A.barrel(Math.floor(gardenRand() * 2)), { x: bx, y: Y(bx, bz), z: bz, s: 1 }, PROP); circle(bx, bz, 0.4); }
      occ.mark(bx, bz, 1.5);
    }
  }

  // ---------------- VILLAGE LIFE ----------------
  // market stalls on the square, with produce around them
  {
    const benchAngles = [0, 1, 2, 3].map((i) => i * Math.PI / 2 + Math.PI / 4);
    const nbA = -0.9 + Math.PI * 2;
    const cands = [0.25, 0.85, 1.45, 2.05, 2.65, 3.3, 3.9, 4.6, 5.25, 5.85];
    let placed = 0;
    for (const a of cands) {
      if (placed >= 3) break;
      const angDist = (b) => Math.abs(((a - b + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
      if (benchAngles.some((b) => angDist(b) < 0.4) || angDist(nbA) < 0.55) continue;
      const ox = SQUARE.x + Math.cos(a) * (SQUARE.r + 1.8), oz = SQUARE.z + Math.sin(a) * (SQUARE.r + 1.8);
      if (hf.maskAt(ox, oz) & 1) continue; // lane entrance
      const x = SQUARE.x + Math.cos(a) * (SQUARE.r - 2.2), z = SQUARE.z + Math.sin(a) * (SQUARE.r - 2.2);
      const rot = Math.atan2(SQUARE.x - x, SQUARE.z - z);
      // the whole stall footprint (with its crate and barrel) must sit clear of lanes crossing the square
      const ca = Math.cos(rot), sa = Math.sin(rot);
      let hit = false;
      for (let u = -2.3; u <= 2.3 && !hit; u += 0.4) for (const v of [-0.8, 0, 0.8]) if (onWalk(x + u * ca + v * sa, z - u * sa + v * ca)) { hit = true; break; }
      if (hit) continue;
      const y = Y(SQUARE.x, SQUARE.z) + 0.05;
      put('marketStall', A.marketStall(placed), { x, y, z, rot, s: 1 }, PROP);
      if (!wasRejected(x, z)) colliders.obbs.push({ x, z, rot, hx: 1.3, hz: 0.55, y0: y, y1: y + 2.6 });
      const tx = Math.cos(rot), tz = -Math.sin(rot);
      put('crate', A.crate(placed + 1), { x: x + tx * 1.7, y, z: z + tz * 1.7, rot: rot + 0.2, s: 1 }, PROP);
      put('basket', A.basket(placed), { x: x - tx * 1.6 + Math.sin(rot) * 0.6, y, z: z - tz * 1.6 + Math.cos(rot) * 0.6, s: 1 }, PROP);
      put('barrel', A.barrel(2), { x: x - tx * 1.8, y, z: z - tz * 1.8, s: 1 }, PROP);
      circle(x + tx * 1.7, z + tz * 1.7, 0.45); circle(x - tx * 1.8, z - tz * 1.8, 0.4);
      const names = ['Fresh from the orchard: apricots, plums and pears.', 'Flowers by the bunch. The peonies are in.', 'Herbs, honey and garden greens.'];
      interactables.push({ id: 'stall' + placed, kind: 'toast', x: x + Math.sin(rot) * 1.4, z: z + Math.cos(rot) * 1.4, y, r: 1.8, label: 'Browse the stall', message: names[placed] });
      placed++;
    }
  }
  // café corner: parasols and bistro tables by the square
  {
    let made = 0;
    for (let t = 0; t < 300 && made < 3; t++) {
      const a = rand() * 6.28, d = SQUARE.r + 3.5 + rand() * 6;
      const x = SQUARE.x + Math.cos(a) * d, z = SQUARE.z + Math.sin(a) * d;
      if (!freeOf(x, z, 1.2) || occAt(x, z, 0) !== 0 || !fp.fits(x, z, 0.9)) continue;
      const y = Y(x, z);
      put('bistroSet', A.bistroSet(made), { x, y, z, s: 1 }, PROP);
      put('parasol', A.parasol(made), { x, y, z, s: 1, free: true }, PROP);
      circle(x, z, 0.9); occ.mark(x, z, 1.8); made++;
    }
  }
  // the village well
  {
    for (let t = 0; t < 200; t++) {
      const a = rand() * 6.28, d = SQUARE.r + 6 + rand() * 10;
      const x = SQUARE.x + Math.cos(a) * d, z = SQUARE.z + Math.sin(a) * d;
      if (!clear(x, z, 2) || hf.slope(x, z) > 0.3) continue;
      put('well', A.well(), { x, y: Y(x, z), z, s: 1 }, PROP);
      circle(x, z, 1.05); occ.mark(x, z, 2);
      interactables.push({ id: 'well', kind: 'toast', x: x + 1.6, z, y: Y(x, z), r: 2, label: 'Draw some water', message: 'Cold and clear, straight from the mountain.' });
      break;
    }
  }
  // bunting strung across the lanes near the square, signposts at trail heads, carts by the lanes
  for (const l of lanes) {
    if (l.walk || l.type === 'trail') continue;
    const S = l.samples;
    for (let i = 4; i < S.length - 4; i += 1) {
      const s = S[i];
      const dSq = Math.hypot(s.x - SQUARE.x, s.z - SQUARE.z);
      if (s.bridge) continue;
      if (!((dSq > 15 && dSq < 16.2) || (dSq > 30 && dSq < 31.2))) continue;
      const len = l.w + 1.6;
      if ([-1, 1].some((sd) => fp.clearance(s.x + s.nx * sd * len / 2, s.z + s.nz * sd * len / 2, 0.12) < 1.2)) continue; // poles and line clear of eaves and props
      const geo = A.bunting(Math.round(len), Math.floor(rand() * 6));
      put('bunting', geo, { x: s.x, y: s.y, z: s.z, rot: Math.atan2(-s.nz, s.nx), s: len / Math.round(len) }, { mat: 'double', shadow: true });
      for (const sd of [-1, 1]) circle(s.x + s.nx * sd * len / 2, s.z + s.nz * sd * len / 2, 0.1);
      i += 6;
    }
  }
  for (const l of LANES) {
    if (l.type !== 'trail') continue;
    const lane = lanes.find((q) => q.id === l.id);
    const s = lane.samples[Math.min(4, lane.samples.length - 1)];
    const x = s.x + s.nx * (lane.w / 2 + 1.2), z = s.z + s.nz * (lane.w / 2 + 1.2);
    if (lanes.some((o) => o !== lane && o.samples.some((q) => Math.hypot(q.x - x, q.z - z) < o.w / 2 + 0.8))) continue;
    put('signpost', A.signpost(Math.floor(rand() * 4)), { x, y: Y(x, z), z, s: 1 }, PROP);
    circle(x, z, 0.15);
  }
  {
    let carts = 0;
    for (const l of lanes) {
      if (l.walk || l.type === 'trail' || carts >= 4) continue;
      const s = l.samples[Math.floor(l.samples.length * (0.3 + rand() * 0.4))];
      const x = s.x + s.nx * (l.w / 2 + 2.2), z = s.z + s.nz * (l.w / 2 + 2.2);
      if (!freeOf(x, z, 0.6) || occAt(x, z, 0) !== 0 || s.bridge || hf.riverDist(x, z) < 2 || !fp.fits(x, z, 0.9)) continue;
      put('handCart', A.handCart(carts % 2), { x, y: Y(x, z), z, rot: Math.atan2(s.nz, -s.nx) + 0.3, s: 1 }, PROP);
      circle(x, z, 0.9); occ.mark(x, z, 1.5); carts++;
    }
  }
  // small lantern posts lighting the walkways of the domain houses
  for (const h of houses) {
    if (!h.domain) continue;
    for (const lz of [2.0, 4.0]) {
      const [x, z] = h.toWorld(h.doorLocal[0] - 1.0, h.doorLocal[1] + lz);
      if (occAt(x, z) === 1) continue;
      put('lanternPost', A.lanternPost(lz > 3 ? 1 : 0), { x, y: Y(x, z), z, s: 1 }, PROP);
      circle(x, z, 0.12);
    }
  }
  // verges: loose edging stones along cobbled lanes and trails, never in a ruled line
  for (const l of lanes) {
    if (l.walk || l.type === 'slab') continue;
    const S = l.samples;
    for (let i = 1; i < S.length - 1; i++) {
      const s = S[i];
      if (s.bridge || s.plaza) continue;
      for (const side of [-1, 1]) {
        if (rand() > (l.type === 'cobble' ? 0.75 : 0.22)) continue;
        const off = l.w / 2 + 0.08 + rand() * 0.18;
        const x = s.x + s.nx * side * off, z = s.z + s.nz * side * off;
        if (occAt(x, z) === 3 || hf.riverDist(x, z) < 0.6) continue;
        put('edgeStone', A.edgeStone(Math.floor(rand() * 3)), { x, y: Y(x, z), z, s: 0.8 + rand() * 0.6 }, { mat: 'solid', shadow: false });
        if (rand() < 0.3) put('grassTuft', A.grassTuft(Math.floor(rand() * 3)), { x: x + s.nx * side * 0.25, y: Y(x, z), z: z + s.nz * side * 0.25, s: 0.9 + rand() * 0.6 }, BLADES);
      }
    }
  }

  // grass tufts and daisies across village lawns
  for (let i = 0; i < 6000 * dens; i++) {
    const a = rand() * 6.28, d = Math.sqrt(rand()) * 70;
    const x = -10 + Math.cos(a) * d, z = 5 + Math.sin(a) * d;
    if (noise(x * 0.07 + 4, z * 0.07) < 0.25) continue; // in drifts, leaving open lawn between
    if (!clear(x, z, 0) || hf.maskAt(x, z) || hf.riverDist(x, z) < 1.5) continue;
    const y = Y(x, z);
    if (rand() < 0.6) put('grassTuft', A.grassTuft(Math.floor(rand() * 3)), { x, y, z, s: 0.9 + rand() * 0.8 }, BLADES);
    else put('wild-daisy', A.wildflowers('daisy', rand() < 0.3 ? 1 : 0), { x, y, z, s: 0.8 + rand() * 0.4 }, LOWP);
  }

  placePackAssets({ ...ctx, putG, root, clear, freeOf, occAt, circle, nearBridge, Y, isMeadow, counts, wasRejected, fp });

  // small, numerous things share big tiles (fewer draw calls); shadow casters keep small tiles for culling
  for (const { geo, opts, items } of sets.values()) root.add(scatter(geo, items, { mat: opts.mat, shadow: opts.shadow, name: opts.name, tile: opts.shadow ? 64 : 128 }));
  for (const [name, { opts, items }] of gsets) root.add(scatterGLTF(packs[name], items, { name, shadow: opts.shadow ?? true, sway: opts.sway || null, tile: (opts.shadow ?? true) ? 64 : 128 }));

  // butterflies over gardens and meadows; dragonflies hovering along the calm river margins
  const riverSpots = [];
  for (let t = 0; t < 400 && riverSpots.length < 44; t++) {
    const s = samples[Math.floor(rand() * samples.length)];
    if (!s || Math.abs(s.z) > 190 || rapidness(s.z) > 0.35) continue;
    const off = (halfWidth(s.z) - 0.6 + rand() * 1.4) * (rand() < 0.5 ? -1 : 1);
    riverSpots.push([s.x - s.tz * off, waterLevel(s.z) + 0.45 + rand() * 0.5, s.z + s.tx * off]);
  }
  const bugs = insects(rand, { height: (x, z) => hf.sample(x, z), wanted: (x, z) => isMeadow(x, z) || villageDist(x, z) < 40, notWater: (x, z) => !(hf.maskAt(x, z) & 4), riverSpots });
  root.add(bugs.group);
  animated.push((t) => { bugs.uniforms.uTime.value = t; });
  counts.butterflies = bugs.butterflies; counts.dragonflies = bugs.dragonflies;
  return { root, counts };
}

function mossyBoulder(v = 0) {
  return kit('mossyBoulder', (k, r) => {
    k.add(G.ball(2), PAL.stone, M(0, 0.45, 0, 0, r() * 3, 0, 1.0, 0.7, 0.85));
    k.add(G.ball(2), PAL.stoneDark, M(0.5, 0.3, 0.3, 0, 0, 0, 0.55, 0.45, 0.5));
    k.add(G.ball(2), PAL.moss, M(-0.05, 0.85, 0, 0, 0, 0, 0.82, 0.32, 0.7));
    if (v) k.add(G.ball(1), PAL.mintDeep, M(0.4, 0.65, 0.2, 0, 0, 0, 0.35, 0.18, 0.3));
    for (let i = 0; i < 3; i++) k.add(G.cone(4), PAL.sageDeep, M(-0.8 + i * 0.3, 0.15, 0.6, 0.3, 0, 0, 0.08, 0.35, 0.08));
  }, v);
}

// ---------------- PACK ASSETS (Kenney Fantasy Town, Quaternius Nature / Props / Medieval Village) ----------------
function placePackAssets(ctx) {
  const { hf, houses, lanes, rand, colliders, interactables, villageDist, animated, packs, putG, root, clear, freeOf, occAt, circle, nearBridge, Y, isMeadow, occ, counts, wasRejected, fp } = ctx;
  const pick = (arr) => arr[Math.floor(rand() * arr.length)];
  const FOLIAGE = { sway: [0.2, 0.05], shadow: false };
  const FOLIAGE_SH = { sway: [0.2, 0.05], shadow: true };

  // landmark helper: a pack model as its own animated mesh group
  const single = (name, center = 'mid', scale = 1) => {
    const g = packs[name];
    if (!g) return null;
    const obj = g.scene.clone(true);
    const box = new THREE.Box3().setFromObject(obj);
    const c = box.getCenter(new THREE.Vector3());
    obj.position.sub(c);
    const holder = new THREE.Group();
    holder.add(obj);
    holder.scale.setScalar(scale);
    obj.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    return holder;
  };

  // --- Watermill on the calm stretch between the second and third falls ---
  for (const spot of ctx.reserved?.mill ? [ctx.reserved.mill] : []) {
    const { s, side } = spot;
    const W = waterLevel(s.z), hw = halfWidth(s.z);
    const nx = -s.tz, nz = s.tx;
    const hx = spot.x, hz = spot.z;
    const gy = Y(hx, hz);
    const rot = Math.atan2(-nx * side, -nz * side); // local +z faces the river
    const mill = new THREE.Group();
    mill.position.set(hx, gy, hz);
    mill.rotation.y = rot;
    // the miller's house is built with the same architecture kit as the village houses: stone ground
    // floor, timber upper storey, deep eaves, shutters and window boxes; its door faces away from the river
    const mh = planHouse({ x: 0, z: 0, rot: Math.PI, style: 'chalet', w: 6.2, d: 5.0, floors: 2, cross: false, dormers: 0, roof: 'terracotta', wall: 'cream', shutters: 'green', seed: 77 });
    const mb = new Batcher();
    const built = buildHouse(mh, (g, m, mat) => mb.add(g, m, mat), 0);
    mill.add(mb.build('millHouse'));
    mill.add(built.doorPivot);
    const wheel = single('k-watermill', 'mid', 2.5);
    if (wheel) {
      // wheel axle points from the river to the house (local x of the Kenney model)
      const holder = new THREE.Group();
      holder.position.set(0, W - gy + 1.25, 3.0 + Math.max(0, hw - 4.4) * 0.0 + 1.6);
      holder.rotation.y = Math.PI / 2;
      holder.add(wheel);
      mill.add(holder);
      animated.push((t) => { wheel.rotation.x = -t * 0.6; });
      // axle beam
      const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 2.2, 8).rotateX(Math.PI / 2), kitMaterial('solid'));
      beam.position.set(0, W - gy + 1.25, 2.6);
      mill.add(beam);
    }
    root.add(mill);
    colliders.obbs.push({ x: hx, z: hz, rot, hx: 3.1, hz: 2.6, y0: gy - 1, y1: gy + 8 });
    occ.mark(hx, hz, 5);
    interactables.push({ id: 'watermill', kind: 'toast', x: hx - Math.sin(rot) * 3.6, z: hz - Math.cos(rot) * 3.6, y: gy, r: 2.6, label: 'Listen to the mill', message: 'The wheel turns slowly, creaking in time with the river.' });
    counts.watermill = 1;
  }

  // --- Windmill on an open meadow rise ---
  {
    const spot = ctx.reserved?.windmill ? [ctx.reserved.windmill.x, ctx.reserved.windmill.z] : null;
    if (spot) {
      const [x, z] = spot, gy = Y(x, z) - 0.2;
      const rot = rand() * 6.28;
      const wm = new THREE.Group();
      wm.position.set(x, gy, z);
      wm.rotation.y = rot;
      const tower = windmillTower();
      wm.add(tower);
      const blades = single('k-windmill', 'mid', 3.3);
      if (blades) {
        const holder = new THREE.Group();
        holder.position.set(0, 8.6, 3.85); // sail plane clear of the reefing stage and its railing
        holder.rotation.y = Math.PI / 2;
        holder.add(blades);
        wm.add(holder);
        animated.push((t) => { blades.rotation.x = t * 0.35; });
      }
      root.add(wm);
      circle(x, z, 2.9);
      occ.mark(x, z, 5);
      interactables.push({ id: 'windmill', kind: 'toast', x: x + Math.sin(rot) * 4.2, z: z + Math.cos(rot) * 4.2, y: gy, r: 2.6, label: 'Admire the windmill', message: 'The sails sweep round in the summer breeze.' });
      counts.windmill = 1;
      // a cottage garden at its foot
      for (let i = 0; i < 6; i++) {
        const a = rot + (i / 6) * 6.28, px = x + Math.cos(a) * 4.2, pz = z + Math.sin(a) * 4.2;
        if (true) putG(i % 2 ? 'n-flower-3' : 'n-bush-flowers', { x: px, y: Y(px, pz), z: pz, s: i % 2 ? 0.45 : 0.6 }, FOLIAGE);
      }
      const [wx, wz] = [x + Math.cos(rot + 1.2) * 6.5, z + Math.sin(rot + 1.2) * 6.5];
      if (hf.slope(wx, wz) < 0.5 && fp.fits(wx, wz, 1.4)) { putG('v-wagon', { x: wx, y: Y(wx, wz), z: wz, s: 1 }); circle(wx, wz, 1.4); occ.mark(wx, wz, 2.2); }
    }
  }

  // --- market row near the square: Kenney stalls, the Quaternius stall cart, produce ---
  {
    const stalls = ['k-stall-green', 'k-stall-red', 'p-stall-cart'];
    let i = 0;
    for (const spot of ctx.reserved?.market || []) {
      const { x, z } = spot;
      const rot = Math.atan2(SQUARE.x - x, SQUARE.z - z);
      const y = Y(x, z);
      const kenney = stalls[i].startsWith('k-');
      putG(stalls[i], { x, y, z, rot: kenney ? rot + Math.PI : rot, s: kenney ? 2.6 : 1 });
      if (!wasRejected(x, z)) colliders.obbs.push({ x, z, rot, hx: kenney ? 1.35 : 1.5, hz: kenney ? 1.35 : 0.6, y0: y, y1: y + 3 });
      const tx = Math.cos(rot), tz = -Math.sin(rot);
      putG(pick(['p-crate-apple', 'p-crate-carrot']), { x: x + tx * 2.0, y, z: z + tz * 2.0, s: 1.1, rot: rot + 0.3 });
      putG('p-barrel-apples', { x: x - tx * 2.0, y, z: z - tz * 2.0, s: 1 });
      putG('p-bag', { x: x - tx * 2.0 + Math.sin(rot) * 0.8, y, z: z - tz * 2.0 + Math.cos(rot) * 0.8, s: 0.8 });
      if (kenney) {
        putG('k-stall-stool', { x: x + Math.sin(rot) * 1.6 + tx * 0.6, y, z: z + Math.cos(rot) * 1.6 + tz * 0.6, s: 2.2 });
        putG('k-stall-bench', { x: x - Math.sin(rot) * 1.9, y, z: z - Math.cos(rot) * 1.9, s: 2.2, rot: rot + Math.PI / 2 });
      }
      circle(x + tx * 2, z + tz * 2, 0.5); circle(x - tx * 2, z - tz * 2, 0.45);
      occ.mark(x, z, 3.2);
      interactables.push({ id: 'pstall' + i, kind: 'toast', x: x + Math.sin(rot) * 2.2, z: z + Math.cos(rot) * 2.2, y, r: 1.8, label: 'Browse the stall', message: ['Herb seedlings and lavender bundles.', 'Fresh bread and summer berries.', 'Apples by the barrel, carrots by the crate.'][i] });
      i++;
    }
    counts.marketRow = i;
  }
  // Kenney lanterns around the square, between the benches
  for (let i = 0; i < 4; i++) {
    const a = i * Math.PI / 2;
    const x = SQUARE.x + Math.cos(a) * (SQUARE.r + 0.9), z = SQUARE.z + Math.sin(a) * (SQUARE.r + 0.9);
    if (hf.maskAt(x, z) & 1) continue;
    putG('k-lantern', { x, y: Y(x, z), z, s: 2.0 });
    circle(x, z, 0.2);
  }
  // carts by the lanes
  {
    let n = 0;
    for (const l of lanes) {
      if (l.walk || l.type === 'trail' || n >= 3) continue;
      const s = l.samples[Math.floor(l.samples.length * (0.2 + rand() * 0.6))];
      if (!s || s.bridge) continue;
      const sd = rand() < 0.5 ? -1 : 1;
      const x = s.x + s.nx * sd * (l.w / 2 + 2.3), z = s.z + s.nz * sd * (l.w / 2 + 2.3);
      if (!freeOf(x, z, 0.6) || occAt(x, z, 0) !== 0 || hf.riverDist(x, z) < 2 || !fp.fits(x, z, 1.1)) continue;
      putG(n % 2 ? 'k-cart-high' : 'k-cart', { x, y: Y(x, z), z, s: 1.9, rot: Math.atan2(s.nx, s.nz) + 0.4 });
      circle(x, z, 1.1); occ.mark(x, z, 1.8); n++;
    }
  }

  // --- houses: ivy, banners, hedges, gates, ornamental railings, vases, buckets ---
  const vines = ['v-vine-1', 'v-vine-2', 'v-vine-4', 'v-vine-5'];
  for (const h of houses) {
    const PL = 0.5;
    const facade = (side, lx, lz) => {
      // side 0 front, 1 right, 3 left
      if (side === 0) return [...h.toWorld(lx, h.d / 2 + lz), h.rot];
      if (side === 1) return [...h.toWorld(h.w / 2 + lz, -lx), h.rot + Math.PI / 2];
      return [...h.toWorld(-h.w / 2 - lz, lx), h.rot - Math.PI / 2];
    };
    if (rand() < 0.45) {
      // ivy climbing a side wall
      const side = rand() < 0.5 ? 1 : 3;
      const n = 1 + Math.floor(rand() * 2);
      for (let k = 0; k < n; k++) {
        const [x, z, r] = facade(side, (k ? 1 : -1) * (h.d / 2 - 0.55), 0.12);
        putG(pick(vines), { x, y: h.groundY + PL, z, rot: r, s: 1, sy: (h.wallH * 0.95) / 2.6 }, FOLIAGE);
      }
    }
    if (h.domain === 'work' || h.domain === 'money') {
      for (const sx of [-1, 1]) {
        const [x, z, r] = facade(0, h.doorLocal[0] + sx * 1.9, 0.0);
        if (h.cross) continue;
        putG(sx > 0 ? 'k-banner-green' : 'k-banner-red', { x, y: h.groundY + PL + 2.0, z, rot: r - Math.PI / 2, s: 2.2 });
      }
    }
    if (h.domain === 'money' && !h.boundary) {
      // ornamental iron railing either side of the town hall path
      for (const sx of [-1, 1]) for (let k = 0; k < 2; k++) {
        const [x, z] = h.toWorld(h.doorLocal[0] + sx * (1.6 + k * 0.98), h.d / 2 + h.wingD + 1.5);
        if (occAt(x, z) === 1) continue;
        putG('v-metal-fence', { x, y: Y(x, z), z, rot: h.rot, s: 0.5 });
        circle(x, z, 0.3);
      }
    }
    if (h.style === 'townhouse' && h.domain !== 'money' && !h.boundary) {
      // clipped hedges framing the front
      for (const sx of [-1, 1]) {
        const [x, z] = h.toWorld(h.doorLocal[0] + sx * 2.4, h.d / 2 + h.wingD + 1.3);
        if (!freeOf(x, z, 0)) continue;
        putG('k-hedge-large', { x, y: Y(x, z), z, rot: h.rot + Math.PI / 2, s: 2.2 });
        circle(x, z, 0.5);
      }
    }
    if (rand() < 0.35) { const [x, z] = h.toWorld(h.doorLocal[0] - 1.25, h.doorLocal[1] + 1.4); if (occAt(x, z) !== 1) putG(pick(['p-vase-2', 'p-vase-4']), { x, y: Y(x, z), z, s: 0.75 }); }
    if (rand() < 0.25) { const [x, z] = h.toWorld(h.w / 2 + 0.7, h.d / 4); if (freeOf(x, z)) putG('p-bucket', { x, y: Y(x, z), z, s: 1.2 }); }
    if (h.garden && rand() < 0.5) { const [x, z] = h.toWorld(-h.w / 2 - 1.6, h.d / 2 + 0.9); if (freeOf(x, z, 0.5)) putG('n-bush-flowers', { x, y: Y(x, z), z, s: 0.6 + rand() * 0.2 }, FOLIAGE_SH); }
    // stepping stones to the back garden
    if (rand() < 0.4) {
      const sx = rand() < 0.5 ? -1 : 1;
      for (let k = 0; k < 3; k++) {
        const [x, z] = h.toWorld(sx * (h.w / 2 + 1.3), h.d / 2 - 0.8 - k * 1.5);
        if (!freeOf(x, z)) break;
        putG(pick(['n-rockpath-1', 'n-rockpath-2', 'n-rockpath-3']), { x, y: Y(x, z) - 0.04, z, s: 0.9, rot: rand() * 6.28 }, { shadow: false });
      }
    }
  }

  // --- woodland: ferns, mushrooms, mossy rocks, ground plants ---
  for (let i = 0; i < 5000; i++) {
    const x = (rand() - 0.5) * 410, z = (rand() - 0.5) * 410;
    if (Math.hypot(x, z) > 204 || forestPatch(x, z) < 0.55 || villageDist(x, z) < 34) continue;
    if (!freeOf(x, z, 0) || hf.riverDist(x, z) < 2.5 || hf.slope(x, z) > 1.1) continue;
    const r = rand(), y = Y(x, z);
    if (r < 0.35) putG('n-fern', { x, y, z, s: 0.55 + rand() * 0.4 }, FOLIAGE);
    else if (r < 0.55) putG('n-plant-7', { x, y, z, s: 0.9 + rand() * 0.6 }, FOLIAGE);
    else if (r < 0.68) putG(rand() < 0.75 ? 'n-mushroom' : 'n-mushroom-shelf', { x, y, z, s: 0.7 + rand() * 0.6 });
    else if (r < 0.78) putG(pick(['n-clover-1', 'n-clover-2']), { x, y, z, s: 0.4 + rand() * 0.2 }, FOLIAGE);
    else if (r < 0.86 && clear(x, z, 2) && fp.fits(x, z, 1.2)) { putG(pick(['n-rock-1', 'n-rock-2', 'n-rock-3']), { x, y: y - 0.25, z, s: 0.5 + rand() * 0.6 }); circle(x, z, 1.2); occ.mark(x, z, 2); }
  }

  // --- meadows: painted wildflower groups, hero trees ---
  for (let i = 0; i < 6000; i++) {
    const x = (rand() - 0.5) * 400, z = (rand() - 0.5) * 400;
    if (Math.hypot(x, z) > 198 || !isMeadow(x, z) || villageDist(x, z) < 20) continue;
    if (!clear(x, z, 0) || hf.riverDist(x, z) < 2 || hf.maskAt(x, z)) continue;
    if (noise(x * 0.05 - 9, z * 0.05 + 21) < 0.1) continue; // painted flowers cluster in patches
    const y = Y(x, z), r = rand();
    if (r < 0.45) putG(rand() < 0.6 ? 'n-flower-3' : 'n-flower-4', { x, y, z, s: 0.32 + rand() * 0.2 }, FOLIAGE);
    else if (r < 0.75) putG('n-plant-7', { x, y, z, s: 0.8 + rand() * 0.6 }, FOLIAGE);
  }
  {
    let n = 0;
    for (let t = 0; t < 3000 && n < 26; t++) {
      const x = (rand() - 0.5) * 300, z = (rand() - 0.5) * 300;
      if (Math.hypot(x, z) > 160 || !isMeadow(x, z) || villageDist(x, z) < 18) continue;
      if (!clear(x, z, 3) || hf.riverDist(x, z) < 4 || hf.slope(x, z) > 0.6) continue;
      putG(rand() < 0.5 ? 'n-tree-1' : 'n-tree-3', { x, y: Y(x, z), z, s: 0.85 + rand() * 0.35 }, { sway: [1.5, 0.02], shadow: true });
      circle(x, z, 0.4); occ.mark(x, z, 3.5); n++;
    }
  }

  // --- riverbanks: painted pebbles, rounded stones, waterside plants ---
  for (let i = 0; i < samples.length; i += 2) {
    const s = samples[i];
    if (s.z < -200 || s.z > 200) continue;
    const hw = halfWidth(s.z);
    for (const side of [-1, 1]) {
      if (rand() > 0.22) continue;
      const off = (hw + 0.4 + rand() * 2.2) * side;
      const x = s.x - s.tz * off, z = s.z + s.tx * off;
      if (nearBridge(x, z, 1) || occAt(x, z) === 1) continue;
      const r = rand(), y = Y(x, z);
      if (r < 0.55) putG(pick(['n-pebble-1', 'n-pebble-2', 'n-pebble-3', 'n-pebble-4', 'n-pebble-5']), { x, y: y - 0.02, z, s: 0.8 + rand() * 1.6 });
      else if (r < 0.75) putG('n-plant-1', { x, y, z, s: 0.35 + rand() * 0.2 }, FOLIAGE);
      else if (r < 0.88) putG('n-rockpath-thin', { x, y: y - 0.04, z, s: 0.9, rot: Math.atan2(s.tx, s.tz) }, { shadow: false });
      else if (clear(x, z, 1)) { putG('k-rock-wide', { x, y: y - 0.1, z, s: 1.3 }); circle(x, z, 0.7); }
    }
  }
}

// Tower mill built with the village architecture materials: rubble stone base, lime-plaster tower,
// a timber reefing stage with railings, framed windows with shutters and window boxes, a hooded door
// and a tiled cap with a brass finial.
function windmillTower() {
  const b = new Batcher();
  const add = (g, m, mat) => b.add(g, m, mat);
  const rAt = (y) => (y < 0.9 ? 2.62 : 2.5 + (2.05 - 2.5) * Math.min(1, (y - 0.9) / 6.6));
  add(new THREE.CylinderGeometry(2.62, 2.75, 1.0, 28), mat4(0, 0.4, 0), MAT.stone);
  add(new THREE.CylinderGeometry(2.66, 2.66, 0.12, 28), mat4(0, 0.92, 0), MAT.stoneTrim);
  add(new THREE.LatheGeometry([new THREE.Vector2(2.5, 0.9), new THREE.Vector2(2.36, 3), new THREE.Vector2(2.05, 7.5), new THREE.Vector2(0.01, 7.5)], 28), mat4(0, 0, 0), MAT.wall_cream);
  // string course and cornice
  add(new THREE.CylinderGeometry(rAt(4.2) + 0.06, rAt(4.2) + 0.06, 0.16, 28), mat4(0, 4.2, 0), MAT.stoneTrim);
  add(new THREE.CylinderGeometry(2.2, 2.12, 0.22, 28), mat4(0, 7.5, 0), MAT.trim);
  // reefing stage on brackets with a simple railing
  add(new THREE.CylinderGeometry(3.25, 3.25, 0.12, 28), mat4(0, 4.0, 0), MAT.wood);
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2;
    add(G.box(), mat4(Math.sin(a) * 2.75, 3.75, Math.cos(a) * 2.75, 0, a, -0.0, 0.1, 0.4, 0.9), MAT.woodDark);
    add(G.box(), mat4(Math.sin(a) * 3.15, 4.42, Math.cos(a) * 3.15, 0, a, 0, 0.07, 0.75, 0.07), MAT.wood);
  }
  add(new THREE.TorusGeometry(3.15, 0.05, 6, 40).rotateX(Math.PI / 2), mat4(0, 4.78, 0), MAT.wood);
  add(new THREE.TorusGeometry(3.15, 0.035, 6, 40).rotateX(Math.PI / 2), mat4(0, 4.42, 0), MAT.wood);
  // cap
  const cap = new THREE.LatheGeometry([new THREE.Vector2(2.45, 0), new THREE.Vector2(2.3, 0.5), new THREE.Vector2(1.55, 2.1), new THREE.Vector2(0.01, 2.9)], 28);
  { const uv = cap.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * 9, uv.getY(i) * 4); } // tile size to match house roofs
  add(cap, mat4(0, 7.55, 0), MAT.roof_terracotta);
  add(G.ball ? G.ball(1) : new THREE.SphereGeometry(1, 10, 8), mat4(0, 10.55, 0, 0, 0, 0, 0.18, 0.18, 0.18), MAT.brass);
  add(new THREE.CylinderGeometry(0.04, 0.04, 0.5, 6), mat4(0, 10.3, 0), MAT.brass);
  // wind shaft housing under the sails
  add(G.box(), mat4(0, 8.6, 2.65, 0, 0, 0, 0.9, 0.9, 2.5), MAT.woodDark);
  add(new THREE.CylinderGeometry(0.16, 0.16, 0.5, 10).rotateX(Math.PI / 2), mat4(0, 8.6, 3.75), MAT.iron);
  // door with stone surround and a little hood
  const dz = rAt(1.6) + 0.02;
  add(G.box(), mat4(0, 1.95, dz - 0.04, -0.03, 0, 0, 1.25, 2.2, 0.16), MAT.stoneTrim);
  add(G.box(), mat4(0, 1.9, dz + 0.03, -0.03, 0, 0, 0.95, 1.95, 0.08), MAT.door_green);
  add(G.box(), mat4(0.3, 1.9, dz + 0.09, 0, 0, 0, 0.08, 0.08, 0.04), MAT.brass);
  add(G.box(), mat4(0, 3.18, dz + 0.25, 0.35, 0, 0, 1.6, 0.08, 0.7), MAT.roof_terracotta);
  for (const sx of [-1, 1]) add(G.box(), mat4(sx * 0.7, 2.95, dz + 0.32, 0, 0, sx * 0.5, 0.06, 0.45, 0.06), MAT.woodDark);
  // windows: frame, glass, shutters, sill and window box
  for (const [y, a] of [[2.3, 1.35], [2.3, -1.35], [5.4, 0.55], [5.4, -0.7], [6.3, 2.7], [2.3, 3.14]]) {
    const r = rAt(y) + 0.02;
    // windows lean back with the tapering wall so frames, sills and shutters sit flush on it
    const lean = Math.atan(0.45 / 6.6);
    const W = (lx, ly, lz, sx, sy, sz, mat) => { const rr = rAt(y + ly) + 0.02 + lz; add(G.box(), mat4(Math.sin(a) * rr + Math.cos(a) * lx, y + ly, Math.cos(a) * rr - Math.sin(a) * lx, -lean, a, 0, sx, sy, sz), mat); };
    W(0, 0, 0.0, 0.84, 1.04, 0.1, MAT.trim);
    W(0, 0, 0.04, 0.64, 0.84, 0.04, MAT.glass);
    W(0, 0, 0.06, 0.05, 0.84, 0.03, MAT.trim);
    W(0, -0.58, 0.08, 0.98, 0.08, 0.22, MAT.stoneTrim);
    for (const sx of [-1, 1]) W(sx * 0.66, 0, 0.06, 0.4, 0.98, 0.05, MAT.shutter_green);
    if (y < 4) {
      W(0, -0.74, 0.18, 0.86, 0.2, 0.22, MAT.wood);
      for (let i = 0; i < 5; i++) W(-0.32 + i * 0.16, -0.58, 0.2, 0.14, 0.14, 0.14, [MAT.flowerPink, MAT.leaf, MAT.flowerWhite, MAT.leafDark, MAT.flowerLavender][i]);
    }
  }
  return b.build('windmill');
}
