// River definition: centreline, width, water level profile (with cascades) and fast spatial queries.
import * as THREE from 'three';
import { clamp, lerp } from '../core/math.js';

const CONTROL = [
  [-30, -700], [-26, -420], [-25, -300], [-18, -160], [12, -95], [4, -45], [-10, 0],
  [2, 45], [20, 95], [8, 150], [-8, 260], [-14, 420], [-15, 700],
];

// Water surface height keyed by z (river flows north -> south, i.e. towards +z).
// Short steep sections are the cascades.
const LEVELS = [
  [-700, 40], [-300, 14], [-120, 9.8], [-70, 8.9], [-56, 5.6], [64, 4.2], [78, 1.5],
  [130, 0.9], [144, -1.5], [300, -3.6], [700, -10],
];
export const CASCADES = [
  { z0: -70, z1: -56 },
  { z0: 64, z1: 78 },
  { z0: 130, z1: 144 },
];
export const RAPIDS = [[-110, -70], [-56, -40], [40, 64], [78, 96], [112, 130], [144, 162]];

export function waterLevel(z) {
  if (z <= LEVELS[0][0]) return LEVELS[0][1];
  for (let i = 1; i < LEVELS.length; i++) {
    const [z1, y1] = LEVELS[i];
    if (z <= z1) {
      const [z0, y0] = LEVELS[i - 1];
      let t = (z - z0) / (z1 - z0);
      const steep = Math.abs(y1 - y0) / (z1 - z0) > 0.08;
      if (steep) t = t * t * (3 - 2 * t); // rounded lip and plunge on cascades
      return lerp(y0, y1, t);
    }
  }
  return LEVELS[LEVELS.length - 1][1];
}

// Smoothed level, used for the valley floor so banks slope instead of stepping.
export function bankLevel(z) {
  let s = 0;
  for (let i = -4; i <= 4; i++) s += waterLevel(z + i * 7);
  return s / 9;
}

export function halfWidth(z) {
  let w = 5.6 + 1.1 * Math.sin(z * 0.031) + 0.6 * Math.sin(z * 0.083 + 1.3);
  for (const [a, b] of RAPIDS) if (z > a && z < b) w -= 0.9 * Math.sin(Math.PI * (z - a) / (b - a));
  for (const c of CASCADES) if (z > c.z0 - 6 && z < c.z1 + 10) w -= 1.2;
  return Math.max(3.6, w);
}

export function rapidness(z) {
  let r = 0.12;
  for (const [a, b] of RAPIDS) if (z > a && z < b) r = Math.max(r, Math.sin(Math.PI * (z - a) / (b - a)));
  for (const c of CASCADES) {
    if (z > c.z0 - 4 && z < c.z1 + 14) r = 1;
  }
  return r;
}

const curve = new THREE.CatmullRomCurve3(CONTROL.map(([x, z]) => new THREE.Vector3(x, 0, z)), false, 'centripetal');
const N = 1400;
export const samples = []; // {x,z,tx,tz,len}
{
  const pts = curve.getSpacedPoints(N);
  let len = 0;
  for (let i = 0; i <= N; i++) {
    const p = pts[i];
    const q = pts[Math.min(N, i + 1)], o = pts[Math.max(0, i - 1)];
    let tx = q.x - o.x, tz = q.z - o.z;
    const l = Math.hypot(tx, tz) || 1;
    if (i > 0) len += Math.hypot(p.x - pts[i - 1].x, p.z - pts[i - 1].z);
    samples.push({ x: p.x, z: p.z, tx: tx / l, tz: tz / l, len });
  }
}

const CELL = 12;
const buckets = new Map();
const key = (i, j) => i * 100000 + j;
samples.forEach((s, idx) => {
  const k = key(Math.floor(s.x / CELL), Math.floor(s.z / CELL));
  if (!buckets.has(k)) buckets.set(k, []);
  buckets.get(k).push(idx);
});

const _res = { d: 0, idx: 0, x: 0, z: 0, side: 0, along: 0 };
// Distance to the river centreline with the nearest point projected onto the segment.
export function riverQuery(x, z, out = _res) {
  const ci = Math.floor(x / CELL), cj = Math.floor(z / CELL);
  let best = Infinity, bi = 0;
  for (let i = ci - 2; i <= ci + 2; i++) for (let j = cj - 2; j <= cj + 2; j++) {
    const b = buckets.get(key(i, j));
    if (!b) continue;
    for (const idx of b) {
      const s = samples[idx];
      const d = (s.x - x) ** 2 + (s.z - z) ** 2;
      if (d < best) { best = d; bi = idx; }
    }
  }
  if (best > (2 * CELL) ** 2) {
    // far from the river: coarse scan then local refine
    best = Infinity;
    for (let idx = 0; idx < samples.length; idx += 8) {
      const s = samples[idx];
      const d = (s.x - x) ** 2 + (s.z - z) ** 2;
      if (d < best) { best = d; bi = idx; }
    }
    const c = bi;
    for (let idx = Math.max(0, c - 8); idx < Math.min(samples.length, c + 9); idx++) {
      const s = samples[idx];
      const d = (s.x - x) ** 2 + (s.z - z) ** 2;
      if (d < best) { best = d; bi = idx; }
    }
  }
  // refine on neighbouring segments
  let bestD = Infinity, px = 0, pz = 0, seg = bi;
  for (let k = Math.max(0, bi - 1); k < Math.min(samples.length - 1, bi + 1); k++) {
    const a = samples[k], b = samples[k + 1];
    const vx = b.x - a.x, vz = b.z - a.z;
    const t = clamp(((x - a.x) * vx + (z - a.z) * vz) / (vx * vx + vz * vz || 1), 0, 1);
    const qx = a.x + vx * t, qz = a.z + vz * t;
    const d = (qx - x) ** 2 + (qz - z) ** 2;
    if (d < bestD) { bestD = d; px = qx; pz = qz; seg = k; }
  }
  const s = samples[seg];
  out.d = Math.sqrt(bestD);
  out.idx = seg;
  out.x = px; out.z = pz;
  out.side = Math.sign((x - px) * s.tz - (z - pz) * s.tx) || 1;
  out.along = s.len;
  return out;
}
