// Procedural European village houses. One architectural language shared by every building:
// stone plinths with a cap band, lime-plaster walls, deep window and door surrounds with recessed
// glazing, sills and lintels, shutters, tiled roofs with fascia boards, gutters and downpipes,
// segmented ridge tiles and proper chimneys. Domain buildings add distinctive features (clock tower,
// conservatory, porch and bay window, workshop lean-to, arched doorway, carved chalet gable).
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mulberry32 } from '../core/math.js';
import { MAT } from './materials.js';
import { mat4, boxProjectUV } from './batcher.js';

const FLOOR_H = 2.75;
const PLINTH = 0.55;

const G = {
  box: new THREE.BoxGeometry(1, 1, 1),
  rbox: new RoundedBoxGeometry(1, 1, 1, 2, 0.08),
  cyl: new THREE.CylinderGeometry(1, 1, 1, 12),
  cyl6: new THREE.CylinderGeometry(1, 1, 1, 8),
  halfCyl: new THREE.CylinderGeometry(1, 1, 1, 10, 1, false, 0, Math.PI),
  sphere: new THREE.SphereGeometry(1, 10, 8),
  cone: new THREE.ConeGeometry(1, 1, 8),
  pyramid: new THREE.ConeGeometry(1, 1, 4, 1).rotateY(Math.PI / 4),
  ball: new THREE.IcosahedronGeometry(1, 1),
};
const rboxCache = new Map();
function rbox(w, h, d, r) {
  const k = [w, h, d, r].map((v) => v.toFixed(2)).join('|');
  if (!rboxCache.has(k)) rboxCache.set(k, new RoundedBoxGeometry(w, h, d, Math.max(w, h, d) < 1.2 ? 1 : 2, Math.min(r, w / 2 - 0.001, h / 2 - 0.001, d / 2 - 0.001)));
  return rboxCache.get(k);
}
// Roof slab whose UVs are scaled so tiles keep a constant size (0.3 m courses) on every roof.
const slabCache = new Map();
function roofSlab(width, thick, L) {
  const k = [width, thick, L].map((v) => v.toFixed(2)).join('|');
  if (!slabCache.has(k)) {
    const g = new RoundedBoxGeometry(width, thick, L, 2, Math.min(0.06, thick / 2 - 0.001));
    const uv = g.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * width / 1.2, uv.getY(i) * L / 1.2);
    slabCache.set(k, g);
  }
  return slabCache.get(k);
}
function prism(span, rise, length) {
  const s = new THREE.Shape();
  s.moveTo(-span / 2, 0); s.lineTo(span / 2, 0); s.lineTo(0, rise); s.closePath();
  const g = new THREE.ExtrudeGeometry(s, { depth: length, bevelEnabled: false });
  g.translate(0, 0, -length / 2);
  g.rotateY(Math.PI / 2);
  return g;
}

const PITCH = { cottage: 42, townhouse: 46, chalet: 27, modern: 38 };

export function planHouse(h) {
  const r = mulberry32(h.seed || 1);
  h.pitch = THREE.MathUtils.degToRad(PITCH[h.style] ?? 42);
  h.wallH = h.floors * FLOOR_H + (h.style === 'townhouse' ? 0.2 : 0);
  if (h.cross) {
    h.wingW = Math.min(h.w * 0.46, 3.9);
    h.wingD = 1.8 + r() * 0.8;
    h.wingX = (r() < 0.5 ? -1 : 1) * (r() < 0.5 ? 0 : h.w * 0.22);
    h.doorLocal = [h.wingX, h.d / 2 + h.wingD];
  } else {
    h.wingW = 0; h.wingD = 0; h.wingX = 0;
    h.doorLocal = [(r() < 0.5 ? 0 : (r() < 0.5 ? -1 : 1) * h.w * 0.2), h.d / 2];
  }
  const c = Math.cos(h.rot), s = Math.sin(h.rot);
  const toWorld = (lx, lz) => [h.x + lx * c + lz * s, h.z - lx * s + lz * c];
  h.toWorld = toWorld;
  h.door = { local: h.doorLocal, world: toWorld(h.doorLocal[0], h.doorLocal[1]), front: toWorld(h.doorLocal[0], h.doorLocal[1] + 1.4) };
  // side annexes (conservatory, lean-to) need a wider plot
  const sideAnnex = h.domain === 'health' || h.domain === 'work' ? 3.2 : 0;
  h.pad = { hx: h.w / 2 + 1.6 + sideAnnex, hz: h.d / 2 + 1.6 + h.wingD / 2, oz: h.wingD / 2 };
  return h;
}

// Gable roof (ridge along local x): tiled slabs, bargeboards, fascia, gutters, ridge tiles, attic.
function gableRoof(add, frame, o) {
  const { along, span, wallTop, pitch, eave, gableOver, roofMat, ridgeMat, atticMat, thick = 0.24, attic = true, trim = true, gutter = false, ridgeTiles = true } = o;
  const hs = span / 2;
  const rise = hs * Math.tan(pitch);
  const ridgeY = wallTop + rise;
  const L = (hs + eave) / Math.cos(pitch);
  const width = along + gableOver * 2;
  const F = (m) => frame.clone().multiply(m);
  const eaveY = wallTop - Math.tan(pitch) * eave;
  for (const side of [1, -1]) {
    const dir = new THREE.Vector3(0, -Math.sin(pitch), Math.cos(pitch) * side);
    const nrm = new THREE.Vector3(0, Math.cos(pitch), Math.sin(pitch) * side);
    const c = new THREE.Vector3(0, ridgeY, 0).addScaledVector(dir, L / 2).addScaledVector(nrm, thick / 2);
    add(roofSlab(width, thick, L), F(mat4(c.x, c.y, c.z, pitch * side, 0, 0)), roofMat);
    if (trim) {
      for (const gx of [-1, 1]) {
        const bc = c.clone().addScaledVector(nrm, -thick / 2 - 0.1);
        bc.x = gx * (width / 2 - 0.06);
        add(rbox(0.14, 0.36, L + 0.04, 0.04), F(mat4(bc.x, bc.y, bc.z, pitch * side, 0, 0)), MAT.trim);
      }
      // fascia board closing the eave
      add(rbox(width, 0.24, 0.07, 0.03), F(mat4(0, eaveY + 0.02, side * (hs + eave + 0.02))), MAT.trim);
    }
    if (gutter) {
      add(G.cyl, F(mat4(0, eaveY - 0.06, side * (hs + eave + 0.12), 0, 0, Math.PI / 2, 0.085, width - 0.2, 0.085)), MAT.gutter);
      // swan-neck and downpipe at one end of each eave
      const px = (side > 0 ? 1 : -1) * (along / 2 - 0.25);
      add(G.cyl6, F(mat4(px, eaveY - 0.25, side * (hs + eave / 2 + 0.1), side * 0.9, 0, 0, 0.045, eave + 0.1, 0.045)), MAT.gutter);
      const top = eaveY - 0.4, bot = 0.15;
      add(G.cyl6, F(mat4(px, (top + bot) / 2, side * (hs + 0.1), 0, 0, 0, 0.05, top - bot, 0.05)), MAT.gutter);
      add(G.cyl6, F(mat4(px, bot + 0.05, side * (hs + 0.2), side * 0.8, 0, 0, 0.055, 0.25, 0.055)), MAT.gutter);
      for (const y of [top - 0.3, (top + bot) / 2, bot + 0.6]) add(G.box, F(mat4(px, y, side * (hs + 0.07), 0, 0, 0, 0.14, 0.04, 0.06)), MAT.gutter);
    }
  }
  if (ridgeTiles) {
    const n = Math.max(2, Math.round(width / 0.42));
    const seg = width / n;
    for (let i = 0; i < n; i++) {
      const x = -width / 2 + seg * (i + 0.5);
      add(G.cyl, F(mat4(x, ridgeY + thick * 0.72, 0, 0, 0, Math.PI / 2, 0.15 * thick / 0.24, seg * 1.04, 0.15 * thick / 0.24)), ridgeMat);
    }
  } else add(G.cyl, F(mat4(0, ridgeY + thick * 0.72, 0, 0, 0, Math.PI / 2, 0.14, width - 0.06, 0.14)), ridgeMat);
  if (attic) add(prism(span, rise, along), F(mat4(0, wallTop - 0.001, 0)), atticMat);
  return { ridgeY, rise, eaveY, width };
}

// Window on a facade. m = facade frame (local +z out, origin on the wall surface).
// The surround stands proud of the wall so the glazing reads as recessed into a thick wall.
function windowAt(add, m, u, y, o) {
  const { w = 0.9, h = 1.2, frame = MAT.trim, surround = MAT.trim, shutters = null, flowers = false, muntins = true, rand,
    awning = null, juliet = false, lintel = null, keystone = false, curtains = true, sill = MAT.stoneTrim } = o;
  const f = (x, yy, z, sx, sy, sz, mat, g = G.box, rz = 0, ry = 0) => add(g, m.clone().multiply(mat4(x, yy, z, 0, ry, rz, sx, sy, sz)), mat);
  const D = 0.2; // reveal depth
  // interior, curtains and glass inside the reveal
  f(u, y, 0.01, w, h, 0.02, MAT.interior);
  if (curtains && rand() < 0.65) for (const s of [-1, 1]) f(u + s * (w / 2 - w * 0.13), y + 0.02, 0.03, w * 0.26, h * 0.95, 0.02, MAT.curtain);
  f(u, y, 0.055, w, h, 0.012, MAT.glass);
  // sash frame and glazing bars
  f(u, y + h / 2 - 0.03, 0.06, w, 0.06, 0.06, frame); f(u, y - h / 2 + 0.03, 0.06, w, 0.06, 0.06, frame);
  f(u - w / 2 + 0.03, y, 0.06, 0.06, h, 0.06, frame); f(u + w / 2 - 0.03, y, 0.06, 0.06, h, 0.06, frame);
  if (muntins) { f(u, y, 0.07, 0.04, h, 0.035, frame); f(u, y + h * 0.12, 0.07, w, 0.04, 0.035, frame); }
  // deep surround (the reveal)
  const sw = 0.13;
  f(u, y + h / 2 + sw / 2, D / 2, w + sw * 2, sw, D, surround, G.box);
  f(u - w / 2 - sw / 2, y, D / 2, sw, h, D, surround, G.box);
  f(u + w / 2 + sw / 2, y, D / 2, sw, h, D, surround, G.box);
  // projecting sill with a drip
  f(u, y - h / 2 - 0.05, 0.15, w + 0.42, 0.09, 0.3, sill, G.box);
  if (lintel) {
    f(u, y + h / 2 + sw + 0.08, 0.12, w + 0.5, 0.17, 0.24, lintel, G.box);
    if (keystone) f(u, y + h / 2 + sw + 0.1, 0.16, 0.22, 0.26, 0.26, lintel, G.box);
  }
  if (shutters) for (const s of [-1, 1]) {
    // louvred shutters, folded back a little from the wall
    const sx = u + s * (w / 2 + sw + 0.22);
    f(sx, y, 0.07, 0.42, h + 0.08, 0.05, shutters, G.box, 0, s * 0.12);
    for (let i = 0; i < 6; i++) f(sx, y - h / 2 + 0.16 + i * (h - 0.24) / 5, 0.1, 0.34, 0.035, 0.02, shutters, G.box, 0, s * 0.12);
    f(u + s * (w / 2 + sw + 0.02), y + h / 2 - 0.15, 0.08, 0.05, 0.05, 0.05, MAT.iron);
  }
  if (awning) {
    const n = 6, aw = (w + 0.6) / n;
    for (let i = 0; i < n; i++) {
      const mat = i % 2 ? MAT.awningA : awning;
      add(G.box, m.clone().multiply(mat4(u - (w + 0.6) / 2 + aw * (i + 0.5), y + h / 2 + sw + 0.44, 0.42, 0.75, 0, 0, aw, 0.03, 0.78)), mat);
      add(G.cone, m.clone().multiply(mat4(u - (w + 0.6) / 2 + aw * (i + 0.5), y + h / 2 + sw + 0.1, 0.72, 0, 0, Math.PI, aw / 2, 0.12, 0.02)), mat);
    }
    for (const s of [-1, 1]) add(G.cyl6, m.clone().multiply(mat4(u + s * (w / 2 + 0.28), y + h / 2 + sw + 0.3, 0.38, 0.9, 0, 0, 0.015, 0.75, 0.015)), MAT.iron);
  }
  if (juliet) {
    const rw = w + 0.36;
    f(u, y - h / 2 + 0.02, 0.3, rw, 0.05, 0.4, MAT.iron);
    f(u, y - h / 2 + 0.62, 0.48, rw, 0.04, 0.04, MAT.iron);
    for (let i = 0; i <= 8; i++) f(u - rw / 2 + (rw * i) / 8, y - h / 2 + 0.33, 0.48, 0.022, 0.6, 0.022, MAT.iron);
    for (let i = 0; i < 6; i++) f(u - rw / 2 + 0.1 + (rw - 0.2) * (i / 5), y - h / 2 + 0.12, 0.38, 0.12, 0.12, 0.12, i % 2 ? MAT.flowerPink : MAT.leaf, G.ball);
  }
  if (flowers) {
    const bw = w + 0.24;
    f(u, y - h / 2 - 0.28, 0.32, bw, 0.24, 0.28, MAT.wood, G.box);
    f(u, y - h / 2 - 0.17, 0.32, bw - 0.06, 0.03, 0.22, MAT.soil);
    for (const s of [-1, 1]) f(u + s * (bw / 2 - 0.12), y - h / 2 - 0.42, 0.28, 0.05, 0.06, 0.22, MAT.iron);
    const cols = [MAT.flowerPink, MAT.flowerRed, MAT.flowerWhite, MAT.flowerLavender, MAT.flowerBlue];
    const pal = [cols[Math.floor(rand() * cols.length)], cols[Math.floor(rand() * cols.length)]];
    for (let i = 0; i < 9; i++) {
      const xx = u - bw / 2 + 0.08 + (i / 8) * (bw - 0.16);
      if (i % 3 === 1) f(xx, y - h / 2 - 0.1, 0.32, 0.13, 0.11, 0.13, MAT.leaf, G.ball);
      else f(xx, y - h / 2 - 0.05 + (i % 2) * 0.04, 0.3 + (i % 2) * 0.06, 0.09, 0.08, 0.09, pal[i % 2], G.ball);
    }
    // trailing foliage spilling softly over the front of the box
    for (let i = 0; i < 7; i++) f(u - bw / 2 + 0.1 + i * (bw - 0.2) / 6, y - h / 2 - 0.24 - (i % 3) * 0.07, 0.47, 0.075, 0.09, 0.025, i % 2 ? MAT.leafDark : MAT.leaf, G.ball, (i % 2 ? 1 : -1) * 0.5);
  }
}

function spaced(count, span) {
  const out = [];
  for (let i = 0; i < count; i++) out.push(-span / 2 + (span * (i + 0.5)) / count);
  return out;
}

const doorGeo = (() => {
  const parts = [];
  const leaf = new THREE.BoxGeometry(1.02, 2.12, 0.08); leaf.translate(0.51, 1.06, 0); parts.push(leaf);
  for (const [y, hh] of [[0.55, 0.7], [1.45, 0.8]]) for (const x of [0.28, 0.74]) { const p = new THREE.BoxGeometry(0.34, hh, 0.04); p.translate(x, y, 0.05); parts.push(p); }
  const rail = new THREE.BoxGeometry(0.9, 0.06, 0.03); rail.translate(0.51, 1.0, 0.055); parts.push(rail);
  for (const p of parts) boxProjectUV(p, 1.0);
  return parts;
})();

// Builds one house into the batcher. Returns colliders and the animated door.
export function buildHouse(h, add, groundY) {
  const rand = mulberry32((h.seed || 7) + 13);
  const base = mat4(h.x, groundY, h.z, 0, h.rot, 0);
  const style = h.style;
  const wallMat = MAT['wall_' + (h.wall || 'cream')];
  const roofMat = MAT['roof_' + (h.roof || 'orange')];
  const ridgeMat = MAT['ridge_' + (h.roof || 'orange')];
  const upperMat = style === 'chalet' ? MAT.wood : wallMat;
  const frameMat = style === 'modern' ? MAT.frameDark : MAT.trim;
  const shutters = h.shutters ? MAT['shutter_' + h.shutters] : null;
  const dr = mulberry32((h.seed || 7) + 991);
  const pick = (arr) => arr[Math.floor(dr() * arr.length)];
  const doorMat = MAT['door_' + pick(['green', 'blue', 'lavender', 'terracotta', 'wood', 'cream'])];
  let awning = (style === 'cottage' || style === 'townhouse') && dr() < 0.4 ? MAT['awning_' + pick(['green', 'blue', 'lavender', 'pink'])] : null;
  const julietOn = h.floors > 1 && style !== 'chalet' && style !== 'modern' && dr() < 0.45;
  if (julietOn) awning = null; // an awning would run into the balcony directly above it
  const timber = h.floors > 1 && (style === 'cottage' || style === 'townhouse') && dr() < 0.45 && h.domain !== 'money' && h.domain !== 'taxes';
  const vane = style !== 'modern' && dr() < 0.4;
  const finials = !vane && style !== 'modern' && dr() < 0.5;
  const wisteria = style !== 'modern' && dr() < 0.3;
  const ivy = dr() < 0.22;
  const oculus = style !== 'modern' && dr() < 0.35;
  const civic = style === 'townhouse' || h.domain === 'money' || h.domain === 'taxes';
  const quoins = civic && style !== 'chalet';
  const surround = civic ? MAT.stoneTrim : style === 'chalet' ? MAT.wood : MAT.trim;
  const lintel = civic ? MAT.stoneTrim : style === 'chalet' || style === 'modern' ? null : (timber ? MAT.timber : null);
  const bay = !h.domain && style === 'cottage' && dr() < 0.3;
  const leanTo = !h.domain && style !== 'modern' && dr() < 0.18;
  h.details = { awning: !!awning, juliet: julietOn, timber, vane, finials, wisteria, ivy, oculus, quoins, bay, leanTo };
  const { w, d, wallH, pitch } = h;
  const wallTop = PLINTH + wallH;
  const L = (g, m, mat) => add(g, base.clone().multiply(m), mat);
  const box = (x, y, z, sx, sy, sz, mat, r = 0.1) => L(rbox(sx, sy, sz, r), mat4(x, y, z), mat);
  const colliders = [];

  // ---- foundations and walls ----
  const plinthBox = (x, z, pw, pd) => {
    box(x, PLINTH / 2 - 0.65, z, pw + 0.36, PLINTH + 1.3, pd + 0.36, MAT.stone, 0.06);
    box(x, PLINTH + 0.02, z, pw + 0.44, 0.1, pd + 0.44, MAT.stoneTrim, 0.03);
  };
  plinthBox(0, 0, w, d);
  if (style === 'chalet' && h.floors > 1) {
    box(0, PLINTH + FLOOR_H / 2, 0, w, FLOOR_H, d, wallMat, 0.12);
    box(0, PLINTH + FLOOR_H + (wallH - FLOOR_H) / 2, 0, w + 0.08, wallH - FLOOR_H, d + 0.08, upperMat, 0.06);
    // log-style corner notches
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) for (let i = 0; i < 6; i++) box(sx * (w / 2 + 0.02), PLINTH + FLOOR_H + 0.2 + i * 0.42, sz * (d / 2 + 0.02), 0.22, 0.18, 0.22, MAT.woodDark, 0.03);
  } else {
    box(0, PLINTH + wallH / 2, 0, w, wallH, d, wallMat, 0.12);
  }
  if (style === 'townhouse' && h.floors > 1) box(0, PLINTH + FLOOR_H, 0, w + 0.14, 0.18, d + 0.14, MAT.stoneTrim, 0.04);
  if (quoins) {
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) for (let i = 0; i * 0.42 < wallH - 0.3; i++) {
      const long = i % 2 === 0;
      box(sx * (w / 2 - (long ? 0.22 : 0.14) + 0.03), PLINTH + 0.25 + i * 0.42, sz * (d / 2 + 0.03), long ? 0.5 : 0.34, 0.36, 0.08, MAT.stoneTrim, 0.03);
      box(sx * (w / 2 + 0.03), PLINTH + 0.25 + i * 0.42, sz * (d / 2 - (long ? 0.14 : 0.22) + 0.03), 0.08, 0.36, long ? 0.34 : 0.5, MAT.stoneTrim, 0.03);
    }
  }
  if (style === 'modern') {
    for (let i = 0; i < 9; i++) box(-w / 2 + 0.25 + i * 0.2, PLINTH + wallH / 2, d / 2 + 0.03, 0.12, wallH, 0.06, MAT.wood, 0.02);
  }

  // ---- roofs ----
  const eave = style === 'chalet' ? 1.0 : style === 'modern' ? 0.3 : 0.5;
  const gableOver = style === 'chalet' ? 0.9 : style === 'modern' ? 0.15 : 0.35;
  const main = gableRoof(L, new THREE.Matrix4(), {
    along: w, span: d, wallTop, pitch, eave, gableOver, roofMat, ridgeMat, atticMat: upperMat, thick: style === 'chalet' ? 0.3 : 0.24, gutter: style !== 'chalet',
  });
  colliders.push({ x: h.x, z: h.z, rot: h.rot, hx: w / 2 + 0.3, hz: d / 2 + 0.3, y0: groundY - 1, y1: groundY + main.ridgeY });
  if (style === 'chalet') {
    // knee braces under the deep chalet eaves, carved sunburst in the gables
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) L(G.box, mat4(sx * (w / 2 + 0.25), wallTop - 0.45, sz * (d / 2 + 0.45), sz * 0.75, 0, 0, 0.12, 1.1, 0.12), MAT.woodDark);
    for (const sx of [-1, 1]) for (let i = 0; i < 7; i++) {
      const a = -Math.PI / 2 + (i / 6) * Math.PI;
      L(G.box, mat4(sx * (w / 2 + 0.06), wallTop + 0.1 + Math.cos(a) * 0.5 * 0 + 0.55, Math.sin(a) * 0.55, a, 0, 0, 0.04, 1.1, 0.07), MAT.trim);
    }
  }

  let wing = null;
  if (h.cross) {
    const wz0 = d / 2 - h.wingW / 2 - 0.9, wz1 = d / 2 + h.wingD;
    const len = wz1 - wz0, cz = (wz0 + wz1) / 2;
    plinthBox(h.wingX, cz, h.wingW, len);
    box(h.wingX, PLINTH + wallH / 2, cz, h.wingW, wallH, len, wallMat, 0.12);
    const frame = mat4(h.wingX, 0, cz + 0.2, 0, Math.PI / 2, 0);
    gableRoof(L, frame, { along: len + 0.4, span: h.wingW, wallTop, pitch, eave: 0.4, gableOver: 0.35, roofMat, ridgeMat, atticMat: upperMat });
    // valley flashing where the wing roof meets the main roof
    for (const s of [-1, 1]) L(G.box, mat4(h.wingX + s * (h.wingW / 2 + 0.3), wallTop + 0.35, d / 2 - 0.45, 0.55, s * 0.6, 0, 0.12, 0.05, 1.6), ridgeMat);
    wing = { x: h.wingX, z0: wz0, z1: wz1 };
    const [wx, wz] = h.toWorld(h.wingX, (d / 2 + d / 2 + h.wingD) / 2);
    colliders.push({ x: wx, z: wz, rot: h.rot, hx: h.wingW / 2 + 0.3, hz: h.wingD / 2 + 0.3, y0: groundY - 1, y1: groundY + main.ridgeY - 0.5 });
  }

  // ---- chimney: stone stack with cap, flaunching and pots ----
  {
    const cx = (rand() < 0.5 ? -1 : 1) * w * 0.26, cz = -d * 0.2;
    const surf = wallTop + (d / 2 - Math.abs(cz)) * Math.tan(pitch);
    const top = main.ridgeY + 0.9;
    const hgt = top - surf + 0.6;
    const chMat = style === 'modern' ? MAT.frameDark : civic || style === 'chalet' ? MAT.stone : wallMat;
    box(cx, surf - 0.6 + hgt / 2, cz, 0.78, hgt, 0.78, chMat, 0.06);
    box(cx, top - 0.25, cz, 0.86, 0.12, 0.86, MAT.stoneTrim, 0.03);
    box(cx, top + 0.08, cz, 0.96, 0.16, 0.96, MAT.chimneyCap, 0.04);
    box(cx, top + 0.2, cz, 0.7, 0.08, 0.7, MAT.chimneyCap, 0.03);
    h.chimneyTop = [cx, top + 0.25, cz];
    const pots = 1 + Math.floor(dr() * 2);
    for (let i = 0; i < pots; i++) {
      const px = cx + (pots > 1 ? (i - 0.5) * 0.34 : 0);
      L(G.cyl, mat4(px, top + 0.42, cz, 0, 0, 0, 0.11, 0.42, 0.11), MAT.pot);
      L(G.cyl, mat4(px, top + 0.65, cz, 0, 0, 0, 0.13, 0.06, 0.13), MAT.pot);
    }
  }

  // ---- dormers ----
  if (h.dormers && style !== 'chalet' && style !== 'modern') {
    const xs = spaced(h.dormers, w - 1.6);
    for (const dx of xs) {
      if (wing && Math.abs(dx - wing.x) < h.wingW / 2 + 1.0) continue;
      const zf = d / 2 - 0.55;
      const ys = wallTop + (d / 2 - zf) * Math.tan(pitch);
      const dw = 1.45, dh = 1.3, dd = 1.9;
      box(dx, ys + dh / 2 - 0.15, zf - dd / 2, dw, dh + 0.3, dd, wallMat, 0.05);
      gableRoof(L, mat4(dx, 0, zf - dd / 2 + 0.15, 0, Math.PI / 2, 0), {
        along: dd + 0.3, span: dw, wallTop: ys + dh - 0.15, pitch: THREE.MathUtils.degToRad(44), eave: 0.15, gableOver: 0.12, roofMat, ridgeMat, atticMat: wallMat, thick: 0.16,
      });
      windowAt(L, mat4(dx, 0, zf), 0, ys + dh / 2 - 0.05, { w: 0.72, h: 0.78, frame: frameMat, surround: MAT.trim, sill: MAT.trim, rand });
    }
  }

  // ---- entrance: surround, recess, steps, hood, lamp, house number ----
  const [doorX, doorZ] = h.doorLocal;
  const df = mat4(doorX, 0, doorZ, 0, 0, 0);
  const DL = (g, m, mat) => L(g, df.clone().multiply(m), mat);
  const arched = h.domain === 'taxes' || h.domain === 'money';
  const dSur = civic ? MAT.stoneTrim : style === 'chalet' ? MAT.woodDark : MAT.trim;
  DL(G.box, mat4(0, PLINTH + 1.1, 0.01, 0, 0, 0, 1.12, 2.22, 0.02), MAT.interior);
  DL(rbox(0.2, 2.42, 0.26, 0.03), mat4(-0.66, PLINTH + 1.2, 0.13), dSur);
  DL(rbox(0.2, 2.42, 0.26, 0.03), mat4(0.66, PLINTH + 1.2, 0.13), dSur);
  DL(rbox(1.56, 0.22, 0.3, 0.03), mat4(0, PLINTH + 2.32, 0.15), dSur);
  if (arched) {
    // semicircular fanlight under a stone arch with a keystone
    DL(G.halfCyl, mat4(0, PLINTH + 2.43, 0.04, Math.PI / 2, 0, 0, 0.56, 0.04, 0.56), MAT.glass);
    for (let i = 0; i <= 8; i++) {
      const a = (i / 8) * Math.PI;
      DL(rbox(0.2, 0.28, 0.28, 0.03), mat4(Math.cos(a) * 0.68, PLINTH + 2.43 + Math.sin(a) * 0.68, 0.14, 0, 0, a - Math.PI / 2), MAT.stoneTrim);
    }
    DL(rbox(0.26, 0.38, 0.32, 0.03), mat4(0, PLINTH + 3.15, 0.17), MAT.stoneTrim);
  }
  DL(rbox(1.9, 0.26, 0.55, 0.05), mat4(0, PLINTH - 0.12, 0.36), MAT.stoneTrim);
  DL(rbox(2.2, 0.3, 0.6, 0.05), mat4(0, PLINTH - 0.4, 0.82), MAT.stone);
  // the steps (and the home porch deck) are walkable surfaces, so feet stand on them instead of in them
  const pads = [
    { x0: doorX - 0.95, x1: doorX + 0.95, z0: doorZ + 0.08, z1: doorZ + 0.64, y: PLINTH + 0.01 },
    { x0: doorX - 1.1, x1: doorX + 1.1, z0: doorZ + 0.52, z1: doorZ + 1.12, y: PLINTH - 0.25 },
  ];
  // wall lantern: iron cage around a warm lamp
  DL(G.box, mat4(1.0, PLINTH + 1.95, 0.22, 0, 0, 0, 0.16, 0.24, 0.16), MAT.lamp);
  DL(G.pyramid, mat4(1.0, PLINTH + 2.14, 0.22, 0, 0, 0, 0.16, 0.14, 0.16), MAT.iron);
  DL(G.box, mat4(1.0, PLINTH + 1.82, 0.22, 0, 0, 0, 0.18, 0.03, 0.18), MAT.iron);
  DL(G.box, mat4(1.0, PLINTH + 2.1, 0.1, 0, 0, 0, 0.03, 0.03, 0.22), MAT.iron);
  // house number plaque
  DL(G.cyl, mat4(-1.0, PLINTH + 1.7, 0.03, Math.PI / 2, 0, 0, 0.13, 0.03, 0.09), MAT.flowerBlue);
  if (!h.cross && !arched) {
    // timber door hood on brackets
    gableRoof(L, mat4(0, 0, 0.55, 0, Math.PI / 2, 0).premultiply(df), {
      along: 1.1, span: 1.6, wallTop: PLINTH + 2.65, pitch: THREE.MathUtils.degToRad(36), eave: 0.12, gableOver: 0.0, roofMat, ridgeMat, atticMat: MAT.trim, thick: 0.14, trim: false, ridgeTiles: false,
    });
    for (const s of [-1, 1]) DL(G.box, mat4(s * 0.72, PLINTH + 2.4, 0.38, 0.7, 0, 0, 0.1, 0.62, 0.1), MAT.woodDark);
  }
  const door = new THREE.Group();
  door.position.set(doorX - 0.51, PLINTH, doorZ + 0.06);
  for (const g of doorGeo) {
    const m = new THREE.Mesh(g, doorMat);
    m.castShadow = true;
    door.add(m);
  }
  const knob = new THREE.Mesh(G.sphere, MAT.brass);
  knob.scale.setScalar(0.05); knob.position.set(0.88, 1.05, 0.08);
  door.add(knob);
  const doorPivot = new THREE.Group();
  doorPivot.position.set(h.x, groundY, h.z);
  doorPivot.rotation.y = h.rot;
  doorPivot.add(door);

  // ---- windows ----
  const floorsY = [];
  for (let f = 0; f < h.floors; f++) floorsY.push(PLINTH + f * FLOOR_H + 1.5);
  const winW = style === 'modern' ? 1.5 : 0.92, winH = style === 'modern' ? 1.6 : 1.22;
  const facade = (side) => {
    if (side === 0) return { m: mat4(0, 0, d / 2), span: w };
    if (side === 2) return { m: mat4(0, 0, -d / 2, 0, Math.PI, 0), span: w };
    if (side === 1) return { m: mat4(w / 2, 0, 0, 0, Math.PI / 2, 0), span: d };
    return { m: mat4(-w / 2, 0, 0, 0, -Math.PI / 2, 0), span: d };
  };
  const annexSide = h.domain === 'health' ? 1 : h.domain === 'work' ? 3 : leanTo ? 3 : -1;
  for (let side = 0; side < 4; side++) {
    const { m, span } = facade(side);
    const n = Math.max(1, Math.floor((span - 0.8) / 2.3));
    const us = spaced(n, span - 1.2);
    floorsY.forEach((y, fi) => {
      for (const u of us) {
        if (side === 0) {
          // keep the whole window (shutters included) clear of the door surround, lantern, plaque and hood
          const ext = (style === 'modern' ? winW / 2 + 0.2 : winW / 2 + (shutters ? 0.56 : 0.2));
          if (fi === 0 && !h.cross && Math.abs(u - doorX) < 1.12 + ext) continue;
          if (h.cross && Math.abs(u - h.wingX) < h.wingW / 2 + 0.7) continue;
        }
        if (side === annexSide && fi === 0) continue;
        if (bay && side === 1 && fi === 0) continue;
        const big = style === 'modern' && fi === 0 && side === 0;
        windowAt(L, m, u, y, {
          w: big ? 1.9 : winW, h: big ? 1.9 : winH, frame: frameMat, surround, lintel, keystone: civic && fi === 0, shutters: style === 'modern' ? null : shutters,
          flowers: fi === 0 && side === 0 && style !== 'modern' && rand() < 0.75, muntins: style !== 'modern', rand,
          awning: side === 0 && fi === 0 ? awning : null, juliet: julietOn && side === 0 && fi === 1,
        });
      }
    });
    if ((side === 1 || side === 3) && main.rise > 1.6) {
      windowAt(L, m, 0, wallTop + main.rise * 0.38, { w: style === 'modern' ? 1.2 : 0.7, h: 0.85, frame: frameMat, surround: style === 'chalet' ? MAT.wood : MAT.trim, sill: MAT.trim, rand, muntins: style !== 'modern', curtains: false });
    }
  }
  if (h.cross) {
    const wm = mat4(h.wingX, 0, d / 2 + h.wingD);
    const wr = h.wingW / 2 * Math.tan(pitch);
    windowAt(L, wm, 0, h.floors > 1 ? floorsY[1] : wallTop + wr * 0.4, { w: 0.82, h: h.floors > 1 ? 1.22 : 0.8, frame: frameMat, surround, lintel, rand, shutters: h.floors > 1 ? shutters : null });
    for (const s of [-1, 1]) {
      const sm = mat4(h.wingX + s * h.wingW / 2, 0, d / 2 + h.wingD / 2 + 0.2, 0, s * Math.PI / 2, 0);
      windowAt(L, sm, 0, floorsY[0], { w: 0.75, h: 1.1, frame: frameMat, surround, rand, flowers: rand() < 0.5 });
    }
  }

  // ---- chalet balcony ----
  if (h.balcony && h.floors > 1) {
    const by = PLINTH + FLOOR_H;
    box(0, by, d / 2 + 0.65, w - 0.4, 0.16, 1.3, MAT.woodDark, 0.04);
    box(0, by + 1.0, d / 2 + 1.25, w - 0.4, 0.1, 0.14, MAT.woodDark, 0.03);
    const posts = Math.floor((w - 0.4) / 0.18);
    for (let i = 0; i <= posts; i++) box(-(w - 0.4) / 2 + i * ((w - 0.4) / posts), by + 0.5, d / 2 + 1.25, 0.1, 0.9, 0.05, i % 2 ? MAT.wood : MAT.timber, 0.02);
    for (const s of [-1, 1]) box(s * (w / 2 - 0.25), by - 0.6, d / 2 + 1.1, 0.16, 1.2, 0.16, MAT.woodDark, 0.03);
    // flower boxes all along the balcony rail
    const cols = [MAT.flowerPink, MAT.flowerRed, MAT.flowerWhite];
    for (let i = 0; i < Math.floor(w - 1); i++) {
      const x = -(w - 1.4) / 2 + i * ((w - 1.4) / Math.max(1, Math.floor(w - 1) - 1));
      box(x, by + 1.12, d / 2 + 1.42, 0.8, 0.2, 0.24, MAT.wood, 0.03);
      for (let k = 0; k < 4; k++) L(G.ball, mat4(x - 0.3 + k * 0.2, by + 1.28, d / 2 + 1.42 + (k % 2) * 0.05, 0, 0, 0, 0.1, 0.09, 0.1), k % 2 ? MAT.leaf : cols[(i + k) % 3]);
      L(G.cone, mat4(x, by + 0.9, d / 2 + 1.55, Math.PI, 0, 0, 0.07, 0.4, 0.07), MAT.leafDark);
    }
  }

  // ---- decorative details ----
  const facadeM = (side) => (side === 0 ? mat4(0, 0, d / 2) : side === 2 ? mat4(0, 0, -d / 2, 0, Math.PI, 0) : side === 1 ? mat4(w / 2, 0, 0, 0, Math.PI / 2, 0) : mat4(-w / 2, 0, 0, 0, -Math.PI / 2, 0));
  const onFace = (side, x, y, z, sx, sy, sz, mat, g = G.box, rz = 0) => L(g, facadeM(side).multiply(mat4(x, y, z, 0, 0, rz, sx, sy, sz)), mat);
  if (timber) {
    const y0 = PLINTH + FLOOR_H, y1 = wallTop;
    for (let side = 0; side < 4; side++) {
      const span = side % 2 ? d : w;
      onFace(side, 0, y0 + 0.06, 0.05, span + 0.06, 0.2, 0.08, MAT.timber, rbox(1, 1, 1, 0.02));
      onFace(side, 0, y1 - 0.08, 0.05, span + 0.06, 0.16, 0.08, MAT.timber, rbox(1, 1, 1, 0.02));
      const nW = Math.max(1, Math.floor((span - 0.8) / 2.3));
      const wu = spaced(nW, span - 1.2);
      const posts = [-span / 2 + 0.07, span / 2 - 0.07];
      for (let i = 0; i < wu.length - 1; i++) posts.push((wu[i] + wu[i + 1]) / 2);
      for (const x of posts) onFace(side, x, (y0 + y1) / 2, 0.05, 0.16, y1 - y0, 0.08, MAT.timber, rbox(1, 1, 1, 0.02));
      // diagonal braces only in the bay between the corner post and the outermost window (shutters
      // included), running exactly from the bottom rail at the corner to the top rail at the bay edge
      const ext = winW / 2 + (shutters ? 0.56 : 0.2) + 0.08;
      for (const sgn of [-1, 1]) {
        const outer = wu.length ? Math.max(...wu.map((u) => u * sgn)) : 0;
        const xa = span / 2 - 0.15, xb = outer + ext;
        const dx = xa - xb, dy = (y1 - 0.16) - (y0 + 0.16);
        if (dx < 0.45 || (side === 0 && (h.cross || h.balcony))) continue;
        const ang = Math.atan2(dx, dy), len = Math.hypot(dx, dy);
        onFace(side, sgn * (xa + xb) / 2, (y0 + y1) / 2, 0.055, 0.12, len, 0.07, MAT.timber, G.box, sgn * ang);
      }
      // timber pegs at the joints
      for (const x of posts) for (const y of [y0 + 0.06, y1 - 0.08]) onFace(side, x, y, 0.1, 0.04, 0.04, 0.03, MAT.woodDark);
    }
  }
  if (vane) {
    const vx = (dr() < 0.5 ? -1 : 1) * w * 0.32, top = main.ridgeY + 0.2;
    box(vx, top + 0.45, 0, 0.05, 0.9, 0.05, MAT.iron, 0.01);
    box(vx, top + 0.62, 0, 0.7, 0.04, 0.04, MAT.iron, 0.01);
    box(vx, top + 0.62, 0, 0.04, 0.04, 0.7, MAT.iron, 0.01);
    L(G.cone, mat4(vx + 0.38, top + 0.95, 0, 0, 0, -Math.PI / 2, 0.08, 0.2, 0.08), MAT.brass);
    box(vx - 0.05, top + 0.95, 0, 0.45, 0.2, 0.03, MAT.brass, 0.01);
    L(G.ball, mat4(vx, top + 1.12, 0, 0, 0, 0, 0.07, 0.07, 0.07), MAT.brass);
  }
  if (finials) for (const sx of [-1, 1]) {
    L(G.cone, mat4(sx * (w / 2 + 0.3), main.ridgeY + 0.5, 0, 0, 0, 0, 0.1, 0.5, 0.1), MAT.trim);
    L(G.ball, mat4(sx * (w / 2 + 0.3), main.ridgeY + 0.8, 0, 0, 0, 0, 0.09, 0.09, 0.09), MAT.trim);
  }
  if (oculus && main.rise > 1.4) {
    for (const side of [1, 3]) {
      L(G.cyl, facadeM(side).multiply(mat4(0, wallTop + main.rise * 0.72, 0.06, Math.PI / 2, 0, 0, 0.3, 0.12, 0.3)), MAT.trim);
      L(G.cyl, facadeM(side).multiply(mat4(0, wallTop + main.rise * 0.72, 0.1, Math.PI / 2, 0, 0, 0.2, 0.06, 0.2)), MAT.glass);
      L(G.cyl, facadeM(side).multiply(mat4(0, wallTop + main.rise * 0.72, 0.075, Math.PI / 2, 0, 0, 0.2, 0.01, 0.2)), MAT.interior);
    }
  }
  if (wisteria) {
    const sx = dr() < 0.5 ? -1 : 1, x0 = sx * (w / 2 - 0.25);
    const fu = spaced(Math.max(1, Math.floor((w - 0.8) / 2.3)), w - 1.2);
    const wisteriaBay = Math.max(...fu.map((u) => u * sx)) + winW / 2 + (shutters ? 0.56 : 0.2) + 0.15;
    box(x0, PLINTH + wallH / 2, d / 2 + 0.1, 0.07, wallH, 0.07, MAT.woodDark, 0.02);
    for (let i = 0; i < 10; i++) {
      const x = x0 - sx * i * 0.3, y = wallTop - 0.22 - (i % 2) * 0.08;
      L(G.ball, mat4(x, y, d / 2 + 0.16, 0, 0, dr(), 0.24, 0.15, 0.07), i % 2 ? MAT.leaf : MAT.leafDark);
      L(G.ball, mat4(x + 0.12, y - 0.12, d / 2 + 0.18, 0, 0, dr(), 0.16, 0.12, 0.06), MAT.leafDark);
      // hanging racemes only in the corner bay, never over a window
      if (i % 3 !== 1 && x * sx > wisteriaBay) L(G.cone, mat4(x + 0.05, y - 0.36, d / 2 + 0.26, Math.PI, 0, 0, 0.08, 0.44, 0.08), MAT.flowerLavender);
    }
    for (let i = 0; i < 10; i++) L(G.ball, mat4(x0 + (dr() - 0.5) * 0.35, PLINTH + 0.4 + i * (wallH / 10), d / 2 + 0.14, 0, 0, dr() * 3, 0.15, 0.12, 0.05), MAT.leafDark);
  }
  if (ivy) {
    const side = annexSide === 1 ? 3 : dr() < 0.5 ? 1 : 3;
    const cx0 = (dr() - 0.5) * (d - 2.5);
    const ivyWins = [];
    if (!(side === annexSide)) for (const u of spaced(Math.max(1, Math.floor((d - 0.8) / 2.3)), d - 1.2)) floorsY.forEach((wy, fi) => { if (!(bay && side === 1 && fi === 0)) ivyWins.push([u, wy]); });
    // a flat mat of small overlapping leaves rather than round blobs
    for (let i = 0; i < 70; i++) {
      const t = Math.pow(dr(), 0.8);
      const x = cx0 + (dr() - 0.5) * 2.4 * (1 - t * 0.5), y = PLINTH + 0.1 + t * wallH * 0.9;
      // ivy grows around windows, never across the glass, frame or shutters
      if (ivyWins.some(([u, wy]) => Math.abs(x - u) < winW / 2 + (shutters ? 0.6 : 0.28) && Math.abs(y - wy) < winH / 2 + 0.3)) continue;
      onFace(side, x, y, 0.05 + dr() * 0.03, 0.16 + dr() * 0.08, 0.13 + dr() * 0.07, 0.035, i % 3 ? MAT.leafDark : MAT.leaf, G.ball, dr() * 3);
    }
  }

  // ---- bay window on a cottage side ----
  if (bay) {
    const bm = facadeM(1);
    const BW = 2.3, BD = 0.8, BH = 1.9;
    const B = (x, y, z, sx, sy, sz, mat, g = rbox(1, 1, 1, 0.04), rx = 0) => L(g, bm.clone().multiply(mat4(x, y, z, rx, 0, 0, sx, sy, sz)), mat);
    B(0, PLINTH / 2 - 0.3, BD / 2, BW + 0.2, PLINTH + 0.6, BD + 0.1, MAT.stone);
    B(0, PLINTH + 0.35, BD / 2, BW, 0.7, BD, wallMat);
    B(0, PLINTH + 0.75, BD / 2 + 0.03, BW + 0.12, 0.08, BD + 0.12, MAT.stoneTrim);
    B(0, PLINTH + 0.8 + BH / 2, BD / 2, BW, BH, BD - 0.06, MAT.interior);
    B(0, PLINTH + 0.8 + BH / 2, BD + 0.005, BW - 0.2, BH - 0.2, 0.02, MAT.glass, G.box);
    for (let i = 0; i <= 3; i++) B(-BW / 2 + 0.06 + i * (BW - 0.12) / 3, PLINTH + 0.8 + BH / 2, BD, 0.1, BH, 0.1, MAT.trim);
    B(0, PLINTH + 0.8 + BH * 0.62, BD + 0.01, BW, 0.06, 0.06, MAT.trim);
    B(0, PLINTH + 0.86 + BH, BD / 2 + 0.05, BW + 0.3, 0.14, BD + 0.3, MAT.trim);
    B(0, PLINTH + 1.08 + BH, BD / 2 - 0.02, BW + 0.3, 0.14, BD + 0.45, roofMat, rbox(1, 1, 1, 0.05), 0.35);
  }

  // ---- lean-to shed / workshop on a side ----
  if (leanTo || h.domain === 'work') {
    const lm = facadeM(3);
    const LW = Math.min(d - 0.8, 5.2), LD = 2.6, LH = 2.5;
    const B = (x, y, z, sx, sy, sz, mat, rx = 0, g = rbox(1, 1, 1, 0.03)) => L(g, lm.clone().multiply(mat4(x, y, z, rx, 0, 0, sx, sy, sz)), mat);
    for (const sx of [-1, 1]) B(sx * (LW / 2 - 0.1), LH / 2 + 0.05, LD - 0.1, 0.16, LH, 0.16, MAT.woodDark);
    B(0, 0.04, LD / 2, LW + 0.2, 0.12, LD + 0.1, MAT.stoneTrim);
    const ang = Math.atan2(0.9, LD);
    B(0, LH + 0.5, LD / 2, LW + 0.5, 0.14, LD / Math.cos(ang) + 0.3, roofMat, ang);
    B(0, LH + 0.05, LD - 0.1, LW, 0.16, 0.16, MAT.woodDark);
    // back wall boarding and a workbench with tools
    for (let i = 0; i < Math.floor(LW / 0.3); i++) B(-LW / 2 + 0.15 + i * 0.3, LH / 2 + 0.2, 0.06, 0.28, LH, 0.05, i % 2 ? MAT.wood : MAT.timber);
    B(0, 0.85, 0.5, LW * 0.6, 0.08, 0.7, MAT.wood);
    for (const sx of [-1, 1]) B(sx * LW * 0.27, 0.42, 0.5, 0.08, 0.8, 0.6, MAT.woodDark);
    B(-0.4, 0.98, 0.45, 0.4, 0.18, 0.25, MAT.pot);
    B(0.5, 1.5, 0.12, 0.6, 0.04, 0.04, MAT.iron);
    const [lx, lz] = h.toWorld(-w / 2 - LD / 2, 0);
    colliders.push({ x: lx, z: lz, rot: h.rot, hx: LD / 2, hz: LW / 2, y0: groundY - 1, y1: groundY + LH + 0.6 });
    h.leanToSide = 3;
    if (h.domain === 'work') {
      // painted trade sign over the workshop
      B(0, LH + 1.15, LD + 0.05, 1.6, 0.42, 0.06, MAT.wood);
      B(0, LH + 1.15, LD + 0.09, 1.4, 0.28, 0.02, MAT.flowerBlue);
    }
  }

  // ---- landmark features ----
  if (h.domain === 'money') {
    // clock tower rising from the ridge
    const T = 1.9, tx = 0, base0 = main.ridgeY - 1.2, shaft = 3.2;
    box(tx, base0 + shaft / 2, 0, T, shaft, T, wallMat, 0.06);
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) for (let i = 0; i < 7; i++) box(sx * (T / 2 + 0.02), base0 + 0.3 + i * 0.45, sz * (T / 2 + 0.02), 0.26, 0.34, 0.26, MAT.stoneTrim, 0.03);
    box(tx, base0 + shaft + 0.05, 0, T + 0.3, 0.16, T + 0.3, MAT.stoneTrim, 0.03);
    // belfry with arched openings
    const bel = 1.5, by0 = base0 + shaft + 0.12;
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) box(sx * (T / 2 - 0.15), by0 + bel / 2, sz * (T / 2 - 0.15), 0.3, bel, 0.3, wallMat, 0.04);
    box(tx, by0 + bel / 2, 0, T - 0.5, bel, T - 0.5, MAT.interior, 0.02);
    L(G.cyl, mat4(0, by0 + bel * 0.55, 0, 0, 0, 0, 0.22, 0.35, 0.22), MAT.brass);
    box(tx, by0 + bel + 0.08, 0, T + 0.2, 0.16, T + 0.2, MAT.stoneTrim, 0.03);
    L(G.pyramid, mat4(0, by0 + bel + 0.16 + 1.2, 0, 0, 0, 0, T * 0.82, 2.4, T * 0.82), MAT.roof_slate);
    L(G.cyl6, mat4(0, by0 + bel + 3.0, 0, 0, 0, 0, 0.03, 0.9, 0.03), MAT.iron);
    L(G.ball, mat4(0, by0 + bel + 3.0, 0, 0, 0, 0, 0.09, 0.09, 0.09), MAT.brass);
    box(0.18, by0 + bel + 3.35, 0, 0.5, 0.16, 0.03, MAT.brass, 0.01);
    // clock faces
    for (let side = 0; side < 4; side++) {
      const a = side * Math.PI / 2;
      const fm = mat4(Math.sin(a) * (T / 2 + 0.01), base0 + shaft - 0.9, Math.cos(a) * (T / 2 + 0.01), 0, a, 0);
      L(G.cyl, fm.clone().multiply(mat4(0, 0, 0.04, Math.PI / 2, 0, 0, 0.62, 0.08, 0.62)), MAT.stoneTrim);
      L(G.cyl, fm.clone().multiply(mat4(0, 0, 0.09, Math.PI / 2, 0, 0, 0.52, 0.04, 0.52)), MAT.clockFace);
      for (let k = 0; k < 12; k++) { const b = (k / 12) * Math.PI * 2; L(G.box, fm.clone().multiply(mat4(Math.sin(b) * 0.44, Math.cos(b) * 0.44, 0.12, 0, 0, -b, 0.03, k % 3 ? 0.06 : 0.12, 0.02)), MAT.iron); }
      L(G.box, fm.clone().multiply(mat4(0.1, 0.12, 0.13, 0, 0, -0.8, 0.035, 0.32, 0.02)), MAT.iron);
      L(G.box, fm.clone().multiply(mat4(-0.12, 0.05, 0.14, 0, 0, 1.2, 0.03, 0.42, 0.02)), MAT.iron);
    }
    h.tallest = groundY + by0 + bel + 3.4;
  }
  if (h.domain === 'health') {
    // glass conservatory full of plants on the right side
    const cm = facadeM(1);
    const CW = Math.min(d - 0.6, 5.0), CD = 3.0, CH = 2.6;
    const C = (x, y, z, sx, sy, sz, mat, rx = 0, g = rbox(1, 1, 1, 0.02)) => L(g, cm.clone().multiply(mat4(x, y, z, rx, 0, 0, sx, sy, sz)), mat);
    C(0, 0.1, CD / 2, CW + 0.2, 0.7, CD + 0.1, MAT.stone);
    C(0, 0.47, CD / 2, CW + 0.28, 0.08, CD + 0.18, MAT.stoneTrim);
    C(0, 0.5 + CH / 2, CD / 2, CW - 0.04, CH - 0.06, CD - 0.04, MAT.glass, 0, G.box);
    for (let i = 0; i <= 5; i++) C(-CW / 2 + i * CW / 5, 0.5 + CH / 2, CD, 0.07, CH, 0.07, MAT.trim);
    for (let i = 0; i <= 3; i++) C(-CW / 2, 0.5 + CH / 2, i * CD / 3, 0.07, CH, 0.07, MAT.trim), C(CW / 2, 0.5 + CH / 2, i * CD / 3, 0.07, CH, 0.07, MAT.trim);
    C(0, 0.5 + CH, CD / 2, CW + 0.1, 0.08, CD + 0.1, MAT.trim);
    const ang = Math.atan2(0.9, CD);
    C(0, 0.5 + CH + 0.48, CD / 2, CW + 0.2, 0.03, CD / Math.cos(ang), MAT.glass, ang, G.box);
    for (let i = 0; i <= 5; i++) C(-CW / 2 + i * CW / 5, 0.5 + CH + 0.5, CD / 2, 0.06, 0.06, CD / Math.cos(ang) + 0.05, MAT.trim, ang);
    // plants inside
    for (let i = 0; i < 9; i++) C(-CW / 2 + 0.5 + (i % 5) * (CW - 1) / 4, 0.9 + (i % 2) * 0.25, 0.5 + Math.floor(i / 5) * 1.6, 0.4 + (i % 3) * 0.12, 0.4, 0.4, i % 3 ? MAT.leaf : MAT.leafDark, 0, G.ball);
    for (let i = 0; i < 4; i++) C(-CW / 2 + 0.7 + i * (CW - 1.4) / 3, 1.25, 1.2, 0.12, 0.12, 0.12, [MAT.flowerPink, MAT.flowerWhite, MAT.flowerLavender][i % 3], 0, G.ball);
    const [cx, cz] = h.toWorld(w / 2 + CD / 2, 0);
    colliders.push({ x: cx, z: cz, rot: h.rot, hx: CD / 2, hz: CW / 2, y0: groundY - 1, y1: groundY + 4 });
  }
  if (h.domain === 'home') {
    // covered porch along the front
    const pz = h.d / 2 + h.wingD;
    const PW = 3.4;
    for (const s of [-1, 1]) {
      box(doorX + s * (PW / 2 - 0.1), PLINTH + 1.25, pz + 1.55, 0.16, 2.5, 0.16, MAT.trim, 0.03);
      { const [px, pz2] = h.toWorld(doorX + s * (PW / 2 - 0.1), pz + 1.55); colliders.push({ x: px, z: pz2, rot: h.rot, hx: 0.12, hz: 0.12, y0: groundY - 1, y1: groundY + 3 }); }
      L(G.box, mat4(doorX + s * (PW / 2 - 0.35), PLINTH + 2.3, pz + 1.55, 0, 0, s * 0.7, 0.08, 0.6, 0.08), MAT.trim);
    }
    box(doorX, PLINTH + 2.55, pz + 1.55, PW + 0.1, 0.16, 0.18, MAT.trim, 0.03);
    L(rbox(PW + 0.6, 0.14, 2.1, 0.04), mat4(doorX, PLINTH + 2.82, pz + 0.95, 0.32, 0, 0), roofMat);
    box(doorX, PLINTH - 0.02, pz + 1.0, PW, 0.12, 1.9, MAT.wood, 0.03);
    // a stone step down from the deck
    box(doorX, PLINTH - 0.32, pz + 2.15, 1.6, 0.3, 0.5, MAT.stoneTrim, 0.04);
    pads.push({ x0: doorX - PW / 2, x1: doorX + PW / 2, z0: pz + 0.05, z1: pz + 1.95, y: PLINTH + 0.04 });
    pads.push({ x0: doorX - 0.8, x1: doorX + 0.8, z0: pz + 1.9, z1: pz + 2.4, y: PLINTH - 0.17 });
  }
  if (h.domain === 'ideas') {
    // contemporary flat-roofed studio annex with a full-height window
    const am = facadeM(0);
    const A = (x, y, z, sx, sy, sz, mat, g = rbox(1, 1, 1, 0.03)) => L(g, am.clone().multiply(mat4(x, y, z, 0, 0, 0, sx, sy, sz)), mat);
    A(w / 2 - 1.2, PLINTH + 1.4, 0.9, 2.4, 2.8, 1.8, MAT.wall_white);
    A(w / 2 - 1.2, PLINTH + 2.86, 0.9, 2.7, 0.14, 2.1, MAT.frameDark);
    A(w / 2 - 1.2, PLINTH + 1.35, 1.81, 1.9, 2.3, 0.04, MAT.glass, G.box);
    A(w / 2 - 1.2, PLINTH + 1.35, 1.79, 1.9, 2.3, 0.02, MAT.interior, G.box);
    for (const x of [-0.95, 0, 0.95]) A(w / 2 - 1.2 + x, PLINTH + 1.35, 1.84, 0.06, 2.3, 0.06, MAT.frameDark);
  }

  const c = Math.cos(h.rot), sn = Math.sin(h.rot);
  const bx0 = Math.min(...pads.map((p) => p.x0)), bx1 = Math.max(...pads.map((p) => p.x1));
  const bz0 = Math.min(...pads.map((p) => p.z0)), bz1 = Math.max(...pads.map((p) => p.z1));
  const surface = {
    test(x, z) {
      const dx = x - h.x, dz = z - h.z, lx = dx * c - dz * sn, lz = dx * sn + dz * c;
      if (lx < bx0 || lx > bx1 || lz < bz0 || lz > bz1) return null;
      let y = null;
      for (const p of pads) if (lx >= p.x0 && lx <= p.x1 && lz >= p.z0 && lz <= p.z1) y = Math.max(y ?? -1e9, groundY + p.y);
      return y;
    },
  };
  return { colliders, surfaces: [surface], door, doorPivot, ridgeY: groundY + main.ridgeY };
}
