// Garden plants built from leaves and flowers rather than spheres: leaf cards fanned around a mound,
// mophead flower heads made of small four petal florets, cupped roses, layered peonies, lavender and
// salvia spikes on slender stems. Every plant is one vertex coloured geometry (see kit.js) and reads
// as a soft storybook illustration, not a cluster of balls.
import * as THREE from 'three';
import { kit, M, G } from './kit.js';
import { PAL } from './assets.js';

const prims = new Map();
const prim = (key, make) => { if (!prims.has(key)) prims.set(key, make()); return prims.get(key); };
const tris = (pos) => { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.computeVertexNormals(); return g; };
// both faces of a triangle list (the kit material is single sided)
const twoSided = (p) => { const out = [...p]; for (let i = 0; i < p.length; i += 9) out.push(p[i], p[i + 1], p[i + 2], p[i + 6], p[i + 7], p[i + 8], p[i + 3], p[i + 4], p[i + 5]); return out; };

// leaf: base at origin, tip at +z (length 1), width 1 at 45%, folded along the midrib
const LEAF = () => prim('leaf', () => tris(twoSided([0, 0, 0, -0.5, 0.06, 0.42, 0, 0.02, 1, 0, 0, 0, 0, 0.02, 1, 0.5, 0.06, 0.42])));
// floret: four rounded petals facing +y, radius 1
const FLORET = () => prim('floret', () => {
  const p = [];
  for (let i = 0; i < 4; i++) { const a = (i / 4) * Math.PI * 2, b = a + 0.62, c = a - 0.62; p.push(0, 0.05, 0, Math.cos(c), 0, Math.sin(c), Math.cos(b), 0, Math.sin(b)); }
  return tris(twoSided(p));
});
// daisy-like flat star with n petals, radius 1, facing +y
const STAR = (n = 8) => prim('star' + n, () => {
  const p = [];
  for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2, w = Math.PI / n * 0.8; p.push(0, 0.02, 0, Math.cos(a + w) * 0.35, 0.01, Math.sin(a + w) * 0.35, Math.cos(a) * 1, 0, Math.sin(a) * 1, 0, 0.02, 0, Math.cos(a) * 1, 0, Math.sin(a) * 1, Math.cos(a - w) * 0.35, 0.01, Math.sin(a - w) * 0.35); }
  return tris(twoSided(p));
});
// rose / peony cup (lathe), radius ~1, height ~0.9
const CUP = (open = 0) => prim('cup' + open, () => new THREE.LatheGeometry(
  open ? [[0, 0], [0.55, 0.12], [1, 0.38], [0.92, 0.55], [0.6, 0.48], [0.5, 0.62], [0.2, 0.55], [0, 0.6]].map(([x, y]) => new THREE.Vector2(x, y))
    : [[0, 0], [0.5, 0.1], [0.8, 0.45], [0.7, 0.8], [0.4, 0.7], [0.15, 0.82], [0, 0.75]].map(([x, y]) => new THREE.Vector2(x, y)), 7));
// slender flower spike (lathe capsule), height 1, radius ~1 at the widest
const SPIKE = () => prim('spike', () => new THREE.LatheGeometry([[0, 0], [0.7, 0.08], [1, 0.3], [0.85, 0.65], [0.45, 0.92], [0, 1]].map(([x, y]) => new THREE.Vector2(x, y)), 5));

const _n = new THREE.Vector3(), _up = new THREE.Vector3(0, 1, 0), _v = new THREE.Vector3(), _sc = new THREE.Vector3(), _q = new THREE.Quaternion(), _q2 = new THREE.Quaternion();
const lerpCol = (a, b, t) => '#' + new THREE.Color(a).lerp(new THREE.Color(b), t).getHexString();

// A mound of leaf cards: dense, irregular, with a darker inner core so it never looks hollow.
export function foliage(k, r, { radius = 0.45, height = 0.5, leaves = 40, size = 0.22, cols = [PAL.sageDark, PAL.sage, PAL.sageDeep, PAL.leafC], core = PAL.sageDeep, cy = 0, ox = 0, oz = 0 }) {
  k.add(G.ball(1), core, M(ox, cy + height * 0.42, oz, 0, r() * 6, 0, radius * 0.72, height * 0.5, radius * 0.72));
  for (let i = 0; i < leaves; i++) {
    const a = r() * Math.PI * 2, el = 0.15 + Math.pow(r(), 0.8) * 1.25;
    const rr = radius * (0.35 + 0.55 * Math.cos(el)) * (0.8 + r() * 0.35);
    const y = cy + height * (0.12 + 0.75 * Math.sin(el)) * (0.85 + r() * 0.2);
    const len = size * (0.75 + r() * 0.5);
    const pitch = 0.15 + el * 0.55 + (r() - 0.5) * 0.3; // outer leaves lie flatter, top leaves stand up
    k.add(LEAF(), cols[Math.floor(r() * cols.length)], M(ox + Math.cos(a) * rr, y, oz + Math.sin(a) * rr, -pitch, Math.PI / 2 - a, (r() - 0.5) * 0.5, len * 0.55, len, len));
  }
}

// Mophead: a domed head covered in florets over a solid underside in a deeper tone.
export function mophead(k, r, x, y, z, R, c1, c2) {
  k.add(G.hemi(8), c2, M(x, y - R * 0.15, z, 0, 0, 0, R * 0.92, R * 0.75, R * 0.92));
  const n = 22;
  for (let i = 0; i < n; i++) {
    const a = r() * Math.PI * 2, el = Math.acos(1 - r() * 0.95);
    const nx = Math.sin(el) * Math.cos(a), ny = Math.cos(el), nz = Math.sin(el) * Math.sin(a);
    const s = R * (0.26 + r() * 0.1);
    _n.set(nx, ny, nz); _q.setFromUnitVectors(_up, _n).multiply(_q2.setFromAxisAngle(_up, r() * 6.28));
    k.add(FLORET(), r() < 0.55 ? c1 : lerpCol(c1, c2, 0.5), new THREE.Matrix4().compose(_v.set(x + nx * R * 0.9, y - R * 0.15 + ny * R * 0.72, z + nz * R * 0.9), _q, _sc.set(s, s, s)));
  }
}

export const hydrangea = (v = 0) => kit('hydrangea2', (k, r) => {
  const c1 = [PAL.powder, PAL.lilac, PAL.rose][v % 3], c2 = [PAL.powderDeep, PAL.lavender, PAL.pinkDeep][v % 3];
  foliage(k, r, { radius: 0.5, height: 0.55, leaves: 46, size: 0.26 });
  const heads = 5 + Math.floor(r() * 3);
  for (let i = 0; i < heads; i++) {
    const a = (i / heads) * Math.PI * 2 + r() * 0.6, rr = i === 0 ? 0 : 0.18 + r() * 0.2;
    mophead(k, r, Math.cos(a) * rr, 0.5 + r() * 0.12 - rr * 0.25, Math.sin(a) * rr, 0.12 + r() * 0.04, c1, c2);
  }
}, v);

export const roseBush = (v = 0) => kit('rose2', (k, r) => {
  const c = [PAL.pinkDeep, PAL.peach, PAL.white][v % 3], c2 = [PAL.rose, PAL.peachDeep, PAL.cream][v % 3];
  for (let i = 0; i < 5; i++) { const a = r() * 6.28; k.add(G.cyl(4, 0.6), PAL.woodDark, M(Math.cos(a) * 0.08, 0.25, Math.sin(a) * 0.08, Math.sin(a) * 0.35, 0, -Math.cos(a) * 0.35, 0.015, 0.5, 0.015)); }
  foliage(k, r, { radius: 0.42, height: 0.62, leaves: 44, size: 0.16, cols: [PAL.sageDeep, PAL.sageDark, PAL.moss] });
  const n = 7 + Math.floor(r() * 4);
  for (let i = 0; i < n; i++) {
    const a = r() * 6.28, el = 0.3 + r() * 1.1;
    const x = Math.cos(a) * 0.4 * Math.cos(el), y = 0.18 + Math.sin(el) * 0.5, z = Math.sin(a) * 0.4 * Math.cos(el);
    const s = 0.055 + r() * 0.025;
    k.add(CUP(0), i % 3 ? c : c2, M(x, y, z, -Math.cos(a) * 0.4 * (1 - el / 1.6), 0, Math.sin(a) * 0.4 * (1 - el / 1.6), s, s * 0.9, s));
  }
}, v);

export const peony = (v = 0) => kit('peony2', (k, r) => {
  const c = [PAL.pink, PAL.rose, PAL.white][v % 3], c2 = [PAL.pinkDeep, PAL.pink, PAL.cream][v % 3];
  foliage(k, r, { radius: 0.4, height: 0.42, leaves: 34, size: 0.22, cols: [PAL.sageDark, PAL.sage, PAL.leafC] });
  const n = 3 + Math.floor(r() * 2);
  for (let i = 0; i < n; i++) {
    const a = (i / n) * 6.28 + r(), rr = 0.12 + r() * 0.14, y = 0.42 + r() * 0.1, s = 0.1 + r() * 0.03;
    k.add(G.cyl(3, 1), PAL.sageDark, M(Math.cos(a) * rr * 0.6, y / 2, Math.sin(a) * rr * 0.6, 0, 0, 0, 0.012, y, 0.012));
    k.add(CUP(1), c2, M(Math.cos(a) * rr, y, Math.sin(a) * rr, 0, r() * 6, 0, s * 1.05, s * 0.6, s * 1.05));
    k.add(CUP(1), c, M(Math.cos(a) * rr, y + s * 0.15, Math.sin(a) * rr, 0, r() * 6, 0, s * 0.8, s * 0.7, s * 0.8));
  }
}, v);

// slender stems with flower spikes over a grassy or leafy base
function spikes(k, r, { n, h, col, col2, base, spike = 0.16, width = 0.03, lean = 0.35, baseLeaves = 14, baseSize = 0.18, spread = 0.18 }) {
  for (let i = 0; i < baseLeaves; i++) { const a = r() * 6.28; k.add(LEAF(), r() < 0.5 ? base : lerpCol(base, PAL.sageDeep, 0.4), M(Math.cos(a) * 0.04, 0.02, Math.sin(a) * 0.04, -(0.5 + r() * 0.6), Math.PI / 2 - a, 0, baseSize * 0.35, baseSize, baseSize)); }
  for (let i = 0; i < n; i++) {
    const a = r() * 6.28, rr = Math.sqrt(r()) * spread, hh = h * (0.75 + r() * 0.4), tl = lean * (rr / spread) * (0.6 + r() * 0.6);
    const tx = Math.cos(a) * Math.sin(tl), tz = Math.sin(a) * Math.sin(tl);
    k.add(G.cyl(3, 1), lerpCol(base, PAL.sageDeep, 0.3), M(Math.cos(a) * rr + tx * hh / 2, hh / 2, Math.sin(a) * rr + tz * hh / 2, Math.sin(a) * tl, 0, -Math.cos(a) * tl, 0.008, hh, 0.008));
    const sx = Math.cos(a) * rr + tx * hh, sz = Math.sin(a) * rr + tz * hh;
    k.add(SPIKE(), r() < 0.6 ? col : col2, M(sx, hh - spike * 0.15, sz, Math.sin(a) * tl, 0, -Math.cos(a) * tl, width, spike * (0.8 + r() * 0.4), width));
  }
}

export const lavenderBush = (v = 0) => kit('lavender2', (k, r) => {
  spikes(k, r, { n: 26, h: 0.5, col: v ? PAL.lilac : PAL.lavenderDeep, col2: v ? PAL.lavender : PAL.lavender, base: '#a9bfa4', spike: 0.15, width: 0.026, lean: 0.55, baseLeaves: 22, baseSize: 0.2, spread: 0.24 });
}, v);

export const salvia = (v = 0) => kit('salvia2', (k, r) => {
  const c = [PAL.lavenderDeep, PAL.powderDeep, PAL.pinkDeep][v % 3], c2 = [PAL.lavender, PAL.powder, PAL.pink][v % 3];
  foliage(k, r, { radius: 0.22, height: 0.18, leaves: 16, size: 0.15, cols: [PAL.sage, PAL.sageDark] });
  spikes(k, r, { n: 11, h: 0.55, col: c, col2: c2, base: PAL.sage, spike: 0.24, width: 0.03, lean: 0.25, baseLeaves: 0, spread: 0.16 });
}, v);

export const floweringShrub = (v = 0) => kit('fshrub2', (k, r) => {
  const c = [PAL.butter, PAL.white, PAL.lilac][v % 3], c2 = [PAL.butterDeep, PAL.cream, PAL.lavender][v % 3];
  foliage(k, r, { radius: 0.62, height: 0.95, leaves: 60, size: 0.26, cols: [PAL.sageDark, PAL.sage, PAL.leafC, PAL.sageDeep] });
  for (let i = 0; i < 9; i++) {
    const a = r() * 6.28, el = 0.35 + r() * 1.0;
    mophead(k, r, Math.cos(a) * 0.5 * Math.cos(el), 0.25 + Math.sin(el) * 0.75, Math.sin(a) * 0.5 * Math.cos(el), 0.07 + r() * 0.03, c, c2);
  }
}, v);

// Small cottage flowers for gaps and bed edges: daisies, cosmos and alliums.
export const cottageFlowers = (kind = 'daisy', v = 0) => kit('cottage-' + kind, (k, r) => {
  const n = kind === 'allium' ? 5 : 9;
  for (let i = 0; i < 10; i++) { const a = r() * 6.28; k.add(LEAF(), r() < 0.5 ? PAL.sageDark : PAL.sage, M(Math.cos(a) * 0.03, 0.02, Math.sin(a) * 0.03, -(0.35 + r() * 0.5), Math.PI / 2 - a, 0, 0.05, 0.16, 0.16)); }
  for (let i = 0; i < n; i++) {
    const a = r() * 6.28, rr = Math.sqrt(r()) * 0.18, h = (kind === 'allium' ? 0.55 : kind === 'cosmos' ? 0.5 : 0.3) * (0.75 + r() * 0.45);
    const x = Math.cos(a) * rr, z = Math.sin(a) * rr;
    k.add(G.cyl(3, 1), PAL.sageDark, M(x, h / 2, z, 0, 0, 0, 0.007, h, 0.007));
    if (kind === 'allium') { mophead(k, r, x, h, z, 0.06, v ? PAL.lilac : PAL.lavender, PAL.lavenderDeep); continue; }
    const pc = kind === 'cosmos' ? [PAL.pink, PAL.rose, PAL.white][Math.floor(r() * 3)] : (v ? PAL.lilac : PAL.white);
    const s = kind === 'cosmos' ? 0.055 : 0.042;
    k.add(STAR(8), pc, M(x, h, z, (r() - 0.5) * 0.5, r() * 6, (r() - 0.5) * 0.5, s, s, s));
    k.add(G.ball(0), kind === 'cosmos' ? PAL.butterDeep : PAL.butterDeep, M(x, h + 0.008, z, 0, 0, 0, s * 0.3, s * 0.2, s * 0.3));
  }
}, v);

// A small flowering clump at (x, z) inside another kit (window boxes, pots, raised beds).
export function miniPlant(k, r, x, z, y0, colour, colour2, kind = 'mop') {
  foliage(k, r, { radius: 0.16, height: 0.16, leaves: 12, size: 0.1, cy: y0, ox: x, oz: z });
  if (kind === 'mop') mophead(k, r, x, y0 + 0.2, z, 0.075, colour, colour2);
  else for (let i = 0; i < 4; i++) { const a = r() * 6.28, rr = r() * 0.08, s = 0.045; k.add(STAR(8), i % 2 ? colour : colour2, M(x + Math.cos(a) * rr, y0 + 0.18 + r() * 0.05, z + Math.sin(a) * rr, (r() - 0.5) * 0.5, r() * 6, (r() - 0.5) * 0.5, s, s, s)); k.add(G.ball(0), PAL.butterDeep, M(x + Math.cos(a) * rr, y0 + 0.19, z + Math.sin(a) * rr, 0, 0, 0, 0.012, 0.01, 0.012)); }
}
