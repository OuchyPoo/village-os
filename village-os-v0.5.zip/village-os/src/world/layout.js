// Hand-authored village plan: lanes, the square, key (domain) buildings and the forest clearings.
// Filler houses are placed procedurally along lanes in buildLayout().
import { mulberry32, noise, smoothstep } from '../core/math.js';
import { riverQuery, halfWidth } from './river.js';

export const SQUARE = { x: -44, z: -6, r: 11.5 };

// type: 'slab' (paved with kerbs), 'cobble' (village lane), 'trail' (forest footpath)
export const LANES = [
  { id: 'main', type: 'slab', w: 3.4, pts: [[-72, -32], [-60, -18], [-44, -6], [-30, -5], [-22, -5], [2, -5], [12, -2], [22, 7], [30, 20], [32, 34], [27, 48]] },
  { id: 'south', type: 'slab', w: 3.2, pts: [[-44, -6], [-50, 10], [-46, 27], [-34, 40], [-20, 47], [-9, 48], [14, 48], [27, 48]] },
  { id: 'promenade', type: 'cobble', w: 2.8, pts: [[-44, -6], [-38, -21], [-31, -36], [-22, -52], [-12, -70], [-4, -86], [0, -98], [24, -98], [40, -110], [54, -128], [62, -146]] },
  { id: 'eastHill', type: 'trail', w: 2.0, pts: [[32, 34], [46, 40], [64, 32], [82, 38], [98, 31], [108, 34]] },
  { id: 'westWood', type: 'trail', w: 2.0, pts: [[-72, -32], [-88, -44], [-104, -40], [-120, -54], [-128, -70]] },
  { id: 'southWest', type: 'trail', w: 2.0, pts: [[-46, 27], [-64, 40], [-82, 60], [-94, 82], [-98, 98]] },
  { id: 'southRiver', type: 'trail', w: 2.1, pts: [[27, 48], [36, 66], [42, 86], [36, 106], [30, 120], [6, 121], [-10, 128], [-28, 140], [-42, 152]] },
  { id: 'northWest', type: 'trail', w: 2.0, pts: [[-31, -36], [-48, -52], [-60, -74], [-58, -96], [-66, -112]] },
];

// Key buildings that host life domains. (x, z) centre; the door faces the nearest lane.
export const KEY_BUILDINGS = [
  { domain: 'home', x: 44, z: 12, style: 'cottage', w: 8.2, d: 6.6, floors: 1, cross: true, dormers: 2, roof: 'orange', wall: 'cream', garden: true },
  { domain: 'work', x: -60, z: -3, style: 'townhouse', w: 8, d: 7, floors: 2, cross: false, dormers: 2, roof: 'terracotta', wall: 'yellow', shutters: 'green' },
  { domain: 'stay', x: -21, z: -30, style: 'chalet', w: 9, d: 7.5, floors: 2, cross: false, dormers: 0, roof: 'orange', wall: 'white', balcony: true, garden: true },
  { domain: 'money', x: -30, z: 12, style: 'townhouse', w: 10, d: 8, floors: 2, cross: true, dormers: 3, roof: 'orange', wall: 'white', shutters: 'blue' },
  { domain: 'taxes', x: -60, z: 16, style: 'cottage', w: 7.4, d: 6.4, floors: 2, cross: false, dormers: 1, roof: 'terracotta', wall: 'pink', shutters: 'green' },
  { domain: 'health', x: 15, z: 30, style: 'cottage', w: 7.6, d: 6.4, floors: 1, cross: true, dormers: 1, roof: 'orange', wall: 'cream', garden: true },
  { domain: 'ideas', x: 112, z: 22, style: 'modern', w: 8.4, d: 6.8, floors: 1, cross: false, dormers: 0, roof: 'slate', wall: 'white', garden: true },
];

// Cottages at the ends of forest trails, set in clearings.
export const CLEARING_COTTAGES = [
  { x: -132, z: -82 }, { x: -104, z: 104 }, { x: -50, z: 160 }, { x: 72, z: -150 }, { x: -72, z: -120 },
];

const WALLS = ['cream', 'peach', 'butter', 'powder', 'mint', 'lavender', 'pink', 'white'];
const ROOFS = ['orange', 'terracotta', 'rose', 'orange', 'slate', 'terracotta'];
const STYLES = ['cottage', 'cottage', 'townhouse', 'chalet', 'cottage', 'modern'];

export function randomHouse(rand, overrides = {}) {
  const style = STYLES[Math.floor(rand() * STYLES.length)];
  const floors = style === 'townhouse' ? 2 : rand() < 0.35 ? 2 : 1;
  return {
    style,
    w: 6.4 + rand() * 2.6,
    d: 5.6 + rand() * 1.8,
    floors,
    cross: style !== 'modern' && rand() < 0.45,
    dormers: style === 'modern' ? 0 : Math.floor(rand() * 3),
    roof: style === 'modern' ? (rand() < 0.6 ? 'slate' : 'orange') : ROOFS[Math.floor(rand() * 5)],
    wall: style === 'modern' ? 'white' : WALLS[Math.floor(rand() * WALLS.length)],
    shutters: style === 'townhouse' || rand() < 0.3 ? (['green', 'blue', 'lavender', 'pink'][Math.floor(rand() * 4)]) : null,
    balcony: style === 'chalet',
    garden: rand() < 0.55,
    seed: Math.floor(rand() * 1e9),
    ...overrides,
  };
}

function sampleLane(pts, step = 1) {
  const out = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const [x0, z0] = pts[i], [x1, z1] = pts[i + 1];
    const n = Math.max(1, Math.ceil(Math.hypot(x1 - x0, z1 - z0) / step));
    for (let k = 0; k < n; k++) out.push([x0 + (x1 - x0) * (k / n), z0 + (z1 - z0) * (k / n)]);
  }
  out.push(pts[pts.length - 1]);
  return out;
}

function distToLanes(x, z, lanes) {
  let best = Infinity, bx = 0, bz = 0, lane = null;
  for (const l of lanes) for (const [px, pz] of l.dense) {
    const d = (px - x) ** 2 + (pz - z) ** 2;
    if (d < best) { best = d; bx = px; bz = pz; lane = l; }
  }
  return { d: Math.sqrt(best), x: bx, z: bz, lane };
}

// Produces the full building list: key buildings, procedural fillers along lanes, clearing cottages.
export function buildLayout(laneCurves) {
  const rand = mulberry32(2024);
  const lanes = laneCurves.map((l) => ({ ...l, dense: sampleLane(l.curvePts, 1.5) }));
  const houses = [];
  const q = {};

  const face = (h) => {
    const n = distToLanes(h.x, h.z, lanes);
    h.rot = Math.atan2(n.x - h.x, n.z - h.z); // local +z (front) points at the lane
    h.laneDist = n.d;
    h.lanePoint = [n.x, n.z];
  };

  const fits = (x, z, r, ignoreLaneDist = false) => {
    riverQuery(x, z, q);
    if (q.d < halfWidth(z) + r + 4) return false;
    if (Math.hypot(x - SQUARE.x, z - SQUARE.z) < SQUARE.r + r + 1) return false;
    for (const h of houses) if (Math.hypot(h.x - x, h.z - z) < h.r + r + 2.5) return false;
    if (!ignoreLaneDist && distToLanes(x, z, lanes).d < r + 2.2) return false;
    if (Math.hypot(x, z) > 165) return false;
    return true;
  };

  for (const k of KEY_BUILDINGS) {
    const h = { ...randomHouse(rand), ...k, key: true };
    h.r = Math.hypot(h.w, h.d) / 2 + (h.cross ? 1 : 0);
    face(h);
    houses.push(h);
  }
  for (const c of CLEARING_COTTAGES) {
    const h = { ...randomHouse(rand, { style: rand() < 0.5 ? 'chalet' : 'cottage', garden: true }), x: c.x, z: c.z, clearing: true };
    h.r = Math.hypot(h.w, h.d) / 2 + (h.cross ? 1 : 0);
    face(h);
    houses.push(h);
  }

  // Filler houses along paved lanes and the promenade, alternating sides, with jitter.
  for (const l of lanes) {
    if (l.type === 'trail') continue;
    const pts = l.dense;
    let side = rand() < 0.5 ? 1 : -1;
    for (let i = 4; i < pts.length - 2; i += 5 + Math.floor(rand() * 3)) {
      const [x0, z0] = pts[i - 1], [x1, z1] = pts[i + 1];
      const tx = x1 - x0, tz = z1 - z0, tl = Math.hypot(tx, tz) || 1;
      const nx = -tz / tl, nz = tx / tl;
      for (const s of [side, -side]) {
        const spec = randomHouse(rand);
        const r = Math.hypot(spec.w, spec.d) / 2 + (spec.cross ? 1 : 0);
        const off = l.w / 2 + spec.d / 2 + 2.8 + rand() * 1.6;
        const x = pts[i][0] + nx * off * s, z = pts[i][1] + nz * off * s;
        if (fits(x, z, r - 1.2, true) && distToLanes(x, z, lanes).d > spec.d / 2 + l.w / 2 + 1.6) {
          const h = { ...spec, x, z, r };
          face(h);
          houses.push(h);
          side = -s;
          if (rand() < 0.5) break;
        }
      }
    }
  }
  return houses;
}

// Forest patch mask (0 meadow .. 1 forest), shared by tree scattering and the ground colour.
export function forestPatch(x, z) {
  const R = Math.hypot(x, z);
  return smoothstep(-0.25, 0.25, noise(x * 0.018, z * 0.018) + 0.35 * noise(x * 0.06, z * 0.06) + 0.5 * smoothstep(90, 190, R) - 0.1);
}
