// Gradient sky dome and soft cumulus clouds made of clustered spheres.
import * as THREE from 'three';
import { mulberry32 } from '../core/math.js';

export function buildSky() {
  const geo = new THREE.SphereGeometry(4000, 32, 16);
  const mat = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: {
      top: { value: new THREE.Color('#9ec3e6').convertSRGBToLinear() },
      mid: { value: new THREE.Color('#d2e3f2').convertSRGBToLinear() },
      horizon: { value: new THREE.Color('#f6e4dc').convertSRGBToLinear() },
    },
    vertexShader: 'varying vec3 vP; void main(){ vP = normalize(position); vec4 p = projectionMatrix*modelViewMatrix*vec4(position,1.0); gl_Position = p.xyww; }',
    fragmentShader: `uniform vec3 top, mid, horizon; varying vec3 vP;
      void main(){ float h = vP.y; vec3 c = mix(horizon, mid, smoothstep(-0.02, 0.18, h)); c = mix(c, top, smoothstep(0.18, 0.7, h));
      gl_FragColor = vec4(c,1.0);
      #include <colorspace_fragment>
      }`,
  });
  const m = new THREE.Mesh(geo, mat);
  m.renderOrder = -10;
  m.frustumCulled = false;
  m.name = 'sky';
  return m;
}

export function buildClouds() {
  const group = new THREE.Group();
  group.name = 'clouds';
  const geo = new THREE.IcosahedronGeometry(1, 3);
  const mat = new THREE.MeshStandardMaterial({ color: '#ffffff', emissive: '#eef4fa', emissiveIntensity: 0.7, roughness: 1, fog: false });
  const rand = mulberry32(42);
  const puffs = [];
  for (let c = 0; c < 30; c++) {
    const a = rand() * Math.PI * 2, r = 320 + rand() * 800;
    const cx = Math.cos(a) * r, cz = Math.sin(a) * r, cy = 190 + rand() * 140;
    const n = 9 + Math.floor(rand() * 8);
    const len = 50 + rand() * 60;
    for (let i = 0; i < n; i++) {
      const t = (i / (n - 1)) * 2 - 1;
      const s = (11 + rand() * 8) * (1.3 - Math.abs(t) * 0.65);
      puffs.push({ x: cx + t * len * 0.5 + (rand() - 0.5) * 12, y: cy + (1 - Math.abs(t)) * 10 + rand() * 6, z: cz + (rand() - 0.5) * 22, s, sy: s * (0.62 + rand() * 0.18), rx: rand() * 3, rot: rand() * Math.PI, rz: rand() * 3 });
    }
  }
  const inst = new THREE.InstancedMesh(geo, mat, puffs.length);
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
  puffs.forEach((p, i) => {
    q.setFromEuler(e.set(0, p.rot, 0));
    m.compose(new THREE.Vector3(p.x, p.y, p.z), q, new THREE.Vector3(p.s, p.sy, p.s));
    inst.setMatrixAt(i, m);
  });
  inst.frustumCulled = false;
  group.add(inst);
  group.userData.update = (dt) => { group.rotation.y += dt * 0.004; };
  return group;
}
