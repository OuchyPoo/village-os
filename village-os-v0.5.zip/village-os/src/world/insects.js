// Butterflies and dragonflies, instanced and animated on the GPU.
// Butterflies: rounded fore and hind wings (fans, darker at the root, paler at the edge, a soft
// eyespot tone), a slim body and antennae; they flap and drift on looping paths over gardens and
// meadows. Dragonflies: long slender bodies with four narrow, glassy wings that shimmer; they hover
// low over the river margins and dart between resting points.
import * as THREE from 'three';

// wing fan: root at origin, outline points (x outward, z forward) -> triangles with a shade attribute
function fan(outline, sideSign, flapAttr, out) {
  for (let i = 0; i < outline.length - 1; i++) {
    const [x0, z0] = outline[i], [x1, z1] = outline[i + 1];
    out.pos.push(0, 0, 0, x0 * sideSign, 0, z0, x1 * sideSign, 0, z1);
    out.side.push(0, flapAttr, flapAttr);
    out.shade.push(0, 1, 1);
  }
}
const ellipse = (cx, cz, rx, rz, a0, a1, n, tilt = 0) => {
  const pts = [];
  for (let i = 0; i <= n; i++) {
    const a = a0 + (a1 - a0) * (i / n);
    const x = Math.cos(a) * rx, z = Math.sin(a) * rz;
    pts.push([cx + x * Math.cos(tilt) - z * Math.sin(tilt), cz + x * Math.sin(tilt) + z * Math.cos(tilt)]);
  }
  return pts;
};
// body: a slim cross of two thin quads along z
function body(len, wid, z0, out) {
  const q = (a, b, c, d) => { out.pos.push(...a, ...b, ...c, ...a, ...c, ...d); out.side.push(0, 0, 0, 0, 0, 0); out.shade.push(-1, -1, -1, -1, -1, -1); };
  q([-wid, 0, z0], [wid, 0, z0], [wid * 0.4, 0, z0 + len], [-wid * 0.4, 0, z0 + len]);
  q([0, -wid, z0], [0, wid, z0], [0, wid * 0.4, z0 + len], [0, -wid * 0.4, z0 + len]);
}

function butterflyGeometry() {
  const out = { pos: [], side: [], shade: [] };
  for (const s of [-1, 1]) {
    fan([[0.02, 0.03], ...ellipse(0.1, 0.07, 0.11, 0.075, -0.9, 2.2, 7, 0.35)], s, s, out); // forewing
    fan([[0.02, -0.01], ...ellipse(0.075, -0.06, 0.08, 0.07, -2.4, 0.6, 6, -0.3)], s, s, out); // hindwing
  }
  body(0.16, 0.012, -0.07, out);
  // antennae
  for (const s of [-1, 1]) { out.pos.push(0, 0, 0.08, s * 0.004, 0.006, 0.08, s * 0.035, 0.03, 0.15); out.side.push(0, 0, 0); out.shade.push(-1, -1, -1); }
  return out;
}

function dragonflyGeometry() {
  const out = { pos: [], side: [], shade: [] };
  for (const s of [-1, 1]) {
    fan(ellipse(0.11, 0.0, 0.11, 0.022, Math.PI, -Math.PI, 8).map(([x, z]) => [x + 0.0, z + 0.03]), s, s, out); // front pair
    fan(ellipse(0.1, 0.0, 0.1, 0.026, Math.PI, -Math.PI, 8).map(([x, z]) => [x, z - 0.015]), s, s * 0.8, out); // rear pair
  }
  body(0.26, 0.011, -0.18, out); // long abdomen and thorax
  return out;
}

function makeInstanced(def, inst, { transparent = false }) {
  const geo = new THREE.InstancedBufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(def.pos, 3));
  geo.setAttribute('side', new THREE.Float32BufferAttribute(def.side, 1));
  geo.setAttribute('shade', new THREE.Float32BufferAttribute(def.shade, 1));
  geo.setAttribute('aBase', new THREE.InstancedBufferAttribute(new Float32Array(inst.base), 3));
  geo.setAttribute('aSeed', new THREE.InstancedBufferAttribute(new Float32Array(inst.seed), 1));
  geo.setAttribute('aCol', new THREE.InstancedBufferAttribute(new Float32Array(inst.col), 3));
  geo.instanceCount = inst.seed.length;
  return geo;
}

const FRAG = /* glsl */ `varying vec3 vCol; varying float vA; void main(){ gl_FragColor = vec4(vCol, vA);
  #include <colorspace_fragment>
}`;

export function insects(rand, { height, wanted, notWater, riverSpots }) {
  const group = new THREE.Group();
  group.name = 'insects';
  const uniforms = { uTime: { value: 0 } };

  // ---- butterflies ----
  const bi = { base: [], seed: [], col: [] };
  const cols = ['#f3c6cf', '#c6b6e3', '#b7d3ea', '#f5e3a4', '#fbf8f2', '#f6caa6'].map((c) => new THREE.Color(c));
  for (let t = 0; t < 8000 && bi.seed.length < 200; t++) {
    const x = (rand() - 0.5) * 300, z = (rand() - 0.5) * 300;
    if (!wanted(x, z) || !notWater(x, z) || Math.hypot(x, z) > 170) continue;
    bi.base.push(x, height(x, z) + 0.6 + rand() * 1.1, z);
    bi.seed.push(rand());
    const c = cols[Math.floor(rand() * cols.length)];
    bi.col.push(c.r, c.g, c.b);
  }
  const bmat = new THREE.ShaderMaterial({
    side: THREE.DoubleSide, uniforms,
    vertexShader: /* glsl */ `
      attribute float side; attribute float shade; attribute vec3 aBase; attribute float aSeed; attribute vec3 aCol;
      uniform float uTime; varying vec3 vCol; varying float vA;
      void main(){
        float t = uTime * (0.3 + aSeed * 0.22) + aSeed * 40.0;
        vec3 c = aBase + vec3(sin(t) * 2.0 + sin(t * 2.3) * 0.5, sin(t * 1.7) * 0.3 + sin(uTime * 3.0 + aSeed * 9.0) * 0.06, cos(t * 0.8) * 2.0);
        vec3 vel = vec3(cos(t) * 2.0, 0.0, -sin(t * 0.8) * 1.6);
        float yaw = atan(vel.x, vel.z);
        // flap: quick downstroke, slower glide pauses
        float ph = uTime * 11.0 + aSeed * 30.0;
        float flap = (0.55 + 0.6 * sin(ph)) * (0.6 + 0.4 * step(0.0, sin(ph * 0.21 + aSeed * 5.0)));
        vec3 p = position;
        if (side != 0.0) { float ang = flap * sign(side); float r = abs(p.x); p = vec3(sign(p.x) * r * cos(ang), p.y + r * sin(ang), p.z); }
        float cy = cos(yaw), sy = sin(yaw);
        p = vec3(p.x * cy + p.z * sy, p.y, -p.x * sy + p.z * cy);
        vCol = shade < 0.0 ? vec3(0.33, 0.31, 0.36) : aCol * mix(0.72, 1.06, shade);
        vA = 1.0;
        gl_Position = projectionMatrix * viewMatrix * vec4(c + p * 1.25, 1.0);
      }`,
    fragmentShader: FRAG,
  });
  const bmesh = new THREE.Mesh(makeInstanced(butterflyGeometry(), bi, {}), bmat);
  bmesh.frustumCulled = false;
  group.add(bmesh);

  // ---- dragonflies over the river margins ----
  const di = { base: [], seed: [], col: [] };
  const dcols = ['#6fa7c4', '#7fb7a6', '#8e8cc6', '#c48a7a'].map((c) => new THREE.Color(c));
  for (const [x, y, z] of riverSpots) {
    di.base.push(x, y, z);
    di.seed.push(rand());
    const c = dcols[Math.floor(rand() * dcols.length)];
    di.col.push(c.r, c.g, c.b);
  }
  const dmat = new THREE.ShaderMaterial({
    side: THREE.DoubleSide, transparent: true, depthWrite: false, uniforms,
    vertexShader: /* glsl */ `
      attribute float side; attribute float shade; attribute vec3 aBase; attribute float aSeed; attribute vec3 aCol;
      uniform float uTime; varying vec3 vCol; varying float vA;
      float h(float n){ return fract(sin(n) * 43758.5453); }
      vec3 spot(float k){ return vec3(h(k * 12.9 + aSeed * 7.0) - 0.5, (h(k * 4.1 + aSeed) - 0.5) * 0.25, h(k * 7.7 + aSeed * 3.0) - 0.5) * vec3(3.0, 1.0, 3.0); }
      void main(){
        // hover, then dart to the next resting point
        float tt = uTime * (0.32 + aSeed * 0.2) + aSeed * 17.0;
        float k = floor(tt), f = fract(tt);
        float m = smoothstep(0.62, 0.78, f);
        vec3 a = spot(k), b = spot(k + 1.0);
        vec3 c = aBase + mix(a, b, m) + vec3(0.0, sin(uTime * 2.3 + aSeed * 11.0) * 0.03, 0.0);
        vec3 d = b - a; float yaw = atan(d.x, d.z);
        vec3 p = position;
        if (side != 0.0) { float ang = sin(uTime * 38.0 + aSeed * 20.0 + (abs(side) < 0.9 ? 1.6 : 0.0)) * 0.35; float r = abs(p.x); p = vec3(sign(p.x) * r * cos(ang), p.y + r * sin(ang), p.z); }
        float cy = cos(yaw), sy = sin(yaw);
        p = vec3(p.x * cy + p.z * sy, p.y, -p.x * sy + p.z * cy);
        vCol = shade < 0.0 ? aCol : mix(vec3(0.92, 0.96, 1.0), aCol, 0.18 + 0.2 * (1.0 - shade));
        vA = shade < 0.0 ? 1.0 : 0.5;
        gl_Position = projectionMatrix * viewMatrix * vec4(c + p * 1.6, 1.0);
      }`,
    fragmentShader: FRAG,
  });
  const dmesh = new THREE.Mesh(makeInstanced(dragonflyGeometry(), di, { transparent: true }), dmat);
  dmesh.frustumCulled = false;
  dmesh.renderOrder = 2;
  group.add(dmesh);

  return { group, uniforms, butterflies: bi.seed.length, dragonflies: di.seed.length };
}
