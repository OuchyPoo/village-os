// Terrain mesh with painted vertex colours: lush lawns, mossy forest floor, pebbly banks,
// grey rock on steep faces and snow on the high peaks.
import * as THREE from 'three';
import { fbm, noise, smoothstep } from '../core/math.js';
import { baseHeight } from './heightfield.js';
import { riverQuery, halfWidth } from './river.js';
import { forestPatch } from './layout.js';

const C = (h) => new THREE.Color(h);
const GRASS_A = C('#a3cd86'), GRASS_B = C('#b8d995'), GRASS_DARK = C('#8dbb7c'), FOREST = C('#7fae78');
const DRY = C('#c7d391'), LUSH = C('#93c487'), EARTH = C('#cdb89a'), MOSS = C('#7fa86f');
const BANK = C('#ddd3bd'), BED = C('#8fb1a7'), ROCK = C('#bab5ae'), ROCK_DARK = C('#a2a1ae'), SNOW = C('#f8f9fc'), HIGH_FOREST = C('#78a374');

function colourAt(tmp, x, z, y, ny, rd, pathEdge = 99) {
    const slope = Math.sqrt(Math.max(0, 1 - ny * ny)) / Math.max(ny, 0.05);
    const R = Math.hypot(x, z);
    // lawn base with soft mottling
    const m = fbm(x * 0.05, z * 0.05, 3) * 0.5 + 0.5;
    tmp.copy(GRASS_A).lerp(GRASS_B, m);
    const forest = smoothstep(40, 90, R) * forestPatch(x, z);
    tmp.lerp(GRASS_DARK, forest * 0.75);
    tmp.lerp(FOREST, smoothstep(140, 220, R) * 0.8);
    // mountains
    const alt = y - 20;
    tmp.lerp(HIGH_FOREST, smoothstep(30, 70, alt) * smoothstep(240, 300, R));
    tmp.lerp(ROCK, smoothstep(0.95, 1.7, slope) * smoothstep(80, 160, R) * (0.35 + 0.65 * smoothstep(40, 110, alt)));
    tmp.lerp(ROCK, smoothstep(95, 140, alt + noise(x * 0.02, z * 0.02) * 15));
    tmp.lerp(ROCK_DARK, smoothstep(120, 170, alt) * 0.5);
    tmp.lerp(SNOW, smoothstep(128, 160, alt + noise(x * 0.01, z * 0.01) * 20) * (1 - smoothstep(1.2, 2.0, slope) * 0.6));
    // steep valley banks show a little rock
    tmp.lerp(ROCK, smoothstep(0.9, 1.6, slope) * (1 - smoothstep(80, 160, R)) * 0.8);
    // meadow variety: drier, warmer swathes and lush, cooler hollows
    const meadow = 1 - smoothstep(0.2, 0.5, forestPatch(x, z));
    const dry = smoothstep(0.15, 0.6, noise(x * 0.018 + 31, z * 0.018 - 12));
    tmp.lerp(DRY, dry * meadow * 0.45 * (1 - smoothstep(140, 200, R)));
    tmp.lerp(LUSH, smoothstep(0.2, 0.7, noise(x * 0.05 - 4, z * 0.05 + 9)) * 0.3);
    // worn, earthy verges along lanes and trails, broken up so they never look ruled
    // (kept narrow so the worn halo never reads as walkable path beyond the real surface)
    const worn = (1 - smoothstep(-0.2, 0.9, pathEdge + noise(x * 0.5, z * 0.5) * 0.35)) * (0.55 + 0.45 * noise(x * 0.2 + 3, z * 0.2));
    tmp.lerp(EARTH, Math.max(0, worn) * 0.42);
    // moss under the woods
    tmp.lerp(MOSS, forestPatch(x, z) * smoothstep(45, 90, R) * 0.35 * (0.6 + 0.4 * noise(x * 0.09, z * 0.09)));
    // river banks and bed
    tmp.lerp(BANK, 1 - smoothstep(0.4, 2.6, rd + noise(x * 0.3, z * 0.3) * 0.6));
    if (rd < 0) tmp.lerp(BED, smoothstep(0, 2, -rd));
    return tmp;
}

// Coarse far landscape (mountains) around the detailed valley grid. Vertices inside the valley
// square are sunk below it so the two meshes never z-fight.
export function buildFarTerrain(hf) {
  const STEP = 10, EXT = 1700, IN = 220;
  const n = Math.round((EXT * 2) / STEP) + 1;
  const pos = new Float32Array(n * n * 3);
  const rds = new Float32Array(n * n);
  const q = {};
  for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
    const x = -EXT + i * STEP, z = -EXT + j * STEP, k = j * n + i;
    let y;
    if (Math.abs(x) < IN && Math.abs(z) < IN) y = hf.sample(x, z) - 3;
    else if (Math.abs(x) <= IN && Math.abs(z) <= IN) y = hf.sample(x, z) - 0.05;
    else y = baseHeight(x, z);
    riverQuery(x, z, q);
    rds[k] = q.d - halfWidth(q.z);
    pos[k * 3] = x; pos[k * 3 + 1] = y; pos[k * 3 + 2] = z;
  }
  const idx = [];
  for (let j = 0; j < n - 1; j++) for (let i = 0; i < n - 1; i++) {
    const x0 = -EXT + i * STEP, z0 = -EXT + j * STEP;
    if (x0 >= -IN + STEP && x0 + STEP <= IN - STEP && z0 >= -IN + STEP && z0 + STEP <= IN - STEP) continue; // fully hidden
    const A = j * n + i, B = A + 1, C = A + n, D = C + 1;
    idx.push(A, C, B, C, D, B);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  const nor = geo.attributes.normal.array;
  const col = new Float32Array(n * n * 3);
  const tmp = new THREE.Color();
  for (let k = 0; k < n * n; k++) {
    colourAt(tmp, pos[k * 3], pos[k * 3 + 2], pos[k * 3 + 1], nor[k * 3 + 1], rds[k]);
    col[k * 3] = tmp.r; col[k * 3 + 1] = tmp.g; col[k * 3 + 2] = tmp.b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.97 }));
  mesh.receiveShadow = true;
  mesh.name = 'farTerrain';
  return mesh;
}

export function buildTerrain(hf) {
  const n = hf.n, a = hf.axis;
  const pos = new Float32Array(n * n * 3);
  const col = new Float32Array(n * n * 3);
  const tmp = new THREE.Color();
  for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
    const k = j * n + i;
    const x = a[i], z = a[j], y = hf.h[k];
    pos[k * 3] = x; pos[k * 3 + 1] = y; pos[k * 3 + 2] = z;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const idx = new Uint32Array((n - 1) * (n - 1) * 6);
  let o = 0;
  for (let j = 0; j < n - 1; j++) for (let i = 0; i < n - 1; i++) {
    const A = j * n + i, B = A + 1, Cc = A + n, D = Cc + 1;
    idx[o++] = A; idx[o++] = Cc; idx[o++] = B;
    idx[o++] = Cc; idx[o++] = D; idx[o++] = B;
  }
  geo.setIndex(new THREE.BufferAttribute(idx, 1));
  geo.computeVertexNormals();
  const nor = geo.attributes.normal.array;

  for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
    const k = j * n + i;
    colourAt(tmp, a[i], a[j], hf.h[k], nor[k * 3 + 1], hf.riverD[k], hf.pathEdge ? hf.pathEdge[k] : 99);
    col[k * 3] = tmp.r; col[k * 3 + 1] = tmp.g; col[k * 3 + 2] = tmp.b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const uv = new Float32Array(n * n * 2);
  for (let k = 0; k < n * n; k++) { uv[k * 2] = pos[k * 3] / 3.2; uv[k * 2 + 1] = pos[k * 3 + 2] / 3.2; }
  geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.97, metalness: 0, map: groundDetail() });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.receiveShadow = true;
  mesh.name = 'terrain';
  return mesh;
}

// Very subtle ground detail (blade strokes, speckles, soft clumps) multiplied over the painted colour.
function groundDetail() {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = '#f4f4f4'; g.fillRect(0, 0, 256, 256);
  let seed = 9;
  const r = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 60; i++) {
    const x = r() * 256, y = r() * 256, rad = 10 + r() * 30;
    const grd = g.createRadialGradient(x, y, 0, x, y, rad);
    const v = r() < 0.5 ? '255,255,255' : '205,215,200';
    grd.addColorStop(0, `rgba(${v},0.35)`); grd.addColorStop(1, `rgba(${v},0)`);
    g.fillStyle = grd;
    for (const ox of [-256, 0, 256]) for (const oy of [-256, 0, 256]) { g.beginPath(); g.arc(x + ox, y + oy, rad, 0, 6.29); g.fill(); }
  }
  for (let i = 0; i < 2600; i++) {
    const x = r() * 256, y = r() * 256, l = 3 + r() * 6, a = -1.2 + r() * 0.5;
    g.strokeStyle = r() < 0.55 ? `rgba(150,170,140,${0.12 + r() * 0.12})` : `rgba(255,255,250,${0.2 + r() * 0.2})`;
    g.lineWidth = 0.8;
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l * 0.3, y + Math.sin(a) * l); g.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}
