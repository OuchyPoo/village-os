// Kit: build small assets from primitives into ONE vertex-coloured geometry, then scatter them as
// tiled InstancedMeshes. One material per family keeps draw calls low while every asset can mix
// many colours.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { addSway } from './vegetation.js';
import { mulberry32 } from '../core/math.js';

const _e = new THREE.Euler(), _q = new THREE.Quaternion(), _p = new THREE.Vector3(), _s = new THREE.Vector3();
export function M(x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = sx, sz = sx) {
  _e.set(rx, ry, rz, 'YXZ');
  return new THREE.Matrix4().compose(_p.set(x, y, z), _q.setFromEuler(_e), _s.set(sx, sy, sz));
}

// primitive cache (unit-ish shapes, scaled by matrices)
const P = new Map();
const prim = (key, make) => { if (!P.has(key)) P.set(key, make()); return P.get(key); };
export const G = {
  box: () => prim('box', () => new THREE.BoxGeometry(1, 1, 1)),
  rbox: (r = 0.12) => prim('rbox' + r, () => new RoundedBoxGeometry(1, 1, 1, 2, r)),
  cyl: (seg = 10, top = 1) => prim(`cyl${seg}-${top}`, () => new THREE.CylinderGeometry(top, 1, 1, seg)),
  cone: (seg = 10) => prim('cone' + seg, () => new THREE.ConeGeometry(1, 1, seg)),
  ball: (d = 1) => prim('ball' + d, () => new THREE.IcosahedronGeometry(1, d)),
  hemi: (seg = 12) => prim('hemi' + seg, () => new THREE.SphereGeometry(1, seg, 6, 0, Math.PI * 2, 0, Math.PI / 2)),
  torus: (seg = 16) => prim('torus' + seg, () => new THREE.TorusGeometry(1, 0.12, 6, seg)),
  disc: (seg = 12) => prim('disc' + seg, () => new THREE.CircleGeometry(1, seg).rotateX(-Math.PI / 2)),
  plane: () => prim('plane', () => new THREE.PlaneGeometry(1, 1)),
  // blade: wide base at y=0, tip at y=1
  tri: () => prim('tri', () => { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute([-0.5, 0, 0, 0.5, 0, 0, 0, 1, 0], 3)); g.computeVertexNormals(); return g; }),
  // pennant: wide top edge at y=0, point hanging to y=-1
  flag: () => prim('flag', () => { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute([-0.5, 0, 0, 0, -1, 0, 0.5, 0, 0], 3)); g.computeVertexNormals(); return g; }),
};

export class Kit {
  constructor() { this.parts = []; }
  add(geo, color, m) {
    const g = geo.index ? geo.toNonIndexed() : geo.clone();
    for (const n of Object.keys(g.attributes)) if (n !== 'position' && n !== 'normal') g.deleteAttribute(n);
    if (!g.attributes.normal) g.computeVertexNormals();
    g.applyMatrix4(m);
    const c = new THREE.Color(color);
    const n = g.attributes.position.count;
    const col = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b; }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    this.parts.push(g);
    return this;
  }
  build() {
    const g = mergeGeometries(this.parts, false);
    this.parts.forEach((p) => p.dispose());
    g.computeBoundingSphere();
    return g;
  }
}

// cached asset geometry: kit('name', seed, (k, rand) => {...})
const KC = new Map();
export function kit(name, build, variant = 0) {
  const key = name + ':' + variant;
  if (!KC.has(key)) {
    const k = new Kit();
    build(k, mulberry32(1000 + variant * 77 + name.length * 13), variant);
    KC.set(key, k.build());
  }
  return KC.get(key);
}

const MATS = {};
export function kitMaterial(kind = 'solid') {
  if (MATS[kind]) return MATS[kind];
  const base = { vertexColors: true, roughness: 0.86, metalness: 0 };
  if (kind === 'sway') MATS[kind] = addSway(new THREE.MeshStandardMaterial(base), 0.15, 0.06);
  else if (kind === 'swayTree') MATS[kind] = addSway(new THREE.MeshStandardMaterial(base), 1.2, 0.025);
  else if (kind === 'grass') MATS[kind] = addSway(new THREE.MeshStandardMaterial({ ...base, side: THREE.DoubleSide }), 0.0, 0.18);
  else if (kind === 'double') MATS[kind] = new THREE.MeshStandardMaterial({ ...base, side: THREE.DoubleSide });
  else MATS[kind] = new THREE.MeshStandardMaterial(base);
  return MATS[kind];
}

// Scatter instances [{x,y,z,s,rot,sy?,tilt?}] of one geometry as spatially tiled InstancedMeshes.
export function scatter(geo, list, { mat = 'solid', shadow = true, tile = 48, name = 'kit', tints = null, rand = mulberry32(5) } = {}) {
  const group = new THREE.Group();
  group.name = name;
  if (!list.length) return group;
  const tiles = new Map();
  for (const it of list) {
    const key = Math.floor(it.x / tile) + ',' + Math.floor(it.z / tile);
    if (!tiles.has(key)) tiles.set(key, []);
    tiles.get(key).push(it);
  }
  const material = typeof mat === 'string' ? kitMaterial(mat) : mat;
  const m = new THREE.Matrix4(), c = new THREE.Color();
  for (const items of tiles.values()) {
    const mesh = new THREE.InstancedMesh(geo, material, items.length);
    items.forEach((it, i) => {
      _e.set(it.tiltX || 0, it.rot || 0, it.tiltZ || 0, 'YXZ');
      m.compose(_p.set(it.x, it.y, it.z), _q.setFromEuler(_e), _s.set(it.s * (it.sx ?? 1), it.s * (it.sy ?? 1), it.s * (it.sz ?? 1)));
      mesh.setMatrixAt(i, m);
      if (tints) mesh.setColorAt(i, c.set(tints[Math.floor(rand() * tints.length)]));
    });
    mesh.castShadow = shadow;
    mesh.receiveShadow = true;
    mesh.computeBoundingSphere();
    group.add(mesh);
  }
  return group;
}

// ---- glTF assets (from the downloaded packs) as instanced, tiled meshes ----
const GP = new WeakMap();
// Bakes each mesh of a glTF into world-space geometry + cloned material.
// center: 'base' puts the footprint centre at the origin with the lowest point at y=0; 'mid' centres fully.
export function gltfParts(gltf, { center = 'base', sway = null, key = '' } = {}) {
  const ck = center + '|' + (sway ? sway.join(',') : '') + key;
  let byKey = GP.get(gltf);
  if (!byKey) { byKey = new Map(); GP.set(gltf, byKey); }
  if (byKey.has(ck)) return byKey.get(ck);
  gltf.scene.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(gltf.scene);
  const c = box.getCenter(new THREE.Vector3());
  const off = center === 'base' ? new THREE.Vector3(-c.x, -box.min.y, -c.z) : center === 'mid' ? c.clone().negate() : new THREE.Vector3();
  const parts = [];
  gltf.scene.traverse((o) => {
    if (!o.isMesh) return;
    const geo = o.geometry.clone().applyMatrix4(o.matrixWorld).translate(off.x, off.y, off.z);
    const mats = Array.isArray(o.material) ? o.material : [o.material];
    mats.forEach((m0, mi) => {
      let g = geo;
      if (mats.length > 1) { g = geo.clone(); g.clearGroups(); const grp = geo.groups.find((q) => q.materialIndex === mi); if (grp) g.setDrawRange(grp.start, grp.count); }
      const m = m0.clone();
      m.metalness = 0; m.roughness = Math.max(m.roughness ?? 0.9, 0.8);
      if (m.alphaTest > 0 || m.transparent) { m.transparent = false; m.alphaTest = Math.max(m.alphaTest, 0.45); m.side = THREE.DoubleSide; }
      parts.push({ geo: g, mat: sway ? addSway(m, sway[0], sway[1]) : m });
    });
  });
  byKey.set(ck, parts);
  return parts;
}

export function scatterGLTF(gltf, list, { shadow = true, tile = 48, name = 'gltf', center = 'base', sway = null } = {}) {
  const group = new THREE.Group();
  group.name = name;
  if (!list.length || !gltf) return group;
  const parts = gltfParts(gltf, { center, sway });
  const tiles = new Map();
  for (const it of list) {
    const key = Math.floor(it.x / tile) + ',' + Math.floor(it.z / tile);
    if (!tiles.has(key)) tiles.set(key, []);
    tiles.get(key).push(it);
  }
  const m = new THREE.Matrix4();
  for (const items of tiles.values()) {
    for (const { geo, mat } of parts) {
      const mesh = new THREE.InstancedMesh(geo, mat, items.length);
      items.forEach((it, i) => {
        _e.set(it.tiltX || 0, it.rot || 0, it.tiltZ || 0, 'YXZ');
        m.compose(_p.set(it.x, it.y, it.z), _q.setFromEuler(_e), _s.set(it.s, it.s * (it.sy ?? 1), it.s * (it.sz ?? 1)));
        mesh.setMatrixAt(i, m);
      });
      mesh.castShadow = shadow;
      mesh.receiveShadow = true;
      mesh.computeBoundingSphere();
      group.add(mesh);
    }
  }
  return group;
}
