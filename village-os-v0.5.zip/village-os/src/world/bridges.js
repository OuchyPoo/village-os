// Stone arch bridges, generated wherever a lane crosses the river.
import * as THREE from 'three';
import { masonryTexture, cobbleTexture } from './textures.js';

let stoneMat, deckMat;
function mats() {
  if (!stoneMat) {
    const t = masonryTexture();
    t.repeat.set(0.45, 0.45);
    stoneMat = new THREE.MeshStandardMaterial({ map: t, roughness: 0.92, color: '#f4efe6' });
    const c = cobbleTexture();
    deckMat = new THREE.MeshStandardMaterial({ map: c, roughness: 0.95 });
  }
  return { stoneMat, deckMat };
}

export function buildBridge(br) {
  const { stoneMat, deckMat } = mats();
  const [ax, ay, az] = br.a, [bx, by, bz] = br.b;
  const dx = bx - ax, dz = bz - az;
  const L = Math.hypot(dx, dz);
  const dir = new THREE.Vector3(dx / L, 0, dz / L);
  const side = new THREE.Vector3(-dir.z, 0, dir.x);
  const W = br.w + 0.8;
  const hump = 0.5 + L * 0.035;
  const top = (u) => ay + (by - ay) * (u / L) + hump * Math.sin(Math.PI * Math.min(1, Math.max(0, u / L)));
  const N = 24;
  const bottom = br.water - 2.6;

  const shape = new THREE.Shape();
  shape.moveTo(-0.6, bottom);
  shape.lineTo(-0.6, top(0) - 0.05);
  for (let i = 0; i <= N; i++) { const u = (i / N) * L; shape.lineTo(u, top(u) - 0.05); }
  shape.lineTo(L + 0.6, top(L) - 0.05);
  shape.lineTo(L + 0.6, bottom);
  shape.closePath();
  const u1 = L * 0.17, u2 = L * 0.83;
  const archTop = Math.max(br.water + 1.4, top(L / 2) - 0.9);
  const hole = new THREE.Path();
  hole.moveTo(u1, br.water - 1.4);
  for (let i = 0; i <= 20; i++) {
    const a = Math.PI - (i / 20) * Math.PI;
    const cx = (u1 + u2) / 2, rx = (u2 - u1) / 2;
    const base = br.water - 0.2;
    hole.lineTo(cx + Math.cos(a) * rx, base + Math.sin(a) * (archTop - base));
  }
  hole.lineTo(u2, br.water - 1.4);
  hole.closePath();
  shape.holes.push(hole);

  const basis = new THREE.Matrix4().makeBasis(dir, new THREE.Vector3(0, 1, 0), side.clone());
  // right-handed: dir × up = side
  const place = (g, offZ) => {
    g.translate(0, 0, offZ);
    g.applyMatrix4(basis);
    g.translate(ax, 0, az);
    return g;
  };
  const group = new THREE.Group();
  group.name = 'bridge';
  const bodyGeo = place(new THREE.ExtrudeGeometry(shape, { depth: W - 0.6, bevelEnabled: true, bevelThickness: 0.15, bevelSize: 0.15, bevelSegments: 2, curveSegments: 4 }), -(W - 0.6) / 2);
  const body = new THREE.Mesh(bodyGeo, stoneMat);
  body.castShadow = body.receiveShadow = true;
  group.add(body);

  // parapets
  for (const s of [-1, 1]) {
    const p = new THREE.Shape();
    p.moveTo(-0.3, top(0) - 0.1);
    for (let i = 0; i <= N; i++) { const u = (i / N) * L; p.lineTo(u, top(u) - 0.1); }
    p.lineTo(L + 0.3, top(L) - 0.1);
    p.lineTo(L + 0.3, top(L) + 0.75);
    for (let i = N; i >= 0; i--) { const u = (i / N) * L; p.lineTo(u, top(u) + 0.75); }
    p.lineTo(-0.3, top(0) + 0.75);
    p.closePath();
    const g = place(new THREE.ExtrudeGeometry(p, { depth: 0.26, bevelEnabled: true, bevelThickness: 0.08, bevelSize: 0.08, bevelSegments: 3, curveSegments: 4 }), s * (W / 2 - 0.25) - 0.13);
    const m = new THREE.Mesh(g, stoneMat);
    m.castShadow = m.receiveShadow = true;
    group.add(m);
  }
  // cobbled deck
  const pos = [], uv = [], idx = [];
  const dw = W - 0.7;
  for (let i = 0; i <= N; i++) {
    const u = (i / N) * L;
    for (const sgn of [-1, 1]) {
      const p = new THREE.Vector3(ax, 0, az).addScaledVector(dir, u).addScaledVector(side, (sgn * dw) / 2);
      pos.push(p.x, top(u) + 0.02, p.z);
      uv.push(sgn < 0 ? 0 : 1, u / dw);
    }
    if (i > 0) { const a = (i - 1) * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
  }
  const dg = new THREE.BufferGeometry();
  dg.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  dg.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  dg.setIndex(idx);
  dg.computeVertexNormals();
  const deck = new THREE.Mesh(dg, deckMat);
  deck.receiveShadow = true;
  group.add(deck);

  // walkable surface + colliders
  const surface = {
    test(x, z) {
      const px = x - ax, pz = z - az;
      const u = px * dir.x + pz * dir.z;
      const v = px * side.x + pz * side.z;
      if (u < -0.5 || u > L + 0.5 || Math.abs(v) > W / 2 - 0.2) return null;
      return top(Math.min(L, Math.max(0, u))) + 0.02;
    },
  };
  const segs = [-1, 1].map((s) => {
    const o = s * (W / 2 - 0.25);
    return {
      x0: ax + side.x * o - dir.x * 0.3, z0: az + side.z * o - dir.z * 0.3,
      x1: bx + side.x * o + dir.x * 0.3, z1: bz + side.z * o + dir.z * 0.3, r: 0.22,
      yTop: (x, z) => surface.test(x, z) ?? ay, h: 0.85,
    };
  });
  return { group, surface, segs, mid: new THREE.Vector3((ax + bx) / 2, top(L / 2), (az + bz) / 2), dir, L };
}
