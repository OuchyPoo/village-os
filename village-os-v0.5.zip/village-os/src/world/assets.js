// The environment asset library. Every factory returns a cached, vertex-coloured geometry
// (origin at ground level, +z = front). Variants change shape, proportion and colour.
import * as THREE from 'three';
import { kit, M, G } from './kit.js';

// Pastel palette shared by the whole world.
export { lavenderBush, roseBush, hydrangea, floweringShrub, peony, salvia, cottageFlowers } from './plants.js';
import { miniPlant } from './plants.js';
import { growTree } from './vegetation.js';

export const PAL = {
  sage: '#9fbf8f', sageDark: '#7fa475', sageDeep: '#6b9466', mint: '#bfe3c6', mintDeep: '#97cfa6', moss: '#8fb37a',
  leafA: '#a9cf8f', leafB: '#b8d9a0', leafC: '#93c08a', leafD: '#c6dfa8',
  powder: '#b7d3ea', powderDeep: '#8fb5d6', lavender: '#c6b6e3', lavenderDeep: '#a28fcf', lilac: '#d9c8ef',
  pink: '#efbcc4', pinkDeep: '#e19aa8', rose: '#f3c6cf', peach: '#f6caa6', peachDeep: '#eeae84',
  cream: '#f7eedb', creamDeep: '#ecdcbc', butter: '#f5e3a4', butterDeep: '#ecd27a', white: '#fbf8f2',
  terracotta: '#d48e6c', terracottaDeep: '#bf7658', wood: '#c2946a', woodDark: '#9b7354', woodGrey: '#b5a796',
  stone: '#cfc8bd', stoneDark: '#aea69b', bark: '#a07c5e', birch: '#f1ede4', water: '#9fcfd8',
};


// ---------- VEGETATION ----------

// Birch: slender pale trunk with dark lenticels, steep fine limbs and small airy leaf clumps.
export const birchTree = (v = 0) => kit('birch2', (k, r) => {
  const t = growTree(r, { parts: true, H: 5.2 + v * 0.8, trunkR: 0.16, nMain: 7, pitch: [0.3, 0.6], len: [1.0, 1.6], start: [0.45, 0.92], clump: [0.5, 0.75], flat: 1.1, second: 1, topClump: 2, lean: 0.08 });
  t.wood.forEach((g, i) => k.add(g, i < 3 ? PAL.birch : '#cfc8bd', new THREE.Matrix4()));
  for (let i = 0; i < 8; i++) k.add(G.box(), '#6f6a66', M(0, 0.6 + i * 0.55 + r() * 0.3, 0.14, 0, r() * 6, 0, 0.1, 0.035, 0.05));
  t.clumps.forEach((g, i) => k.add(g, [PAL.mint, PAL.leafB, PAL.leafD][i % 3], new THREE.Matrix4()));
}, v);

export const willowTree = (v = 0) => kit('willow', (k, r) => {
  k.add(G.cyl(10, 0.6), PAL.bark, M(0, 1.3, 0, 0.1, 0, 0.08, 0.38, 2.6, 0.38));
  k.add(G.ball(2), PAL.sage, M(0, 3.6, 0, 0, 0, 0, 2.6, 1.5, 2.6));
  // hanging curtains of leaves
  for (let i = 0; i < 22; i++) {
    const a = (i / 22) * 6.28 + r() * 0.2, rr = 2.0 + r() * 0.5, len = 1.8 + r() * 1.3;
    k.add(G.cone(5), i % 3 ? PAL.sage : PAL.mintDeep, M(Math.cos(a) * rr, 3.2 - len / 2, Math.sin(a) * rr, Math.PI, 0, 0, 0.4, len, 0.4));
  }
}, v);

// Flowering cherry: a low, wide branching tree whose clumps mix blossom with fresh leaf.
export const blossomTree = (v = 0) => kit('blossom2', (k, r) => {
  const pinkSet = [[PAL.pink, PAL.rose, PAL.white], [PAL.lilac, PAL.lavender, PAL.white], [PAL.white, PAL.rose, PAL.cream]][v % 3];
  const t = growTree(r, { parts: true, H: 2.1, trunkR: 0.2, nMain: 5, pitch: [0.85, 1.2], len: [1.2, 1.8], start: [0.65, 0.95], clump: [0.6, 0.85], flat: 0.65, second: 2, lean: 0.25 });
  t.wood.forEach((g) => k.add(g, PAL.bark, new THREE.Matrix4()));
  t.clumps.forEach((g, i) => k.add(g, i % 5 === 4 ? PAL.leafB : pinkSet[i % 3], new THREE.Matrix4()));
}, v);

// Orchard tree: short trunk, open goblet of limbs, leafy clumps with fruit hanging beneath them.
export const fruitTree = (v = 0) => kit('fruit2', (k, r) => {
  const t = growTree(r, { parts: true, H: 1.5, trunkR: 0.18, nMain: 4, pitch: [0.6, 0.95], len: [1.1, 1.5], start: [0.8, 0.98], clump: [0.62, 0.85], flat: 0.75, second: 1, leader: false, lean: 0.15 });
  t.wood.forEach((g) => k.add(g, PAL.bark, new THREE.Matrix4()));
  t.clumps.forEach((g, i) => k.add(g, [PAL.leafA, PAL.leafC, PAL.leafB][(i + v) % 3], new THREE.Matrix4()));
  for (const [c, cr] of t.tips) for (let i = 0; i < 4; i++) {
    const a = r() * 6.28;
    k.add(G.ball(1), v ? PAL.butterDeep : PAL.terracotta, M(c.x + Math.cos(a) * cr * 0.75, c.y - cr * 0.2 + r() * 0.2, c.z + Math.sin(a) * cr * 0.75, 0, 0, 0, 0.085, 0.09, 0.085));
  }
}, v);

export const hedge = (v = 0) => kit('hedge', (k) => {
  k.add(G.rbox(0.3), v ? PAL.sageDark : PAL.sageDeep, M(0, 0.5, 0, 0, 0, 0, 2.0, 1.0, 0.8));
  k.add(G.ball(1), v ? PAL.sage : PAL.sageDark, M(-0.6, 0.95, 0.05, 0, 0, 0, 0.42, 0.25, 0.35));
  k.add(G.ball(1), v ? PAL.sage : PAL.sageDark, M(0.5, 0.97, -0.05, 0, 0, 0, 0.45, 0.24, 0.35));
}, v);

export const topiary = (v = 0) => kit('topiary', (k) => {
  k.add(G.cyl(12, 0.8), PAL.terracotta, M(0, 0.25, 0, 0, 0, 0, 0.32, 0.5, 0.32));
  k.add(G.cyl(12, 1), PAL.terracottaDeep, M(0, 0.52, 0, 0, 0, 0, 0.36, 0.06, 0.36));
  k.add(G.cyl(6, 1), PAL.woodDark, M(0, 0.85, 0, 0, 0, 0, 0.04, 0.7, 0.04));
  if (v === 0) k.add(G.ball(2), PAL.sageDark, M(0, 1.35, 0, 0, 0, 0, 0.42));
  else { k.add(G.ball(2), PAL.sageDark, M(0, 1.1, 0, 0, 0, 0, 0.3)); k.add(G.ball(2), PAL.sageDark, M(0, 1.6, 0, 0, 0, 0, 0.22)); }
}, v);




export const fern = (v = 0) => kit('fern', (k, r) => {
  const n = 7 + v;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * 6.28 + r() * 0.3, len = 0.6 + r() * 0.35;
    // frond: a flattened, tilted cone
    k.add(G.cone(4), i % 2 ? PAL.sageDeep : PAL.moss, M(Math.cos(a) * len * 0.45, 0.22, Math.sin(a) * len * 0.45, 0, -a + Math.PI / 2, 1.05, 0.13, len, 0.03));
  }
}, v);

export const tallGrass = (v = 0) => kit('tallgrass', (k, r) => {
  const cols = [[PAL.sage, PAL.leafD, PAL.mint], [PAL.butter, PAL.leafD, PAL.sage], [PAL.mintDeep, PAL.sage, PAL.leafB]][v % 3];
  for (let i = 0; i < 9; i++) {
    const a = r() * 6.28, rr = r() * 0.18, h = 0.45 + r() * 0.45;
    k.add(G.tri(), cols[i % 3], M(Math.cos(a) * rr, 0, Math.sin(a) * rr, (r() - 0.5) * 0.4, r() * 6.28, (r() - 0.5) * 0.3, 0.08, h, 1));
  }
  if (v === 1) for (let i = 0; i < 4; i++) k.add(G.ball(0), PAL.creamDeep, M((r() - 0.5) * 0.3, 0.85 + r() * 0.2, (r() - 0.5) * 0.3, 0, 0, 0, 0.035, 0.08, 0.035));
}, v);

export const clover = (v = 0) => kit('clover', (k, r) => {
  for (let i = 0; i < 9; i++) {
    const a = r() * 6.28, rr = r() * 0.35;
    k.add(G.disc(6), i % 2 ? PAL.mintDeep : PAL.sage, M(Math.cos(a) * rr, 0.04 + r() * 0.03, Math.sin(a) * rr, 0, 0, 0, 0.09 + r() * 0.04));
  }
  for (let i = 0; i < 3; i++) k.add(G.ball(0), v ? PAL.pink : PAL.white, M((r() - 0.5) * 0.5, 0.12, (r() - 0.5) * 0.5, 0, 0, 0, 0.05));
}, v);

// Wildflower clumps with different flower shapes.
export const wildflowers = (kind = 'daisy', v = 0) => kit('flower-' + kind, (k, r) => {
  const n = 6 + Math.floor(r() * 4);
  for (let i = 0; i < n; i++) {
    const a = r() * 6.28, rr = r() * 0.32, h = 0.25 + r() * 0.3;
    const x = Math.cos(a) * rr, z = Math.sin(a) * rr;
    k.add(G.cyl(3, 1), PAL.sageDark, M(x, h / 2, z, 0, 0, 0, 0.012, h, 0.012));
    if (kind === 'daisy') {
      k.add(G.cyl(8, 1), v ? PAL.lilac : PAL.white, M(x, h, z, 0.2, 0, 0, 0.07, 0.015, 0.07));
      k.add(G.ball(0), PAL.butterDeep, M(x, h + 0.015, z, 0, 0, 0, 0.025));
    } else if (kind === 'poppy') {
      k.add(G.hemi(8), v ? PAL.peachDeep : PAL.terracotta, M(x, h - 0.02, z, Math.PI, 0, 0, 0.065, 0.06, 0.065));
      k.add(G.ball(0), '#5d5a63', M(x, h + 0.01, z, 0, 0, 0, 0.018));
    } else if (kind === 'cornflower') {
      k.add(G.ball(0), v ? PAL.lavenderDeep : PAL.powderDeep, M(x, h, z, 0, 0, 0, 0.045));
    } else if (kind === 'foxglove') {
      const H = h + 0.35;
      k.add(G.cyl(3, 1), PAL.sageDark, M(x, H / 2, z, 0, 0, 0, 0.014, H, 0.014));
      for (let j = 0; j < 5; j++) k.add(G.cone(5), v ? PAL.lilac : PAL.pinkDeep, M(x + 0.03, H - 0.05 - j * 0.07, z, Math.PI, 0, 0.4, 0.03, 0.06, 0.03));
    } else if (kind === 'buttercup') {
      k.add(G.hemi(6), PAL.butter, M(x, h - 0.01, z, Math.PI, 0, 0, 0.04, 0.03, 0.04));
    }
  }
  for (let i = 0; i < 4; i++) { const a = r() * 6.28; k.add(G.tri(), PAL.sageDark, M(Math.cos(a) * 0.08, 0, Math.sin(a) * 0.08, (r() - 0.5) * 0.5, r() * 6.28, 0, 0.06, 0.22, 1)); }
}, v);


export const undergrowth = (v = 0) => kit('undergrowth', (k, r) => {
  for (let i = 0; i < 4; i++) {
    const a = r() * 6.28, rr = r() * 0.5;
    k.add(G.ball(1), [PAL.sageDeep, PAL.moss, PAL.sageDark][i % 3], M(Math.cos(a) * rr, 0.15, Math.sin(a) * rr, 0, 0, 0, 0.35 + r() * 0.2, 0.25 + r() * 0.1, 0.35 + r() * 0.2));
  }
}, v);

// ---------- WOODLAND ----------

export const fallenLog = (v = 0) => kit('log', (k, r) => {
  const L = 3 + v * 1.2;
  k.add(G.cyl(10, 0.9), PAL.bark, M(0, 0.32, 0, 0, 0, Math.PI / 2, 0.32, L, 0.32));
  k.add(G.cyl(10, 1), PAL.creamDeep, M(L / 2 + 0.005, 0.32, 0, 0, 0, Math.PI / 2, 0.27, 0.02, 0.27));
  k.add(G.cyl(10, 1), PAL.creamDeep, M(-L / 2 - 0.005, 0.32, 0, 0, 0, Math.PI / 2, 0.3, 0.02, 0.3));
  for (let i = 0; i < 4; i++) k.add(G.ball(1), PAL.moss, M(-L / 2 + 0.4 + r() * (L - 0.8), 0.58, (r() - 0.5) * 0.2, 0, 0, 0, 0.32, 0.1, 0.25));
  k.add(G.cyl(5, 0.4), PAL.bark, M(L * 0.15, 0.55, 0.25, 0.8, 0, 0, 0.06, 0.6, 0.06));
}, v);

export const stump = (v = 0) => kit('stump', (k, r) => {
  const h = 0.45 + v * 0.25;
  k.add(G.cyl(10, 0.85), PAL.bark, M(0, h / 2, 0, 0, 0, 0, 0.42, h, 0.42));
  k.add(G.cyl(10, 1), PAL.creamDeep, M(0, h + 0.005, 0, 0, 0, 0, 0.36, 0.02, 0.36));
  k.add(G.torus(16), PAL.wood, M(0, h + 0.02, 0, Math.PI / 2, 0, 0, 0.2, 0.2, 0.2));
  for (let i = 0; i < 4; i++) { const a = i * 1.57 + r(); k.add(G.cone(5), PAL.bark, M(Math.cos(a) * 0.48, 0.08, Math.sin(a) * 0.48, Math.sin(a) * 1.2, 0, -Math.cos(a) * 1.2, 0.12, 0.35, 0.12)); }
  if (v) k.add(G.ball(1), PAL.moss, M(0.1, h + 0.04, 0.05, 0, 0, 0, 0.22, 0.06, 0.18));
}, v);

export const mushrooms = (v = 0) => kit('mushroom', (k, r) => {
  const cap = [PAL.terracotta, PAL.peach, PAL.cream][v % 3];
  const n = 3 + Math.floor(r() * 3);
  for (let i = 0; i < n; i++) {
    const x = (r() - 0.5) * 0.4, z = (r() - 0.5) * 0.4, h = 0.08 + r() * 0.14, s = 0.06 + r() * 0.07;
    k.add(G.cyl(6, 0.8), PAL.cream, M(x, h / 2, z, 0, 0, 0, s * 0.35, h, s * 0.35));
    k.add(G.hemi(10), cap, M(x, h - 0.01, z, 0, 0, 0, s, s * 0.8, s));
    if (v === 0) for (let j = 0; j < 3; j++) { const a = r() * 6.28; k.add(G.ball(0), PAL.white, M(x + Math.cos(a) * s * 0.55, h + s * 0.5, z + Math.sin(a) * s * 0.55, 0, 0, 0, s * 0.15)); }
  }
}, v);

// ---------- RIVERBANK ----------

export const reeds = (v = 0) => kit('reeds', (k, r) => {
  for (let i = 0; i < 12; i++) {
    const a = r() * 6.28, rr = r() * 0.35, h = 0.8 + r() * 0.8;
    k.add(G.tri(), i % 2 ? PAL.sage : PAL.leafD, M(Math.cos(a) * rr, 0, Math.sin(a) * rr, (r() - 0.5) * 0.3, r() * 6.28, (r() - 0.5) * 0.3, 0.07, h, 1));
    if (v === 0 && i % 3 === 0) {
      k.add(G.cyl(3, 1), PAL.sageDark, M(Math.cos(a) * rr, h / 2 + 0.1, Math.sin(a) * rr, 0, 0, 0, 0.012, h + 0.2, 0.012));
      k.add(G.cyl(6, 1), PAL.woodDark, M(Math.cos(a) * rr, h + 0.1, Math.sin(a) * rr, 0, 0, 0, 0.04, 0.22, 0.04));
    }
  }
}, v);

export const irises = (v = 0) => kit('iris', (k, r) => {
  for (let i = 0; i < 7; i++) {
    const a = r() * 6.28, rr = r() * 0.25, h = 0.5 + r() * 0.3;
    k.add(G.tri(), PAL.sageDark, M(Math.cos(a) * rr, 0, Math.sin(a) * rr, 0, r() * 6.28, (r() - 0.5) * 0.3, 0.09, h * 0.8, 1));
    if (i % 2) { k.add(G.cone(5), v ? PAL.butter : PAL.lavenderDeep, M(Math.cos(a) * rr, h + 0.04, Math.sin(a) * rr, Math.PI, 0, 0, 0.07, 0.1, 0.07)); }
  }
}, v);

export const lilyPads = (v = 0) => kit('lily', (k, r) => {
  for (let i = 0; i < 5; i++) {
    const x = (r() - 0.5) * 1.2, z = (r() - 0.5) * 1.2, s = 0.18 + r() * 0.15;
    k.add(G.disc(10), i % 2 ? PAL.mintDeep : PAL.sage, M(x, 0.01 + i * 0.002, z, 0, r() * 6, 0, s));
    if (i === 1 || (v && i === 3)) {
      k.add(G.cone(6), v ? PAL.pink : PAL.white, M(x, 0.05, z, 0, 0, 0, 0.07, 0.08, 0.07));
      k.add(G.ball(0), PAL.butter, M(x, 0.08, z, 0, 0, 0, 0.025));
    }
  }
}, v);

export const pebbles = (v = 0) => kit('pebbles', (k, r) => {
  const cols = [PAL.stone, PAL.stoneDark, PAL.creamDeep, '#c3c9cf'];
  for (let i = 0; i < 9; i++) {
    const a = r() * 6.28, rr = r() * 0.6, s = 0.06 + r() * 0.1;
    k.add(G.ball(1), cols[i % 4], M(Math.cos(a) * rr, s * 0.25, Math.sin(a) * rr, 0, r() * 3, 0, s * 1.3, s * 0.55, s));
  }
}, v);

export const branch = (v = 0) => kit('branch', (k, r) => {
  k.add(G.cyl(6, 0.6), PAL.woodGrey, M(0, 0.08, 0, 0, 0, Math.PI / 2, 0.07, 2.0, 0.07));
  k.add(G.cyl(5, 0.5), PAL.woodGrey, M(0.4, 0.1, 0.3, 0, -0.7, Math.PI / 2, 0.04, 0.8, 0.04));
  k.add(G.cyl(5, 0.5), PAL.woodGrey, M(-0.5, 0.1, -0.2, 0, 0.6, Math.PI / 2, 0.035, 0.6, 0.035));
}, v);

export const jetty = () => kit('jetty', (k) => {
  for (let i = 0; i < 9; i++) k.add(G.box(), i % 2 ? PAL.wood : PAL.woodGrey, M(0, 0.0, i * 0.42, 0, 0, 0, 1.6, 0.08, 0.38));
  for (const x of [-0.75, 0.75]) for (const z of [0.2, 1.8, 3.4]) k.add(G.cyl(6, 1), PAL.woodDark, M(x, -0.6, z, 0, 0, 0, 0.08, 1.6, 0.08));
  k.add(G.cyl(6, 1), PAL.woodDark, M(0.75, 0.35, 3.4, 0, 0, 0, 0.07, 0.7, 0.07));
}, 0);

export const rowboat = (v = 0) => kit('boat', (k) => {
  const hull = [PAL.powder, PAL.mint, PAL.pink][v % 3];
  const prof = [];
  for (let i = 0; i <= 8; i++) { const t = i / 8; prof.push(new THREE.Vector2(0.05 + Math.sin(t * Math.PI / 2) * 0.55, t * 0.42)); }
  const g = new THREE.LatheGeometry(prof, 14);
  k.add(g, hull, M(0, 0, 0, 0, 0, 0, 1, 1, 2.4));
  k.add(G.cyl(14, 1), PAL.wood, M(0, 0.4, 0, 0, 0, 0, 0.58, 0.03, 1.32 * 1.0));
  k.add(G.box(), PAL.woodDark, M(0, 0.3, 0.3, 0, 0, 0, 0.95, 0.05, 0.22));
  k.add(G.box(), PAL.woodDark, M(0, 0.3, -0.5, 0, 0, 0, 0.9, 0.05, 0.22));
  k.add(G.cyl(4, 1), PAL.wood, M(0.45, 0.45, 0, 0, 0, 1.3, 0.025, 1.6, 0.025));
}, v);

// ---------- MEADOW / FARM ----------

export const hayBale = (v = 0) => kit('hay', (k) => {
  if (v === 0) {
    k.add(G.cyl(16, 1), PAL.butterDeep, M(0, 0.6, 0, 0, 0, Math.PI / 2, 0.6, 1.1, 0.6));
    k.add(G.torus(20), PAL.creamDeep, M(0.555, 0.6, 0, 0, Math.PI / 2, 0, 0.35, 0.35, 0.35));
    k.add(G.torus(20), PAL.creamDeep, M(-0.555, 0.6, 0, 0, Math.PI / 2, 0, 0.35, 0.35, 0.35));
  } else {
    k.add(G.rbox(0.08), PAL.butterDeep, M(0, 0.3, 0, 0, 0, 0, 1.1, 0.6, 0.6));
    k.add(G.box(), PAL.terracottaDeep, M(0.25, 0.3, 0, 0, 0, 0, 0.03, 0.62, 0.62));
    k.add(G.box(), PAL.terracottaDeep, M(-0.25, 0.3, 0, 0, 0, 0, 0.03, 0.62, 0.62));
  }
}, v);

export const beehive = (v = 0) => kit('hive', (k) => {
  if (v === 0) { // straw skep on a stand
    k.add(G.box(), PAL.woodDark, M(0, 0.3, 0, 0, 0, 0, 0.7, 0.06, 0.7));
    for (const [x, z] of [[-0.3, -0.3], [0.3, -0.3], [-0.3, 0.3], [0.3, 0.3]]) k.add(G.box(), PAL.woodDark, M(x, 0.15, z, 0, 0, 0, 0.06, 0.3, 0.06));
    for (let i = 0; i < 5; i++) k.add(G.torus(14), PAL.butterDeep, M(0, 0.4 + i * 0.1, 0, Math.PI / 2, 0, 0, 0.3 - i * 0.045, 0.3 - i * 0.045, 0.5));
    k.add(G.ball(1), PAL.butterDeep, M(0, 0.86, 0, 0, 0, 0, 0.08));
  } else { // painted box hive
    k.add(G.box(), PAL.stoneDark, M(0, 0.15, 0, 0, 0, 0, 0.6, 0.3, 0.6));
    for (let i = 0; i < 3; i++) k.add(G.box(), [PAL.powder, PAL.butter, PAL.mint][i], M(0, 0.4 + i * 0.26, 0, 0, 0, 0, 0.55, 0.24, 0.55));
    k.add(G.box(), PAL.white, M(0, 1.2, 0, 0, 0, 0, 0.66, 0.08, 0.66));
  }
}, v);

// ---------- VILLAGE PROPS ----------

export const barrel = (v = 0) => kit('barrel', (k) => {
  const prof = [];
  for (let i = 0; i <= 8; i++) { const t = i / 8; prof.push(new THREE.Vector2(0.3 + Math.sin(t * Math.PI) * 0.07, t * 0.9)); }
  k.add(new THREE.LatheGeometry(prof, 14), v ? PAL.woodGrey : PAL.wood, M());
  for (const y of [0.15, 0.75]) k.add(G.torus(16), '#8d8a8a', M(0, y, 0, Math.PI / 2, 0, 0, 0.34, 0.34, 0.3));
  k.add(G.cyl(14, 1), PAL.woodDark, M(0, 0.89, 0, 0, 0, 0, 0.3, 0.02, 0.3));
  if (v === 2) for (let i = 0; i < 5; i++) k.add(G.ball(1), [PAL.terracotta, PAL.butter, PAL.peach][i % 3], M((i % 3 - 1) * 0.12, 0.93, (i > 2 ? 0.08 : -0.06), 0, 0, 0, 0.09));
}, v);

export const crate = (v = 0) => kit('crate', (k, r) => {
  k.add(G.box(), v ? PAL.woodGrey : PAL.wood, M(0, 0.25, 0, 0, 0, 0, 0.7, 0.5, 0.5));
  for (const y of [0.12, 0.38]) k.add(G.box(), PAL.woodDark, M(0, y, 0, 0, 0, 0, 0.72, 0.06, 0.52));
  const fruit = [PAL.terracotta, PAL.butterDeep, PAL.mintDeep, PAL.peachDeep][v % 4];
  for (let i = 0; i < 8; i++) k.add(G.ball(1), fruit, M(-0.22 + (i % 4) * 0.15, 0.52, -0.1 + Math.floor(i / 4) * 0.2, 0, 0, 0, 0.08 + r() * 0.02));
}, v);

export const basket = (v = 0) => kit('basket', (k, r) => {
  const prof = [new THREE.Vector2(0.01, 0), new THREE.Vector2(0.18, 0), new THREE.Vector2(0.24, 0.2), new THREE.Vector2(0.25, 0.22)];
  k.add(new THREE.LatheGeometry(prof, 12), PAL.butterDeep, M());
  k.add(G.torus(16), PAL.wood, M(0, 0.22, 0, 0, 0, 0, 0.2, 0.2, 0.25));
  const c = [[PAL.pink, PAL.white, PAL.lilac], [PAL.terracotta, PAL.butter], [PAL.mintDeep, PAL.sage]][v % 3];
  for (let i = 0; i < 6; i++) k.add(G.ball(1), c[i % c.length], M((r() - 0.5) * 0.25, 0.22, (r() - 0.5) * 0.25, 0, 0, 0, 0.07));
}, v);

export const marketStall = (v = 0) => kit('stall', (k, r) => {
  const stripe = [[PAL.pink, PAL.white], [PAL.powder, PAL.white], [PAL.mint, PAL.cream]][v % 3];
  // counter
  k.add(G.box(), PAL.wood, M(0, 0.45, 0, 0, 0, 0, 2.4, 0.9, 0.9));
  k.add(G.box(), PAL.cream, M(0, 0.92, 0, 0, 0, 0, 2.5, 0.06, 1.0));
  for (const x of [-1.15, 1.15]) for (const z of [-0.45, 0.45]) k.add(G.box(), PAL.woodDark, M(x, 1.25, z, 0, 0, 0, 0.08, 2.5, 0.08));
  // striped awning
  for (let i = 0; i < 8; i++) k.add(G.box(), stripe[i % 2], M(-1.1 + i * 0.315, 2.42, 0.1, -0.35, 0, 0, 0.315, 0.04, 1.5));
  for (let i = 0; i < 8; i++) k.add(G.cone(3), stripe[i % 2], M(-1.1 + i * 0.315, 2.04, 0.83, 0, 0, Math.PI, 0.16, 0.18, 0.02));
  // produce
  const crops = [PAL.terracotta, PAL.butterDeep, PAL.mintDeep, PAL.peachDeep, PAL.lavenderDeep];
  for (let j = 0; j < 3; j++) {
    k.add(G.box(), PAL.woodGrey, M(-0.8 + j * 0.8, 1.02, 0.1, 0, 0, 0, 0.6, 0.14, 0.5));
    for (let i = 0; i < 6; i++) k.add(G.ball(1), crops[(j + v) % 5], M(-0.8 + j * 0.8 + (i % 3 - 1) * 0.16, 1.14, 0.1 + (i > 2 ? 0.1 : -0.1), 0, 0, 0, 0.08 + r() * 0.02));
  }
  // hanging sign
  k.add(G.box(), PAL.cream, M(0, 2.0, 0.55, 0, 0, 0, 0.8, 0.26, 0.04));
}, v);

export const handCart = (v = 0) => kit('cart', (k, r) => {
  k.add(G.box(), v ? PAL.powderDeep : PAL.wood, M(0, 0.75, 0, 0, 0, 0, 1.1, 0.4, 1.6));
  k.add(G.box(), PAL.woodDark, M(0, 0.55, 0, 0, 0, 0, 1.12, 0.06, 1.62));
  for (const x of [-0.62, 0.62]) {
    k.add(G.torus(18), PAL.woodDark, M(x, 0.45, -0.1, 0, Math.PI / 2, 0, 0.42, 0.42, 0.42));
    k.add(G.cyl(8, 1), PAL.woodDark, M(x, 0.45, -0.1, 0, 0, Math.PI / 2, 0.06, 0.1, 0.06));
    for (let s = 0; s < 4; s++) k.add(G.box(), PAL.wood, M(x, 0.45, -0.1, s * 0.785, 0, 0, 0.03, 0.8, 0.04));
  }
  for (const x of [-0.4, 0.4]) k.add(G.cyl(5, 1), PAL.woodDark, M(x, 0.6, 1.3, 1.35, 0, 0, 0.035, 1.2, 0.035));
  const load = v === 1 ? [PAL.butterDeep] : [PAL.pink, PAL.white, PAL.lilac, PAL.peach];
  for (let i = 0; i < 10; i++) k.add(G.ball(1), load[i % load.length], M((r() - 0.5) * 0.8, 1.0 + r() * 0.1, (r() - 0.5) * 1.3, 0, 0, 0, 0.13 + r() * 0.05));
}, v);

export const signpost = (v = 0) => kit('signpost', (k) => {
  k.add(G.cyl(6, 1), PAL.woodDark, M(0, 1.2, 0, 0, 0, 0, 0.07, 2.4, 0.07));
  const cols = [PAL.cream, PAL.powder, PAL.pink, PAL.mint];
  for (let i = 0; i < 3; i++) {
    const a = i * 2.1 + v;
    k.add(G.box(), cols[(i + v) % 4], M(Math.sin(a) * 0.4, 2.0 - i * 0.32, Math.cos(a) * 0.4, 0, a + Math.PI / 2, 0, 0.9, 0.22, 0.05));
    k.add(G.cone(3), cols[(i + v) % 4], M(Math.sin(a) * 0.9, 2.0 - i * 0.32, Math.cos(a) * 0.9, 0, a, Math.PI / 2, 0.13, 0.15, 0.05));
  }
  k.add(G.cone(8), PAL.woodDark, M(0, 2.45, 0, 0, 0, 0, 0.1, 0.12, 0.1));
}, v);

export const well = () => kit('well', (k) => {
  const prof = [new THREE.Vector2(0.9, 0), new THREE.Vector2(0.95, 0.8), new THREE.Vector2(0.75, 0.82), new THREE.Vector2(0.72, 0.1)];
  k.add(new THREE.LatheGeometry(prof, 18), PAL.stone, M());
  k.add(G.cyl(18, 1), PAL.water, M(0, 0.55, 0, 0, 0, 0, 0.72, 0.02, 0.72));
  for (const x of [-0.85, 0.85]) k.add(G.box(), PAL.woodDark, M(x, 1.35, 0, 0, 0, 0, 0.12, 1.9, 0.12));
  k.add(G.cyl(8, 1), PAL.wood, M(0, 1.7, 0, 0, 0, Math.PI / 2, 0.08, 1.7, 0.08));
  for (const s of [-1, 1]) k.add(G.box(), PAL.terracotta, M(0, 2.55, s * 0.42, s * 0.75, 0, 0, 2.2, 0.08, 1.15));
  k.add(G.cyl(8, 0.8), PAL.woodGrey, M(0, 1.2, 0, 0, 0, 0, 0.16, 0.25, 0.16));
}, 0);

export const bunting = (len = 8, v = 0) => kit('bunting' + Math.round(len), (k, r) => {
  const cols = [PAL.pink, PAL.powder, PAL.butter, PAL.mint, PAL.lavender, PAL.peach];
  const n = Math.floor(len / 0.45);
  for (let i = 0; i <= n; i++) {
    const t = i / n, x = -len / 2 + t * len, sag = Math.sin(t * Math.PI) * 0.6;
    if (i < n) k.add(G.box(), PAL.white, M(x + len / n / 2, 3.6 - sag, 0, 0, 0, 0, len / n, 0.015, 0.015));
    if (i > 0 && i < n) k.add(G.flag(), cols[(i + v) % cols.length], M(x, 3.6 - sag, 0, 0, 0, 0, 0.32, 0.38, 1));
  }
  for (const x of [-len / 2, len / 2]) k.add(G.cyl(6, 1), PAL.white, M(x, 1.85, 0, 0, 0, 0, 0.06, 3.7, 0.06));
}, v);

export const laundryLine = (v = 0) => kit('laundry', (k, r) => {
  for (const x of [-1.8, 1.8]) { k.add(G.cyl(6, 1), PAL.woodGrey, M(x, 0.95, 0, 0, 0, 0, 0.05, 1.9, 0.05)); k.add(G.box(), PAL.woodGrey, M(x, 1.85, 0, 0, 0, 0, 0.05, 0.05, 0.4)); }
  k.add(G.box(), PAL.white, M(0, 1.83, 0, 0, 0, 0, 3.6, 0.01, 0.01));
  const cols = [PAL.white, PAL.powder, PAL.pink, PAL.butter, PAL.mint, PAL.lavender];
  let x = -1.5;
  for (let i = 0; i < 5; i++) { const w = 0.35 + r() * 0.35, h = 0.4 + r() * 0.4; k.add(G.box(), cols[(i + v) % 6], M(x + w / 2, 1.82 - h / 2, 0, 0, 0, 0, w, h, 0.02)); x += w + 0.12; }
}, v);

export const bistroSet = (v = 0) => kit('bistro', (k) => {
  const c = [PAL.powder, PAL.mint, PAL.white][v % 3];
  k.add(G.cyl(12, 1), c, M(0, 0.72, 0, 0, 0, 0, 0.4, 0.04, 0.4));
  k.add(G.cyl(6, 1), c, M(0, 0.36, 0, 0, 0, 0, 0.03, 0.72, 0.03));
  k.add(G.cyl(10, 1), c, M(0, 0.02, 0, 0, 0, 0, 0.2, 0.03, 0.2));
  for (const a of [0.4, 0.4 + Math.PI]) {
    const x = Math.cos(a) * 0.75, z = Math.sin(a) * 0.75;
    k.add(G.cyl(10, 1), c, M(x, 0.45, z, 0, 0, 0, 0.2, 0.03, 0.2));
    for (const [dx, dz] of [[-0.12, -0.12], [0.12, -0.12], [-0.12, 0.12], [0.12, 0.12]]) k.add(G.cyl(4, 1), c, M(x + dx, 0.22, z + dz, 0, 0, 0, 0.015, 0.45, 0.015));
    const bx = x + Math.cos(a) * 0.18, bz = z + Math.sin(a) * 0.18;
    k.add(G.box(), c, M(bx, 0.7, bz, 0, -a + Math.PI / 2, 0, 0.36, 0.42, 0.03));
  }
  k.add(G.cyl(8, 0.8), PAL.white, M(0, 0.8, 0, 0, 0, 0, 0.06, 0.12, 0.06));
  k.add(G.ball(1), PAL.pinkDeep, M(0, 0.9, 0, 0, 0, 0, 0.07));
}, v);

export const parasol = (v = 0) => kit('parasol', (k) => {
  const cols = [[PAL.pink, PAL.white], [PAL.powder, PAL.white], [PAL.butter, PAL.cream]][v % 3];
  k.add(G.cyl(6, 1), PAL.white, M(0, 1.2, 0, 0, 0, 0, 0.03, 2.4, 0.03));
  for (let i = 0; i < 8; i++) k.add(G.ball(0), cols[1], M(Math.cos(i * 0.785) * 1.18, 2.15, Math.sin(i * 0.785) * 1.18, 0, 0, 0, 0.05));
  k.add(G.cone(8), cols[0], M(0, 2.35, 0, 0, 0, 0, 1.2, 0.42, 1.2));
  k.add(G.cyl(10, 1), PAL.stoneDark, M(0, 0.05, 0, 0, 0, 0, 0.25, 0.1, 0.25));
}, v);

export const planter = (v = 0) => kit('planter', (k, r) => {
  if (v === 0) { // round terracotta pot of flowers
    const prof = [new THREE.Vector2(0.01, 0), new THREE.Vector2(0.2, 0), new THREE.Vector2(0.28, 0.4), new THREE.Vector2(0.31, 0.44)];
    k.add(new THREE.LatheGeometry(prof, 12), PAL.terracotta, M());
    for (let i = 0; i < 3; i++) { const a = (i / 3) * 6.28; miniPlant(k, r, Math.cos(a) * 0.12, Math.sin(a) * 0.12, 0.38, [PAL.pink, PAL.white, PAL.lilac][i], PAL.rose, i === 1 ? 'star' : 'mop'); }
  } else if (v === 1) { // stone urn with trailing ivy
    const prof = [new THREE.Vector2(0.18, 0), new THREE.Vector2(0.12, 0.25), new THREE.Vector2(0.28, 0.55), new THREE.Vector2(0.33, 0.62)];
    k.add(new THREE.LatheGeometry(prof, 12), PAL.stone, M());
    k.add(G.ball(1), PAL.sage, M(0, 0.68, 0, 0, 0, 0, 0.32, 0.2, 0.32));
    for (let i = 0; i < 5; i++) { const a = r() * 6.28; k.add(G.cone(4), PAL.sageDeep, M(Math.cos(a) * 0.3, 0.45, Math.sin(a) * 0.3, Math.PI, 0, 0, 0.07, 0.4, 0.07)); }
  } else { // long timber trough
    k.add(G.box(), PAL.wood, M(0, 0.22, 0, 0, 0, 0, 1.4, 0.44, 0.4));
    for (let i = 0; i < 10; i++) k.add(G.ball(0), [PAL.peach, PAL.butter, PAL.pink, PAL.leafA][i % 4], M(-0.6 + i * 0.13, 0.5, (r() - 0.5) * 0.2, 0, 0, 0, 0.09));
  }
}, v);

export const gardenArch = (v = 0) => kit('arch', (k, r) => {
  const w = 1.6;
  for (const x of [-w / 2, w / 2]) k.add(G.box(), PAL.white, M(x, 1.1, 0, 0, 0, 0, 0.08, 2.2, 0.35));
  for (let i = 0; i <= 10; i++) { const a = Math.PI * (i / 10); k.add(G.box(), PAL.white, M(Math.cos(a) * w / 2, 2.2 + Math.sin(a) * 0.5, 0, 0, 0, a + Math.PI / 2, 0.08, 0.2, 0.35)); }
  const bloom = [PAL.pinkDeep, PAL.rose, PAL.white, PAL.peach, PAL.lavender][v % 5];
  for (let i = 0; i < 26; i++) {
    const t = r(), side = r() < 0.6;
    const x = side ? (r() < 0.5 ? -w / 2 : w / 2) + (r() - 0.5) * 0.15 : Math.cos(Math.PI * t) * w / 2;
    const y = side ? 0.3 + r() * 1.9 : 2.2 + Math.sin(Math.PI * t) * 0.5;
    k.add(G.ball(1), i % 3 ? PAL.sageDark : PAL.sage, M(x, y, (r() - 0.5) * 0.35, 0, 0, 0, 0.16));
    if (i % 2) k.add(G.ball(0), bloom, M(x, y + 0.08, (r() - 0.5) * 0.4, 0, 0, 0, 0.07));
  }
}, v);

export const birdbath = () => kit('birdbath', (k) => {
  const prof = [new THREE.Vector2(0.25, 0), new THREE.Vector2(0.1, 0.12), new THREE.Vector2(0.08, 0.7), new THREE.Vector2(0.4, 0.82), new THREE.Vector2(0.42, 0.9)];
  k.add(new THREE.LatheGeometry(prof, 14), PAL.stone, M());
  k.add(G.cyl(14, 1), PAL.water, M(0, 0.86, 0, 0, 0, 0, 0.36, 0.02, 0.36));
  k.add(G.ball(1), PAL.powderDeep, M(0.3, 0.98, 0, 0, 0, 0, 0.06, 0.06, 0.09));
}, 0);

export const wheelbarrow = (v = 0) => kit('barrow', (k, r) => {
  k.add(G.box(), v ? PAL.mint : PAL.powderDeep, M(0, 0.55, 0, 0.1, 0, 0, 0.7, 0.3, 0.9));
  k.add(G.torus(14), '#7d7a78', M(0, 0.22, 0.55, 0, Math.PI / 2, 0, 0.2, 0.2, 0.3));
  for (const x of [-0.25, 0.25]) { k.add(G.cyl(4, 1), PAL.woodDark, M(x, 0.45, -0.55, 1.2, 0, 0, 0.025, 0.9, 0.025)); k.add(G.cyl(4, 1), PAL.woodDark, M(x, 0.2, -0.25, 0, 0, 0, 0.025, 0.4, 0.025)); }
  for (let i = 0; i < 5; i++) k.add(G.ball(1), v ? PAL.butterDeep : PAL.sageDark, M((r() - 0.5) * 0.4, 0.72, (r() - 0.5) * 0.6, 0, 0, 0, 0.13));
}, v);

export const wateringCan = () => kit('can', (k) => {
  k.add(G.cyl(12, 1), PAL.powderDeep, M(0, 0.17, 0, 0, 0, 0, 0.14, 0.34, 0.14));
  k.add(G.cyl(5, 0.4), PAL.powderDeep, M(0.2, 0.25, 0, 0, 0, -0.9, 0.025, 0.35, 0.025));
  k.add(G.torus(10), PAL.powderDeep, M(-0.05, 0.36, 0, 0, 0, 0, 0.1, 0.1, 0.3));
}, 0);

export const lanternPost = (v = 0) => kit('lanternpost', (k) => {
  k.add(G.box(), PAL.cream, M(0, 0.6, 0, 0, 0, 0, 0.14, 1.2, 0.14));
  k.add(G.box(), '#fff1c6', M(0, 1.34, 0, 0, 0, 0, 0.2, 0.26, 0.2));
  k.add(G.cone(4), v ? PAL.powderDeep : PAL.sageDark, M(0, 1.55, 0, 0, Math.PI / 4, 0, 0.2, 0.18, 0.2));
}, v);

export const flowerbed = (v = 0) => kit('flowerbed', (k, r) => {
  const w = 2.4, d = 1.0;
  const edge = v === 1 ? PAL.stone : PAL.wood;
  k.add(G.box(), edge, M(0, 0.12, d / 2, 0, 0, 0, w, 0.24, 0.08));
  k.add(G.box(), edge, M(0, 0.12, -d / 2, 0, 0, 0, w, 0.24, 0.08));
  k.add(G.box(), edge, M(w / 2, 0.12, 0, 0, 0, 0, 0.08, 0.24, d));
  k.add(G.box(), edge, M(-w / 2, 0.12, 0, 0, 0, 0, 0.08, 0.24, d));
  k.add(G.box(), '#a88d74', M(0, 0.18, 0, 0, 0, 0, w - 0.1, 0.06, d - 0.1));
  const sets = [[PAL.pink, PAL.white, PAL.lavender], [PAL.peach, PAL.butter, PAL.white], [PAL.powder, PAL.lilac, PAL.rose]][v % 3];
  // staggered clumps, each a small leafy plant with real flowers
  for (let i = 0; i < 10; i++) {
    const x = -w / 2 + 0.25 + (i / 9) * (w - 0.5) + (r() - 0.5) * 0.08, z = (i % 2 ? 0.2 : -0.2) + (r() - 0.5) * 0.08;
    miniPlant(k, r, x, z, 0.2, sets[i % 3], sets[(i + 1) % 3], i % 3 === 1 ? 'star' : 'mop');
  }
}, v);

export const bench2 = (v = 0) => kit('bench2', (k) => {
  const c = [PAL.white, PAL.powder, PAL.mint][v % 3];
  for (let i = 0; i < 3; i++) k.add(G.box(), c, M(0, 0.45, -0.15 + i * 0.15, 0, 0, 0, 1.5, 0.05, 0.12));
  for (let i = 0; i < 2; i++) k.add(G.box(), c, M(0, 0.68 + i * 0.16, -0.27, 0, 0, 0, 1.5, 0.1, 0.04));
  for (const x of [-0.65, 0.65]) { k.add(G.box(), c, M(x, 0.22, 0, 0, 0, 0, 0.06, 0.45, 0.45)); k.add(G.box(), c, M(x, 0.6, -0.27, 0, 0, 0, 0.06, 0.75, 0.05)); }
}, v);

export const milkChurns = () => kit('churns', (k) => {
  for (const [x, z, s] of [[0, 0, 1], [0.38, 0.12, 0.9], [0.15, 0.38, 0.85]]) {
    k.add(G.cyl(12, 0.7), '#cfd6dc', M(x, 0.3 * s, z, 0, 0, 0, 0.17 * s, 0.6 * s, 0.17 * s));
    k.add(G.cyl(12, 1), '#cfd6dc', M(x, 0.66 * s, z, 0, 0, 0, 0.1 * s, 0.14 * s, 0.1 * s));
    k.add(G.cyl(12, 1), PAL.powderDeep, M(x, 0.75 * s, z, 0, 0, 0, 0.12 * s, 0.04 * s, 0.12 * s));
  }
}, 0);

export const woodpile = () => kit('woodpile', (k, r) => {
  for (let row = 0; row < 4; row++) for (let i = 0; i < 6 - row; i++) {
    const x = -0.7 + i * 0.28 + row * 0.14, y = 0.14 + row * 0.24;
    k.add(G.cyl(7, 1), PAL.wood, M(x, y, 0, Math.PI / 2, 0, 0, 0.13, 0.9, 0.13));
    k.add(G.cyl(7, 1), PAL.creamDeep, M(x, y, 0.451, Math.PI / 2, 0, 0, 0.11, 0.01, 0.11));
  }
  k.add(G.box(), PAL.terracotta, M(0, 1.15, 0, 0, 0, 0.05, 2.0, 0.06, 1.1));
}, 0);

// ---------- LANDSCAPING (v0.3) ----------

// Unit garden bed (1 x 1 m footprint, scaled along x/z): mounded soil inside a soft stone edge.
export const gardenBed = (v = 0) => kit('gardenBed', (k) => {
  const edge = v ? PAL.wood : PAL.stone;
  k.add(G.rbox(0.12), '#a88f76', M(0, 0.06, 0, 0, 0, 0, 0.94, 0.16, 0.86));
  k.add(G.rbox(0.2), '#9b8169', M(0, 0.1, 0, 0, 0, 0, 0.8, 0.12, 0.7));
  for (const z of [-0.47, 0.47]) k.add(G.rbox(0.3), edge, M(0, 0.07, z, 0, 0, 0, 1.0, 0.14, 0.09));
  for (const x of [-0.5, 0.5]) k.add(G.rbox(0.3), edge, M(x, 0.07, 0, 0, 0, 0, 0.09, 0.14, 1.0));
}, v);

// Short meadow / lawn grass clump in mixed greens.
export const grassTuft = (v = 0) => kit('grassTuft', (k, r) => {
  const cols = [[PAL.sage, PAL.leafB, PAL.mintDeep], [PAL.leafA, PAL.leafD, PAL.sage], [PAL.sageDark, PAL.leafB, PAL.leafC]][v % 3];
  const n = 7 + Math.floor(r() * 5);
  for (let i = 0; i < n; i++) {
    const a = r() * 6.28, rr = r() * 0.12, h = 0.18 + r() * 0.24;
    k.add(G.tri(), cols[i % 3], M(Math.cos(a) * rr, 0, Math.sin(a) * rr, (r() - 0.5) * 0.6, r() * 6.28, (r() - 0.5) * 0.5, 0.06, h, 1));
  }
}, v);

// A flat, rounded edging stone for path verges.
export const edgeStone = (v = 0) => kit('edgeStone', (k, r) => {
  k.add(G.ball(1), [PAL.stone, PAL.stoneDark, '#d6d0c6'][v % 3], M(0, 0.02, 0, 0, r() * 3, 0, 0.22 + r() * 0.08, 0.08, 0.16 + r() * 0.06));
}, v);

// Weeping willow: a lumpy crown with long curtains of hanging leaf strands.
// Weeping willow: a leaning trunk that forks into arching limbs, a soft open crown, and long curtains
// of narrow leafy streamers that arc out from the limbs and fall straight, tapering and paling at
// the tips. Streamers vary in length and spacing so the outline is ragged like a real willow.
export const willowTree2 = (v = 0) => kit('willow3', (k, r) => {
  const up = new THREE.Vector3(0, 1, 0), q = new THREE.Quaternion();
  const limb = (a, b, r0, r1) => { const d = b.clone().sub(a), L = d.length(); const g = new THREE.CylinderGeometry(r1, r0, L, 6).translate(0, L / 2, 0); g.applyQuaternion(q.setFromUnitVectors(up, d.normalize())); g.translate(a.x, a.y, a.z); k.add(g, PAL.bark, new THREE.Matrix4()); };
  const base = new THREE.Vector3(0, 0, 0), fork = new THREE.Vector3(0.25, 2.4, 0.1);
  limb(base, fork, 0.42, 0.3);
  const tips = [];
  const nL = 5;
  for (let i = 0; i < nL; i++) {
    const a = (i / nL) * 6.28 + r() * 0.5, L = 1.8 + r() * 0.8;
    const mid = fork.clone().add(new THREE.Vector3(Math.cos(a) * L * 0.45, 1.3 + r() * 0.4, Math.sin(a) * L * 0.45));
    const tip = mid.clone().add(new THREE.Vector3(Math.cos(a) * L * 0.6, 0.35 + r() * 0.3, Math.sin(a) * L * 0.6));
    limb(fork, mid, 0.2, 0.13); limb(mid, tip, 0.13, 0.06);
    tips.push(tip, mid);
  }
  // soft crown over the limb tops
  // domed crown: clumps around every limb tip plus a central dome, so no limb ends poke out
  k.add(G.ball(2), PAL.sage, M(0.2, 4.2, 0.1, 0, 0, 0, 2.1, 1.05, 2.1));
  for (const t of tips) k.add(G.ball(1), r() < 0.5 ? PAL.sage : PAL.leafC, M(t.x, t.y + 0.05, t.z, 0, r() * 6, 0, 0.7 + r() * 0.2, 0.45 + r() * 0.15, 0.7 + r() * 0.2));
  // streamers: tapered two-sided ribbons, arcing outward then falling, darker at the top
  const cols = [PAL.sage, PAL.leafC, PAL.sageDark, PAL.mintDeep];
  const N = 120;
  for (let s = 0; s < N; s++) {
    const a = (s * 2.39996) % 6.28 + (r() - 0.5) * 0.1;
    const R0 = 0.9 + Math.sqrt(r()) * 2.0, y0 = 4.2 - (R0 / 2.9) * (R0 / 2.9) * 0.9; // from the underside of the dome
    const len = (1.6 + r() * 1.6) * (0.75 + R0 / 2.5 * 0.4), out = 0.25 + r() * 0.3, w0 = 0.12 + r() * 0.07;
    const seg = 6, pos = [], posLow = [];
    const P = (t) => { const rr = R0 + out * (1 - (1 - t) * (1 - t)); return [Math.cos(a) * rr, y0 - len * Math.pow(t, 1.35), Math.sin(a) * rr]; };
    const tx = -Math.sin(a), tz = Math.cos(a);
    for (let j = 0; j < seg; j++) {
      const t0 = j / seg, t1 = (j + 1) / seg;
      const [x0, yA, z0] = P(t0), [x1, yB, z1] = P(t1);
      const wA = w0 * (1 - t0 * 0.75) * (j % 2 ? 0.85 : 1), wB = w0 * (1 - t1 * 0.75) * (j % 2 ? 1 : 0.85);
      const A = [x0 - tx * wA / 2, yA, z0 - tz * wA / 2], B = [x0 + tx * wA / 2, yA, z0 + tz * wA / 2];
      const C = [x1 + tx * wB / 2, yB, z1 + tz * wB / 2], D = [x1 - tx * wB / 2, yB, z1 - tz * wB / 2];
      (j < 3 ? pos : posLow).push(...A, ...B, ...C, ...A, ...C, ...D, ...A, ...C, ...B, ...A, ...D, ...C);
    }
    const c = cols[s % cols.length];
    for (const [p, col] of [[pos, c], [posLow, '#' + new THREE.Color(c).lerp(new THREE.Color(PAL.leafD), 0.45).getHexString()]]) {
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(p, 3));
      g.computeVertexNormals();
      k.add(g, col, new THREE.Matrix4());
    }
  }
}, v);

// Garden plant clumps for planted beds (low, mid and tall habits).
// clipped box: a slightly irregular, flattened dome with a few soft lumps, not a perfect sphere
export const boxBall = (v = 0) => kit('boxBall2', (k, r) => {
  const c = v ? PAL.sageDeep : PAL.sageDark;
  k.add(G.ball(2), c, M(0, 0.26, 0, 0, r() * 6, 0, 0.34, 0.26, 0.31));
  for (let i = 0; i < 5; i++) { const a = r() * 6.28; k.add(G.ball(1), i % 2 ? c : PAL.sage, M(Math.cos(a) * 0.17, 0.3 + r() * 0.12, Math.sin(a) * 0.15, 0, r() * 6, 0, 0.17, 0.13, 0.16)); }
}, v);
