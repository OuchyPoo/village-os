// Rounded river stones and boulders: noise-displaced icospheres with mossy tops, instanced.
import * as THREE from 'three';
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { makeNoise2D, mulberry32 } from '../core/math.js';

function rockGeometry(seed) {
  const n = makeNoise2D(seed);
  let g = new THREE.IcosahedronGeometry(1, 3);
  g.deleteAttribute('uv'); g.deleteAttribute('normal');
  g = mergeVertices(g);
  const p = g.attributes.position;
  const v = new THREE.Vector3();
  for (let i = 0; i < p.count; i++) {
    v.fromBufferAttribute(p, i);
    const d = 1 + 0.22 * n(v.x * 1.3 + v.y * 0.7, v.z * 1.3 - v.y * 0.5) + 0.08 * n(v.x * 3.1, v.z * 3.1 + v.y * 2);
    v.multiplyScalar(d);
    v.y *= 0.62;
    if (v.y < -0.1) v.y *= 0.5;
    p.setXYZ(i, v.x, v.y, v.z);
  }
  g.computeVertexNormals();
  // moss on upward faces
  const nor = g.attributes.normal;
  const col = new Float32Array(p.count * 3);
  const stone = new THREE.Color('#c6c1b9'), moss = new THREE.Color('#9fc28a'), dark = new THREE.Color('#a6a19c');
  const c = new THREE.Color();
  for (let i = 0; i < p.count; i++) {
    const ny = nor.getY(i);
    c.copy(stone).lerp(dark, Math.max(0, -p.getY(i)) * 0.8);
    c.lerp(moss, THREE.MathUtils.smoothstep(ny, 0.82, 0.98) * 0.35);
    col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
  }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  return g;
}

// rocks: [{x,y,z,s,rot,mossy}]
export function buildRocks(rocks) {
  const group = new THREE.Group();
  group.name = 'rocks';
  const geos = [1, 2, 3, 4].map(rockGeometry);
  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9 });
  const rand = mulberry32(3);
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), p = new THREE.Vector3(), s = new THREE.Vector3(), e = new THREE.Euler();
  geos.forEach((g, gi) => {
    const list = rocks.filter((_, i) => i % geos.length === gi);
    const mesh = new THREE.InstancedMesh(g, mat, Math.max(1, list.length));
    list.forEach((r, i) => {
      e.set((rand() - 0.5) * 0.25, r.rot, (rand() - 0.5) * 0.25);
      q.setFromEuler(e);
      p.set(r.x, r.y, r.z);
      s.set(r.s * (0.85 + rand() * 0.4), r.s * (r.sy ?? 1), r.s * (0.85 + rand() * 0.4));
      m.compose(p, q, s);
      mesh.setMatrixAt(i, m);
    });
    mesh.count = list.length;
    mesh.castShadow = true; mesh.receiveShadow = true;
    mesh.computeBoundingSphere();
    group.add(mesh);
  });
  return group;
}
