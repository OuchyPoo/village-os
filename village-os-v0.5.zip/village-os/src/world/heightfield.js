// Terrain height model: a 1.25 m grid over the valley that gets shaped by the village plan
// (house pads, lanes, the square). Outside it, baseHeight() describes the mountains directly.
import { fbm, ridged, smoothstep, lerp, clamp } from '../core/math.js';
import { riverQuery, halfWidth, waterLevel, bankLevel } from './river.js';

export const INNER = 220;
export const CELL = 1.25;
const OUTER_STEPS = 0; // the far landscape is a separate coarse mesh (see terrain.js)

function buildAxis() {
  const n = Math.round((INNER * 2) / CELL);
  const out = [];
  for (let i = 0; i <= n; i++) out.push(-INNER + i * CELL);
  return out;
}

const q = {};
export function baseHeight(x, z) {
  riverQuery(x, z, q);
  const rz = q.z;
  const hw = halfWidth(rz);
  const W = waterLevel(rz);
  const B = Math.max(bankLevel(rz) + 1.9, W + 1.1);
  const r = Math.max(0, q.d - hw - 5);
  let h = B + 0.035 * r + 0.001 * r * r;
  h += fbm(x * 0.008, z * 0.008, 4) * 9 * smoothstep(10, 70, r);
  // rolling ground: gentle knolls and hollows across the village terraces, finer swells nearer the bank
  h += fbm(x * 0.013 + 3, z * 0.013 - 8, 3) * 2.4 * smoothstep(6, 40, r);
  h += fbm(x * 0.03 + 11, z * 0.03, 3) * 1.3 * smoothstep(3, 18, r);
  const R = Math.hypot(x, z * 0.9);
  const rid = ridged(x * 0.0034, z * 0.0034, 4);
  const soft = fbm(x * 0.0022 + 5.3, z * 0.0022 - 2.1, 4) * 0.5 + 0.5;
  const m = smoothstep(150, 360, R) * (28 + 230 * Math.pow(0.5 * rid + 0.5 * soft, 1.7)) * smoothstep(14, 120, q.d);
  h += m;
  if (q.d < hw + 4.5) {
    if (q.d <= hw) {
      const t = q.d / hw;
      h = W - 0.4 - 1.4 * (1 - t * t);
    } else {
      const t = smoothstep(hw, hw + 4.5, q.d);
      h = lerp(W + 0.2, h, t);
    }
  }
  return h;
}

export class Heightfield {
  constructor() {
    this.axis = buildAxis();
    this.n = this.axis.length;
    this.innerStart = OUTER_STEPS;
    this.innerCount = Math.round((INNER * 2) / CELL) + 1;
    this.h = new Float32Array(this.n * this.n);
    this.riverD = new Float32Array(this.n * this.n);
    this.mask = new Uint8Array(this.n * this.n); // 1 path, 2 pad, 4 water, 8 square, 16 bridge
    const a = this.axis;
    for (let j = 0; j < this.n; j++) for (let i = 0; i < this.n; i++) {
      const x = a[i], z = a[j];
      const k = j * this.n + i;
      this.h[k] = baseHeight(x, z);
      this.riverD[k] = q.d - halfWidth(q.z);
      if (this.riverD[k] < 0.6) this.mask[k] |= 4;
    }
  }

  idx(x, z) { // inner cell index (floating)
    return [(x + INNER) / CELL + this.innerStart, (z + INNER) / CELL + this.innerStart];
  }

  forCellsInRadius(x, z, r, fn) {
    const [fi, fj] = this.idx(x, z);
    const rc = Math.ceil(r / CELL);
    const i0 = Math.max(this.innerStart, Math.floor(fi) - rc), i1 = Math.min(this.innerStart + this.innerCount - 1, Math.ceil(fi) + rc);
    const j0 = Math.max(this.innerStart, Math.floor(fj) - rc), j1 = Math.min(this.innerStart + this.innerCount - 1, Math.ceil(fj) + rc);
    for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) fn(j * this.n + i, this.axis[i], this.axis[j]);
  }

  // Flatten an oriented rectangle (house plot) with a soft falloff.
  applyPad(cx, cz, rot, hx, hz, y, fall = 5) {
    const c = Math.cos(rot), s = Math.sin(rot);
    this.forCellsInRadius(cx, cz, Math.hypot(hx, hz) + fall, (k, x, z) => {
      const dx = x - cx, dz = z - cz;
      const lx = dx * c - dz * s, lz = dx * s + dz * c;
      const ox = Math.max(Math.abs(lx) - hx, 0), oz = Math.max(Math.abs(lz) - hz, 0);
      const d = Math.hypot(ox, oz);
      const t = 1 - smoothstep(0, fall, d);
      if (t <= 0) return;
      this.h[k] = lerp(this.h[k], y, t);
      if (d === 0) this.mask[k] |= 2;
    });
  }

  applyDisc(cx, cz, r, y, fall, maskBit = 8) {
    this.forCellsInRadius(cx, cz, r + fall, (k, x, z) => {
      const d = Math.max(0, Math.hypot(x - cx, z - cz) - r);
      const t = 1 - smoothstep(0, fall, d);
      if (t <= 0) return;
      this.h[k] = lerp(this.h[k], y, t);
      if (d === 0) this.mask[k] |= maskBit;
    });
  }

  // Lanes: carve each cell towards the nearest lane sample's height.
  applyPaths(lanes) {
    const N = this.h.length;
    const edge = new Float32Array(N).fill(1e9);
    const py = new Float32Array(N);
    for (const l of lanes) {
      const hw = l.w / 2;
      for (let i = 0; i < l.samples.length; i++) {
        const s = l.samples[i];
        if (s.bridge) continue;
        this.forCellsInRadius(s.x, s.z, hw + 2.4, (k, x, z) => {
          const e = Math.hypot(x - s.x, z - s.z) - hw;
          if (e < edge[k]) { edge[k] = e; py[k] = s.y; }
        });
      }
    }
    this.pathEdge = edge; // distance from the nearest lane edge (m), used for worn verges
    for (let k = 0; k < N; k++) {
      if (edge[k] > 2.4) continue;
      const t = 1 - smoothstep(0.15, 2.4, edge[k]);
      this.h[k] = lerp(this.h[k], py[k] - 0.02, t);
      if (edge[k] < 0.4) this.mask[k] |= 1;
    }
  }

  maskAt(x, z) {
    const [fi, fj] = this.idx(x, z);
    const i = Math.round(fi), j = Math.round(fj);
    if (i < this.innerStart || j < this.innerStart || i >= this.innerStart + this.innerCount || j >= this.innerStart + this.innerCount) return 0;
    return this.mask[j * this.n + i];
  }

  riverDist(x, z) {
    const [fi, fj] = this.idx(x, z);
    const i = clamp(Math.round(fi), 0, this.n - 1), j = clamp(Math.round(fj), 0, this.n - 1);
    return this.riverD[j * this.n + i];
  }

  sample(x, z) {
    const [fi, fj] = this.idx(x, z);
    const lo = this.innerStart, hi = this.innerStart + this.innerCount - 1;
    if (fi < lo || fj < lo || fi >= hi || fj >= hi) return baseHeight(x, z);
    const i = Math.floor(fi), j = Math.floor(fj);
    const tx = fi - i, tz = fj - j;
    const n = this.n, h = this.h;
    const a = h[j * n + i], b = h[j * n + i + 1], c = h[(j + 1) * n + i], d = h[(j + 1) * n + i + 1];
    // match the triangle split used by PlaneGeometry-style indexing (a,c,b / c,d,b)
    if (tx + tz <= 1) return a + (b - a) * tx + (c - a) * tz;
    return d + (c - d) * (1 - tx) + (b - d) * (1 - tz);
  }

  slope(x, z) {
    const e = 0.8;
    const dx = this.sample(x + e, z) - this.sample(x - e, z);
    const dz = this.sample(x, z + e) - this.sample(x, z - e);
    return Math.hypot(dx, dz) / (2 * e);
  }
}
