// The river: a flowing stylised water ribbon with rapids, cascades, foam rings around rocks
// and whitewater spray. All animation runs in shaders.
import * as THREE from 'three';
import { samples, waterLevel, halfWidth, rapidness, CASCADES } from './river.js';
import { softDot } from './textures.js';

const NOISE_GLSL = /* glsl */ `
float hash(vec2 p){ p = fract(p*vec2(123.34, 456.21)); p += dot(p, p+45.32); return fract(p.x*p.y); }
float vnoise(vec2 p){ vec2 i=floor(p), f=fract(p); vec2 u=f*f*(3.0-2.0*f);
  return mix(mix(hash(i),hash(i+vec2(1,0)),u.x), mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),u.x), u.y); }
float fbm(vec2 p){ float s=0.0, a=0.5; for(int i=0;i<4;i++){ s+=a*vnoise(p); p*=2.03; a*=0.5; } return s; }
`;

export function buildRiver(sun) {
  const ACROSS = 10;
  const pos = [], uv = [], rap = [], drop = [], idx = [];
  const rows = [];
  for (let i = 0; i < samples.length; i += 1) {
    const s = samples[i];
    if (s.z < -650 || s.z > 650) continue;
    rows.push(s);
  }
  rows.forEach((s, r) => {
    const hw = halfWidth(s.z) + 1.4;
    const y = waterLevel(s.z);
    const slope = Math.abs(waterLevel(s.z + 1.5) - waterLevel(s.z - 1.5)) / 3;
    for (let c = 0; c <= ACROSS; c++) {
      const u = c / ACROSS;
      const off = (u * 2 - 1) * hw;
      const nx = -s.tz, nz = s.tx;
      pos.push(s.x + nx * off, y, s.z + nz * off);
      uv.push(u, s.len);
      rap.push(rapidness(s.z));
      drop.push(Math.min(1, slope * 4));
    }
    if (r > 0) {
      const a = (r - 1) * (ACROSS + 1), b = r * (ACROSS + 1);
      for (let c = 0; c < ACROSS; c++) idx.push(a + c, a + c + 1, b + c, a + c + 1, b + c + 1, b + c);
    }
  });
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  geo.setAttribute('aRapid', new THREE.Float32BufferAttribute(rap, 1));
  geo.setAttribute('aDrop', new THREE.Float32BufferAttribute(drop, 1));
  geo.setIndex(idx);
  geo.computeVertexNormals();

  const mat = new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uSunDir: { value: sun.clone().normalize() },
      uDeep: { value: new THREE.Color('#85c0cf') },
      uShallow: { value: new THREE.Color('#c2e6e0') },
      uSky: { value: new THREE.Color('#e4eef8') },
      fogColor: { value: new THREE.Color() },
      fogNear: { value: 1 },
      fogFar: { value: 1000 },
    },
    vertexShader: /* glsl */ `
      attribute float aRapid; attribute float aDrop;
      varying vec2 vUv; varying float vRapid; varying float vDrop; varying vec3 vWorld; varying float vFogDepth;
      uniform float uTime;
      void main(){
        vUv = uv; vRapid = aRapid; vDrop = aDrop;
        vec3 p = position;
        float e = 1.0 - abs(uv.x*2.0-1.0);
        p.y += (sin(uv.y*0.9 - uTime*3.0 + uv.x*5.0)*0.03 + sin(uv.y*2.3 - uTime*4.7)*0.02) * (0.4 + aRapid*1.6) * e;
        vec4 w = modelMatrix * vec4(p,1.0);
        vWorld = w.xyz;
        vec4 mv = viewMatrix * w;
        vFogDepth = -mv.z;
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: /* glsl */ `
      uniform float uTime; uniform vec3 uSunDir, uDeep, uShallow, uSky, fogColor; uniform float fogNear, fogFar;
      varying vec2 vUv; varying float vRapid; varying float vDrop; varying vec3 vWorld; varying float vFogDepth;
      ${NOISE_GLSL}
      void main(){
        float across = vUv.x*2.0-1.0;
        float edge = abs(across);
        float speed = 1.0 + vRapid*2.4 + vDrop*6.0;
        float calm = 1.0 - smoothstep(0.3, 0.7, vRapid);
        // long flow-aligned coordinates (v is metres along the river)
        vec2 fp = vec2(vUv.x*5.0, vUv.y*0.09 - uTime*speed*0.16);
        float n1 = fbm(fp);
        float n2 = fbm(vec2(vUv.x*16.0 + 3.1, vUv.y*0.22 - uTime*speed*0.42));
        float n3 = fbm(vec2(vUv.x*7.0 - 1.7, vUv.y*0.55 - uTime*speed*0.9));
        // base colour: deeper in the middle
        vec3 col = mix(uDeep, uShallow, smoothstep(0.3, 0.98, edge + (n1-0.5)*0.35));
        col *= 0.94 + n3*0.12;
        // thin flow streaks everywhere, stronger in fast water
        float streak = smoothstep(0.66, 0.78, n2) * (0.22 + vRapid*0.45 + vDrop*0.8);
        // whitewater on rapids and cascades
        float white = smoothstep(0.5, 0.72, n3*0.7 + n2*0.5 - 0.12 + vRapid*0.22) * smoothstep(0.35, 0.8, vRapid) * 0.9;
        white = max(white, smoothstep(0.08, 0.45, vDrop) * smoothstep(0.2, 0.55, n2 + 0.15));
        // edge foam where water meets the banks
        float bank = smoothstep(0.8, 0.94, edge + (n2-0.5)*0.22) * (0.55 + vRapid*0.45);
        float foam = clamp(max(max(streak, white), bank), 0.0, 1.0);
        // lighting: fake normal from noise, sun glint and sky fresnel
        float dx = fbm(fp + vec2(0.05,0.0)) - n1; float dy = fbm(fp + vec2(0.0,0.05)) - n1;
        vec3 N = normalize(vec3(-dx*3.0, 1.0, -dy*3.0));
        vec3 V = normalize(cameraPosition - vWorld);
        float fres = pow(1.0 - max(dot(N, V), 0.0), 3.0);
        col = mix(col, uSky, fres*0.5);
        vec3 H = normalize(uSunDir + V);
        float spec = pow(max(dot(N, H), 0.0), 90.0);
        col += vec3(1.0, 0.95, 0.85) * spec * 0.8;
        col = mix(col, vec3(0.97, 0.99, 1.0), foam);
        float f = smoothstep(fogNear, fogFar, vFogDepth);
        col = mix(col, fogColor, f);
        gl_FragColor = vec4(col, 1.0);
        #include <colorspace_fragment>
      }`,
  });
  mat.uniforms.uDeep.value.convertSRGBToLinear();
  mat.uniforms.uShallow.value.convertSRGBToLinear();
  mat.uniforms.uSky.value.convertSRGBToLinear();
  const mesh = new THREE.Mesh(geo, mat);
  mesh.name = 'river';
  mesh.receiveShadow = false;
  return mesh;
}

// Flat foam rings that pulse around rocks sitting in the current.
export function buildFoamRings(rocks) {
  const tex = softDot();
  const geo = new THREE.RingGeometry(0.75, 1.35, 24, 1);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false,
    uniforms: { uTime: { value: 0 } },
    vertexShader: /* glsl */ `
      varying float vR; varying float vPhase; varying vec2 vUv;
      uniform float uTime;
      void main(){
        vec4 ip = instanceMatrix * vec4(0,0,0,1);
        vPhase = fract(ip.x*0.37 + ip.z*0.21);
        float s = 1.0 + 0.08*sin(uTime*3.0 + vPhase*6.28);
        vec3 p = position * vec3(s,1.0,s);
        vR = length(position.xz);
        vUv = uv;
        gl_Position = projectionMatrix * viewMatrix * modelMatrix * instanceMatrix * vec4(p,1.0);
      }`,
    fragmentShader: /* glsl */ `
      varying float vR; varying float vPhase; varying vec2 vUv; uniform float uTime;
      void main(){
        float a = smoothstep(0.75, 0.9, vR) * (1.0 - smoothstep(1.0, 1.35, vR));
        float br = 0.6 + 0.4*sin(atan(vUv.y-0.5, vUv.x-0.5)*7.0 + uTime*4.0 + vPhase*20.0);
        gl_FragColor = vec4(vec3(1.0), a*br*0.85);
      }`,
  });
  const inst = new THREE.InstancedMesh(geo, mat, rocks.length);
  const m = new THREE.Matrix4();
  rocks.forEach((r, i) => {
    m.makeScale(r.s * 1.2, 1, r.s * 1.2).setPosition(r.x, r.water + 0.04, r.z);
    inst.setMatrixAt(i, m);
  });
  inst.frustumCulled = false;
  inst.renderOrder = 2;
  return inst;
}

// Whitewater spray particles at the cascades and rapids (GPU animated, no CPU per frame).
export function buildSpray() {
  const pts = [], seeds = [];
  for (const c of CASCADES) {
    for (let i = 0; i < 260; i++) {
      const z = c.z1 + Math.random() * 6 - 1;
      const s = samples.reduce((b, p) => (Math.abs(p.z - z) < Math.abs(b.z - z) ? p : b));
      const hw = halfWidth(z);
      const off = (Math.random() * 2 - 1) * hw * 0.9;
      pts.push(s.x - s.tz * off, waterLevel(z), s.z + s.tx * off);
      seeds.push(Math.random());
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
  geo.setAttribute('aSeed', new THREE.Float32BufferAttribute(seeds, 1));
  const mat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false,
    uniforms: { uTime: { value: 0 }, uTex: { value: softDot() }, uScale: { value: 600 } },
    vertexShader: /* glsl */ `
      attribute float aSeed; uniform float uTime; uniform float uScale; varying float vA;
      void main(){
        float t = fract(uTime*0.55 + aSeed);
        vec3 p = position;
        p.y += sin(t*3.14159)*(0.9 + aSeed*1.2);
        p.z += t*1.6; p.x += (aSeed-0.5)*t*1.2;
        vA = sin(t*3.14159);
        vec4 mv = modelViewMatrix * vec4(p,1.0);
        gl_PointSize = uScale * (0.25 + aSeed*0.35) / -mv.z;
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: /* glsl */ `
      uniform sampler2D uTex; varying float vA;
      void main(){ vec4 t = texture2D(uTex, gl_PointCoord); gl_FragColor = vec4(1.0,1.0,1.0, t.a*vA*0.7); }`,
  });
  const p = new THREE.Points(geo, mat);
  p.frustumCulled = false;
  p.renderOrder = 3;
  return p;
}
