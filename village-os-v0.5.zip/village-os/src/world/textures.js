// Procedural canvas textures for paving, cobbles and trails, tuned to the soft pastel reference.
import * as THREE from 'three';
import { mulberry32 } from '../core/math.js';

function canvasTex(w, h, draw, repeat = true) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const g = c.getContext('2d');
  draw(g, w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  return t;
}

const shade = (hex, f) => {
  const c = new THREE.Color(hex);
  c.offsetHSL(0, 0, f);
  return '#' + c.getHexString();
};

// Square paving slabs, 4 across the width of the texture (u = across path, v = along).
export function slabTexture() {
  return canvasTex(256, 256, (g, w, h) => {
    const r = mulberry32(3);
    g.fillStyle = '#cfc6b8';
    g.fillRect(0, 0, w, h);
    const n = 3, s = w / n;
    for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
      g.fillStyle = shade('#ebe5d9', (r() - 0.5) * 0.05);
      g.beginPath();
      g.roundRect(i * s + 3, j * s + 3, s - 6, s - 6, 6);
      g.fill();
      g.fillStyle = 'rgba(255,255,255,0.18)';
      g.fillRect(i * s + 6, j * s + 6, s - 14, 4);
    }
  });
}

export function cobbleTexture() {
  return canvasTex(256, 256, (g, w, h) => {
    const r = mulberry32(5);
    g.fillStyle = '#c4b8a7';
    g.fillRect(0, 0, w, h);
    const rows = 9, rh = h / rows;
    for (let j = 0; j < rows; j++) {
      let x = j % 2 ? -rh * 0.5 : 0;
      while (x < w) {
        const cw = rh * (0.9 + r() * 0.5);
        g.fillStyle = shade('#e6ddcd', (r() - 0.5) * 0.09);
        g.beginPath();
        g.roundRect(x + 2, j * rh + 2, cw - 4, rh - 4, 7);
        g.fill();
        g.fillStyle = 'rgba(255,255,255,0.16)';
        g.beginPath();
        g.roundRect(x + 5, j * rh + 4, cw - 12, 4, 3);
        g.fill();
        // wrap horizontally for tiling
        if (x + cw > w) { g.fillStyle = shade('#d6cfc2', 0); g.beginPath(); g.roundRect(x + 2 - w, j * rh + 2, cw - 4, rh - 4, 7); g.fill(); }
        x += cw;
      }
    }
  });
}

export function trailTexture() {
  return canvasTex(256, 256, (g, w, h) => {
    const r = mulberry32(9);
    g.fillStyle = '#e2d2b2';
    g.fillRect(0, 0, w, h);
    for (let i = 0; i < 900; i++) {
      g.fillStyle = r() < 0.5 ? 'rgba(150,125,90,0.22)' : 'rgba(250,240,220,0.25)';
      const s = 1 + r() * 4;
      g.beginPath();
      g.arc(r() * w, r() * h, s, 0, Math.PI * 2);
      g.fill();
    }
    for (let i = 0; i < 40; i++) {
      g.fillStyle = shade('#bdb6a8', (r() - 0.5) * 0.1);
      g.beginPath();
      g.ellipse(r() * w, r() * h, 3 + r() * 5, 2 + r() * 4, r() * 3, 0, Math.PI * 2);
      g.fill();
    }
  });
}

export function plazaTexture() {
  // concentric cobble rings for the round square
  return canvasTex(1024, 1024, (g, w, h) => {
    const r = mulberry32(11);
    g.fillStyle = '#aaa294';
    g.fillRect(0, 0, w, h);
    const cx = w / 2, cy = h / 2;
    for (let ring = 0; ring < 22; ring++) {
      const rad0 = 40 + ring * 21, rad1 = rad0 + 19;
      const count = Math.floor((Math.PI * 2 * rad0) / 26);
      for (let k = 0; k < count; k++) {
        const a0 = (k / count) * Math.PI * 2 + ring * 0.13, a1 = ((k + 0.88) / count) * Math.PI * 2 + ring * 0.13;
        g.fillStyle = ring === 10 || ring === 21 ? shade('#e5c9b8', (r() - 0.5) * 0.06) : shade('#e8e0d2', (r() - 0.5) * 0.08);
        g.beginPath();
        g.arc(cx, cy, rad1, a0, a1);
        g.arc(cx, cy, rad0, a1, a0, true);
        g.closePath();
        g.fill();
      }
    }
    g.fillStyle = '#cfc8ba';
    g.beginPath(); g.arc(cx, cy, 38, 0, Math.PI * 2); g.fill();
  }, false);
}

// Soft round sprite for spray, splashes and smoke.
export function softDot() {
  return canvasTex(64, 64, (g, w) => {
    const grd = g.createRadialGradient(w / 2, w / 2, 0, w / 2, w / 2, w / 2);
    grd.addColorStop(0, 'rgba(255,255,255,1)');
    grd.addColorStop(0.45, 'rgba(255,255,255,0.75)');
    grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd;
    g.fillRect(0, 0, w, w);
  }, false);
}

// Soft stone masonry (world-unit UVs: 1 texture repeat = 2 m).
export function masonryTexture() {
  return canvasTex(256, 256, (g, w, h) => {
    const r = mulberry32(21);
    g.fillStyle = '#9d968b';
    g.fillRect(0, 0, w, h);
    const rows = 6, rh = h / rows;
    for (let j = 0; j < rows; j++) {
      let x = (j % 2) * -30;
      while (x < w) {
        const bw = 45 + r() * 40;
        g.fillStyle = shade('#c4bcae', (r() - 0.5) * 0.08);
        g.beginPath(); g.roundRect(x + 2, j * rh + 2, bw - 4, rh - 4, 8); g.fill();
        if (x + bw > w) { g.beginPath(); g.roundRect(x + 2 - w, j * rh + 2, bw - 4, rh - 4, 8); g.fill(); }
        x += bw;
      }
    }
  });
}
