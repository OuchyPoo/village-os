// Models taken from the four CC0 packs (Kenney Fantasy Town Kit 2.0, Quaternius Stylized Nature,
// Fantasy Props and Medieval Village MegaKits). Regraded to the pastel palette by tools/build-packs.mjs.
export const PACK_MODELS = [
  'k-watermill', 'k-windmill', 'k-cart', 'k-cart-high', 'k-stall-green', 'k-stall-red', 'k-stall-bench', 'k-stall-stool',
  'k-hedge', 'k-hedge-curved', 'k-hedge-gate', 'k-hedge-large', 'k-fence-gate', 'k-lantern', 'k-banner-green', 'k-banner-red',
  'k-rock-large', 'k-rock-wide', 'k-stairs-stone',
  'n-pebble-1', 'n-pebble-2', 'n-pebble-3', 'n-pebble-4', 'n-pebble-5', 'n-rockpath-1', 'n-rockpath-2', 'n-rockpath-3', 'n-rockpath-thin',
  'n-rock-1', 'n-rock-2', 'n-rock-3', 'n-mushroom', 'n-mushroom-shelf', 'n-flower-3', 'n-flower-4', 'n-plant-7', 'n-plant-1',
  'n-clover-1', 'n-clover-2', 'n-fern', 'n-bush-flowers', 'n-tree-1', 'n-tree-3',
  'p-barrel-apples', 'p-crate-apple', 'p-crate-carrot', 'p-bucket', 'p-stall-cart', 'p-vase-2', 'p-vase-4', 'p-bag',
  'v-vine-1', 'v-vine-2', 'v-vine-4', 'v-vine-5', 'v-wagon', 'v-metal-fence',
];
