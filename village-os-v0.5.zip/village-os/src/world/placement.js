// Shared placement checks so objects never intersect each other or float/bury on slopes.
// Footprints reads the live collider lists (circles, oriented boxes, fence/wall segments) through a
// spatial hash that catches up with anything pushed since the last query, so every placement pass in
// the world sees everything placed before it.
const CELL = 6;

export class Footprints {
  constructor(colliders) {
    this.c = colliders;
    this.grid = new Map();
    this.n = { circles: 0, obbs: 0, segs: 0 };
  }
  _ins(o, x, z, r) {
    const i0 = Math.floor((x - r) / CELL), i1 = Math.floor((x + r) / CELL), j0 = Math.floor((z - r) / CELL), j1 = Math.floor((z + r) / CELL);
    for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) { const k = i * 8192 + j; let l = this.grid.get(k); if (!l) this.grid.set(k, (l = [])); l.push(o); }
  }
  sync() {
    const { circles, obbs, segs } = this.c;
    for (; this.n.circles < circles.length; this.n.circles++) { const c = circles[this.n.circles]; this._ins({ t: 'c', o: c }, c.x, c.z, c.r); }
    for (; this.n.obbs < obbs.length; this.n.obbs++) { const b = obbs[this.n.obbs]; this._ins({ t: 'b', o: b, c: Math.cos(b.rot), s: Math.sin(b.rot) }, b.x, b.z, Math.hypot(b.hx, b.hz)); }
    for (; this.n.segs < segs.length; this.n.segs++) { const s = segs[this.n.segs]; this._ins({ t: 's', o: s }, (s.x0 + s.x1) / 2, (s.z0 + s.z1) / 2, Math.hypot(s.x1 - s.x0, s.z1 - s.z0) / 2 + s.r); }
  }
  // clearance of a disc (x, z, r) from every solid footprint: negative means they overlap
  clearance(x, z, r, { ignoreSegs = false, except = null } = {}) {
    this.sync();
    let best = Infinity;
    const i0 = Math.floor((x - r) / CELL), i1 = Math.floor((x + r) / CELL), j0 = Math.floor((z - r) / CELL), j1 = Math.floor((z + r) / CELL);
    const seen = new Set();
    for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) for (const e of this.grid.get(i * 8192 + j) || []) {
      if (seen.has(e)) continue; seen.add(e);
      const o = e.o;
      if (except && (o === except || o.house === except)) continue;
      let d;
      if (e.t === 'c') d = Math.hypot(x - o.x, z - o.z) - o.r;
      else if (e.t === 'b') {
        const dx = x - o.x, dz = z - o.z, lx = dx * e.c - dz * e.s, lz = dx * e.s + dz * e.c;
        const qx = Math.max(-o.hx, Math.min(o.hx, lx)), qz = Math.max(-o.hz, Math.min(o.hz, lz));
        d = Math.hypot(lx - qx, lz - qz) - (Math.abs(lx) <= o.hx && Math.abs(lz) <= o.hz ? Math.min(o.hx - Math.abs(lx), o.hz - Math.abs(lz)) : 0);
      } else {
        if (ignoreSegs) continue;
        const vx = o.x1 - o.x0, vz = o.z1 - o.z0, t = Math.max(0, Math.min(1, ((x - o.x0) * vx + (z - o.z0) * vz) / (vx * vx + vz * vz || 1)));
        d = Math.hypot(x - (o.x0 + vx * t), z - (o.z0 + vz * t)) - o.r;
      }
      best = Math.min(best, d - r);
    }
    return best;
  }
  fits(x, z, r, opts) { return this.clearance(x, z, r, opts) > -0.04; }
}

// Ground height for something standing on legs or a base over a rectangular footprint: the lowest
// corner, so nothing floats; `tilt` is the height spread across the footprint (reject if too steep).
export function footprintGround(hf, x, z, rot, hx, hz) {
  const c = Math.cos(rot), s = Math.sin(rot);
  let lo = Infinity, hi = -Infinity;
  for (const [u, v] of [[-hx, -hz], [hx, -hz], [-hx, hz], [hx, hz], [0, 0]]) {
    const y = hf.sample(x + u * c + v * s, z - u * s + v * c);
    lo = Math.min(lo, y); hi = Math.max(hi, y);
  }
  return { y: lo, tilt: hi - lo };
}
