// Third-person movement: camera-relative WASD, sprint, jump with gravity, terrain following,
// collision push-out and slope limits. Also handles sitting on benches.
import * as THREE from 'three';
import { dampAngle } from '../core/math.js';

const WALK = 4.2, SPRINT = 7.6, ACCEL = 11, GRAVITY = 24, JUMP = 7.4, RADIUS = 0.42, MAX_SLOPE = 1.05;

export class PlayerController {
  constructor(character, collision, input) {
    this.char = character;
    this.col = collision;
    this.input = input;
    this.pos = new THREE.Vector3();
    this.vel = new THREE.Vector3();
    this.facing = 0;
    this.grounded = true;
    this.sitting = null;
    this.locked = false; // UI open
    this.coyote = 0;
  }

  teleport(x, z, facing = this.facing) {
    this.pos.set(x, this.col.ground(x, z), z);
    this.vel.set(0, 0, 0);
    this.facing = facing;
    this.sync();
  }

  sit(seat) {
    this.sitting = seat;
    this.pos.set(seat.x, seat.y, seat.z);
    this.facing = seat.rot;
    this.vel.set(0, 0, 0);
  }

  stand() {
    if (!this.sitting) return;
    const s = this.sitting;
    this.sitting = null;
    const [x, z] = this.col.resolve(s.x + Math.sin(s.rot) * 1.0, s.z + Math.cos(s.rot) * 1.0, RADIUS);
    this.pos.set(x, this.col.ground(x, z), z);
  }

  update(dt, camYaw) {
    const inp = this.input;
    let mx = 0, mz = 0;
    if (!this.locked) {
      if (inp.down('KeyW') || inp.down('ArrowUp')) mz += 1;
      if (inp.down('KeyS') || inp.down('ArrowDown')) mz -= 1;
      if (inp.down('KeyD') || inp.down('ArrowRight')) mx += 1;
      if (inp.down('KeyA') || inp.down('ArrowLeft')) mx -= 1;
    }
    if (this.sitting) {
      if (mx || mz || inp.consume('Space')) this.stand();
      else { this.sync(); this.char.update(dt, { sitting: true }); return; }
    }
    const fx = -Math.sin(camYaw), fz = -Math.cos(camYaw);
    const rx = Math.cos(camYaw), rz = -Math.sin(camYaw);
    let dx = fx * mz + rx * mx, dz = fz * mz + rz * mx;
    const dl = Math.hypot(dx, dz);
    const sprint = inp.down('ShiftLeft') || inp.down('ShiftRight');
    const target = dl > 0 ? (sprint ? SPRINT : WALK) : 0;
    if (dl > 0) { dx /= dl; dz /= dl; }
    const k = 1 - Math.exp(-ACCEL * dt * (this.grounded ? 1 : 0.35));
    this.vel.x += (dx * target - this.vel.x) * k;
    this.vel.z += (dz * target - this.vel.z) * k;

    // jump & gravity
    this.coyote = this.grounded ? 0.12 : Math.max(0, this.coyote - dt);
    if (!this.locked && inp.consume('Space') && this.coyote > 0) { this.vel.y = JUMP; this.grounded = false; this.coyote = 0; }
    this.vel.y -= GRAVITY * dt;

    // horizontal move with slope limit
    const ox = this.pos.x, oz = this.pos.z;
    let nx = ox + this.vel.x * dt, nz = oz + this.vel.z * dt;
    const g0 = this.col.ground(ox, oz);
    const tryStep = (x, z) => {
      const g = this.col.ground(x, z);
      const run = Math.hypot(x - ox, z - oz) || 1e-6;
      const onSurface = this.col.surfaceAt(x, z) !== null;
      return onSurface || (g - g0) / run < MAX_SLOPE || g <= this.pos.y + 0.05;
    };
    if (!tryStep(nx, nz)) {
      if (tryStep(nx, oz)) nz = oz; else if (tryStep(ox, nz)) nx = ox; else { nx = ox; nz = oz; }
    }
    [nx, nz] = this.col.resolve(nx, nz, RADIUS, this.pos.y);
    // vertical
    let ny = this.pos.y + this.vel.y * dt;
    const g = this.col.ground(nx, nz);
    if (ny <= g) { ny = g; this.vel.y = 0; this.grounded = true; }
    else if (this.grounded && this.vel.y <= 0 && ny - g < 0.45) { ny = g; this.vel.y = 0; } // stick to ground going downhill
    else this.grounded = false;
    // effective velocity after collisions
    if (dt > 0) { this.vel.x = (nx - ox) / dt * 0.5 + this.vel.x * 0.5; this.vel.z = (nz - oz) / dt * 0.5 + this.vel.z * 0.5; }
    this.pos.set(nx, ny, nz);

    const speed = Math.hypot(nx - ox, nz - oz) / Math.max(dt, 1e-4);
    if (dl > 0) this.facing = dampAngle(this.facing, Math.atan2(dx, dz), 1 - Math.exp(-12 * dt));
    this.sync();
    this.char.update(dt, { grounded: this.grounded, speed });
  }

  sync() {
    const r = this.char.root;
    r.position.copy(this.pos);
    if (this.sitting) r.position.y += 0.18;
    r.rotation.y = this.facing;
    const b = this.char.blob;
    const g = this.col.ground(this.pos.x, this.pos.z);
    b.position.set(this.pos.x, g + 0.06, this.pos.z);
    const h = Math.max(0, this.pos.y - g);
    b.scale.setScalar(1 / (1 + h * 0.4));
    b.material.opacity = 0.18 / (1 + h * 0.6);
  }
}
