// Orbit follow camera: right-drag to rotate, wheel to zoom, smooth follow, and
// collision so it never clips through houses or terrain.
import * as THREE from 'three';
import { clamp } from '../core/math.js';

export class FollowCamera {
  constructor(camera, collision, input) {
    this.cam = camera;
    this.col = collision;
    this.input = input;
    this.yaw = -1.0;
    this.pitch = 0.5;
    this.dist = 13;
    this.targetDist = 13;
    this.curDist = 13;
    this.focus = new THREE.Vector3();
    this.inited = false;
    this.sens = 0.0034;
    this._a = new THREE.Vector3(); this._b = new THREE.Vector3();
  }

  update(dt, playerPos, lockLook = false) {
    const inp = this.input;
    if (!lockLook) {
      this.yaw -= inp.dx * this.sens;
      this.pitch = clamp(this.pitch + inp.dy * this.sens, 0.05, 1.32);
      this.targetDist = clamp(this.targetDist * (1 + inp.wheel * 0.12), 3.2, 30);
    }
    this.dist += (this.targetDist - this.dist) * (1 - Math.exp(-10 * dt));
    const goal = this._a.set(playerPos.x, playerPos.y + 1.45, playerPos.z);
    if (!this.inited) { this.focus.copy(goal); this.inited = true; }
    this.focus.lerp(goal, 1 - Math.exp(-14 * dt));
    const cp = Math.cos(this.pitch);
    const want = this._b.set(
      this.focus.x + Math.sin(this.yaw) * cp * this.dist,
      this.focus.y + Math.sin(this.pitch) * this.dist,
      this.focus.z + Math.cos(this.yaw) * cp * this.dist,
    );
    // collision: pull in fast, ease back out slowly
    const hit = this.col.raycast(this.focus, want, 0.35);
    const allowed = Math.max(0.5, Math.min(this.dist, hit - 0.2));
    const k = allowed < this.curDist ? 1 - Math.exp(-30 * dt) : 1 - Math.exp(-3 * dt);
    this.curDist += (allowed - this.curDist) * k;
    const t = this.curDist / this.dist;
    this.cam.position.copy(this.focus).lerp(want, t);
    // keep the lens above ground
    const g = this.col.ground(this.cam.position.x, this.cam.position.z) + 0.4;
    if (this.cam.position.y < g) this.cam.position.y = g;
    this.cam.lookAt(this.focus);
  }
}
