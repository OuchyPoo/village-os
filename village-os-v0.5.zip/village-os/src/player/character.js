// The explorer: Kenney's CC0 platformer character with idle / walk / jump clips.
import * as THREE from 'three';

export class Character {
  constructor(gltf) {
    this.root = new THREE.Group();
    this.root.name = 'player';
    const model = gltf.scene;
    model.scale.setScalar(1.3);
    model.traverse((o) => {
      if (o.isMesh) {
        o.castShadow = true;
        o.receiveShadow = true;
        o.material = o.material.clone();
        o.material.roughness = 0.7;
      }
    });
    this.model = model;
    this.root.add(model);
    this.mixer = new THREE.AnimationMixer(model);
    this.actions = {};
    for (const clip of gltf.animations) this.actions[clip.name] = this.mixer.clipAction(clip);
    if (this.actions.jump) { this.actions.jump.setLoop(THREE.LoopOnce, 1); this.actions.jump.clampWhenFinished = true; }
    this.current = null;
    this.play('idle', 0);
    // soft blob shadow helps read height while jumping
    const blob = new THREE.Mesh(
      new THREE.CircleGeometry(0.55, 24).rotateX(-Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: '#2d3a2a', transparent: true, opacity: 0.18, depthWrite: false }),
    );
    blob.renderOrder = 1;
    this.blob = blob;
  }

  play(name, fade = 0.18) {
    const next = this.actions[name];
    if (!next || this.current === next) return;
    next.reset().setEffectiveWeight(1).fadeIn(fade).play();
    if (this.current) this.current.fadeOut(fade);
    this.current = next;
  }

  update(dt, state) {
    if (state.sitting) { this.play('idle'); this.actions.idle && (this.actions.idle.timeScale = 0.6); }
    else if (!state.grounded) this.play('jump', 0.1);
    else if (state.speed > 0.4) {
      this.play('walk');
      this.actions.walk.timeScale = THREE.MathUtils.clamp(state.speed / 3.6, 0.7, 2.1);
    } else { this.play('idle'); this.actions.idle && (this.actions.idle.timeScale = 1); }
    this.mixer.update(dt);
  }
}
