// Minimal DOM overlay: contextual "E" prompt, domain panel, toast and a fading controls hint.
const $ = (html) => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstChild; };

export class HUD {
  constructor() {
    this.prompt = $(`<div class="prompt" aria-live="polite"><kbd>E</kbd><span></span></div>`);
    this.panel = $(`<div class="panel" role="dialog" aria-modal="true" hidden>
      <div class="card"><p class="kind"></p><h2></h2><p class="blurb"></p><div class="sections"></div>
      <div class="actions"><button class="close" type="button">Close <kbd>Esc</kbd></button></div></div></div>`);
    this.toastEl = $(`<div class="toast" hidden></div>`);
    this.hint = $(`<div class="hint">
      <div><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> Move</div>
      <div><kbd>Right mouse</kbd> Look</div><div><kbd>Wheel</kbd> Zoom</div>
      <div><kbd>Shift</kbd> Sprint</div><div><kbd>Space</kbd> Jump</div><div><kbd>E</kbd> Interact</div></div>`);
    document.body.append(this.prompt, this.panel, this.toastEl, this.hint);
    this.onClose = null;
    this.panel.querySelector('.close').addEventListener('click', () => this.closePanel());
    this.panel.addEventListener('mousedown', (e) => { if (e.target === this.panel) this.closePanel(); });
    setTimeout(() => this.hint.classList.add('fade'), 14000);
  }

  showPrompt(label, x, y) {
    this.prompt.querySelector('span').textContent = label;
    this.prompt.style.transform = `translate(${Math.round(x)}px, ${Math.round(y)}px) translate(-50%, -100%)`;
    this.prompt.classList.add('on');
  }
  hidePrompt() { this.prompt.classList.remove('on'); }

  get panelOpen() { return !this.panel.hidden; }
  openPanel({ kind = '', title = '', blurb = '', sections = [], html = '' }, onClose) {
    const c = this.panel.querySelector('.card');
    c.querySelector('.kind').textContent = kind;
    c.querySelector('h2').textContent = title;
    c.querySelector('.blurb').textContent = blurb;
    const s = c.querySelector('.sections');
    s.innerHTML = html;
    for (const sec of sections) {
      const el = $(`<section><h3></h3><ul></ul></section>`);
      el.querySelector('h3').textContent = sec.label;
      for (const it of sec.items) { const li = document.createElement('li'); li.textContent = it; el.querySelector('ul').append(li); }
      s.append(el);
    }
    this.panel.hidden = false;
    requestAnimationFrame(() => this.panel.classList.add('open'));
    this.onClose = onClose;
    this.panel.querySelector('.close').focus({ preventScroll: true });
  }
  closePanel() {
    if (this.panel.hidden) return;
    this.panel.classList.remove('open');
    this.panel.hidden = true;
    const cb = this.onClose; this.onClose = null;
    cb && cb();
    document.activeElement?.blur?.();
  }

  toast(text, ms = 2600) {
    this.toastEl.textContent = text;
    this.toastEl.hidden = false;
    this.toastEl.classList.add('on');
    clearTimeout(this._t);
    this._t = setTimeout(() => { this.toastEl.classList.remove('on'); setTimeout(() => (this.toastEl.hidden = true), 300); }, ms);
  }
}
