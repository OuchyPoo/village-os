// Keyboard + mouse state. Right mouse drag (with pointer lock when available) orbits the camera.
export class Input {
  constructor(dom) {
    this.dom = dom;
    this.keys = new Set();
    this.pressed = new Set();
    this.dx = 0; this.dy = 0; this.wheel = 0;
    this.rmb = false;
    this.enabled = true;
    addEventListener('keydown', (e) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      const k = e.code;
      if (!this.keys.has(k)) this.pressed.add(k);
      this.keys.add(k);
      if (['Space', 'ArrowUp', 'ArrowDown', 'Tab'].includes(k)) e.preventDefault();
    });
    addEventListener('keyup', (e) => this.keys.delete(e.code));
    addEventListener('blur', () => { this.keys.clear(); this.rmb = false; });
    dom.addEventListener('contextmenu', (e) => e.preventDefault());
    dom.addEventListener('mousedown', (e) => {
      if (e.button === 2) {
        this.rmb = true;
        try { const p = dom.requestPointerLock?.(); if (p && p.catch) p.catch(() => {}); } catch (_) { /* optional */ }
      }
    });
    addEventListener('mouseup', (e) => {
      if (e.button === 2) {
        this.rmb = false;
        if (document.pointerLockElement === dom) document.exitPointerLock();
      }
    });
    addEventListener('mousemove', (e) => {
      if (this.rmb || document.pointerLockElement === dom) { this.dx += e.movementX; this.dy += e.movementY; }
    });
    dom.addEventListener('wheel', (e) => { this.wheel += Math.sign(e.deltaY) * Math.min(3, Math.abs(e.deltaY) / 100 + 0.5); e.preventDefault(); }, { passive: false });
  }
  down(code) { return this.enabled && this.keys.has(code); }
  consume(code) { const had = this.pressed.has(code); this.pressed.delete(code); return had; }
  releaseMouse() { this.rmb = false; if (document.pointerLockElement) document.exitPointerLock(); }
  endFrame() { this.dx = 0; this.dy = 0; this.wheel = 0; this.pressed.clear(); }
}
