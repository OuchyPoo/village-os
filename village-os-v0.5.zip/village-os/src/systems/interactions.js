// Finds the nearest interactable, shows a contextual prompt, and runs its action on E.
import * as THREE from 'three';

export class Interactions {
  constructor({ world, player, hud, camera, input, scene }) {
    Object.assign(this, { world, player, hud, camera, input, scene });
    this.list = world.interactables;
    this.active = null;
    this.coins = 0;
    this.openDoor = null;
    this.tweens = [];
    this._v = new THREE.Vector3();
  }

  nearest() {
    const p = this.player.pos;
    let best = null, bd = Infinity;
    for (const it of this.list) {
      const d = Math.hypot(it.x - p.x, it.z - p.z);
      if (d < it.r && d < bd && Math.abs((it.y ?? p.y) - p.y) < 2.5) { best = it; bd = d; }
    }
    return best;
  }

  update(dt, t) {
    const { hud, input, player } = this;
    // tweens (door swings, coin arcs)
    this.tweens = this.tweens.filter((tw) => { tw.t = Math.min(1, tw.t + dt / tw.dur); tw.fn(tw.t); return tw.t < 1; });

    if (input.consume('Escape')) {
      if (hud.panelOpen) hud.closePanel();
      else if (player.sitting) player.stand();
      input.releaseMouse();
    }
    if (hud.panelOpen) { hud.hidePrompt(); if (input.consume('KeyE')) hud.closePanel(); return; }

    if (player.sitting) {
      this.prompt('Stand up', player.pos.x, player.pos.y + 2.1, player.pos.z);
      if (input.consume('KeyE')) player.stand();
      return;
    }
    const it = this.nearest();
    this.active = it;
    if (!it) { hud.hidePrompt(); return; }
    this.prompt(it.label, it.x, (it.y ?? player.pos.y) + 2.3, it.z);
    if (input.consume('KeyE')) this.run(it);
  }

  prompt(label, x, y, z) {
    const v = this._v.set(x, y, z).project(this.camera);
    if (v.z > 1) { this.hud.hidePrompt(); return; }
    this.hud.showPrompt(label, (v.x * 0.5 + 0.5) * innerWidth, (-v.y * 0.5 + 0.5) * innerHeight);
  }

  swing(door, to, dur = 0.45) {
    const from = door.rotation.y;
    this.tweens.push({ t: 0, dur, fn: (k) => { const e = 1 - Math.pow(1 - k, 3); door.rotation.y = from + (to - from) * e; } });
  }

  run(it) {
    const { hud, player } = this;
    if (it.kind === 'door') {
      const door = it.house.doorObj;
      this.swing(door, -1.35);
      player.locked = true;
      // face the door
      player.facing = Math.atan2(it.house.door.world[0] - player.pos.x, it.house.door.world[1] - player.pos.z);
      hud.openPanel(it.info, () => { this.swing(door, 0, 0.6); player.locked = false; });
    } else if (it.kind === 'noticeboard') {
      player.locked = true;
      hud.openPanel({
        kind: 'Village noticeboard', title: 'Welcome to Village OS',
        blurb: 'Each building is a part of life. Walk up to a door and press E to look inside. Signs mark the houses that already hold a domain; the empty cottages are waiting for new ones.',
        sections: [
          { label: 'Getting around', items: ['WASD to walk, Shift to sprint, Space to jump', 'Hold right mouse to look around, wheel to zoom', 'E to interact, Esc to close or release the mouse'] },
          { label: 'Around the village', items: ['The square: town hall, workshop and records office', 'Across the main bridge: your cottage and the apothecary', 'Up the river path: the guesthouse and the falls', 'Follow the forest trail east to the Village OS workshop'] },
        ],
      }, () => { player.locked = false; });
    } else if (it.kind === 'fountain') {
      this.coins++;
      this.tossCoin(it.target);
      hud.toast(this.coins === 1 ? 'A coin for good luck. Make a wish.' : `${this.coins} coins in the fountain`);
    } else if (it.kind === 'toast') {
      hud.toast(it.message);
    } else if (it.kind === 'bench') {
      player.sit(it.seat);
    }
  }

  tossCoin(target) {
    const coin = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.02, 16), new THREE.MeshStandardMaterial({ color: '#e7c35a', metalness: 0.8, roughness: 0.3 }));
    const a = this.player.pos.clone().add(new THREE.Vector3(0, 1.3, 0));
    const b = target.clone().add(new THREE.Vector3((Math.random() - 0.5) * 1.5, 0, (Math.random() - 0.5) * 1.5));
    this.scene.add(coin);
    this.tweens.push({
      t: 0, dur: 0.9, fn: (k) => {
        coin.position.lerpVectors(a, b, k);
        coin.position.y += Math.sin(k * Math.PI) * 2.2;
        coin.rotation.x = k * 20;
        if (k >= 1) { this.scene.remove(coin); coin.geometry.dispose(); }
      },
    });
  }
}
