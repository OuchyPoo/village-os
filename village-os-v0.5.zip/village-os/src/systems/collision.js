// Ground height (terrain + bridge decks), solid-object push-out (circles, oriented boxes,
// capsules), river blocking, steep-slope blocking and camera ray tests.
import { riverQuery, halfWidth } from '../world/river.js';

const CELL = 8;

export class Collision {
  constructor(world) {
    this.hf = world.hf;
    this.surfaces = world.surfaces;
    this.grid = new Map();
    const { circles, obbs, segs } = world.colliders;
    for (const c of circles) this.insert({ type: 'c', ...c }, c.x, c.z, c.r);
    for (const b of obbs) this.insert({ type: 'b', ...b, c: Math.cos(b.rot), s: Math.sin(b.rot) }, b.x, b.z, Math.hypot(b.hx, b.hz));
    for (const s of segs) this.insert({ type: 's', ...s }, (s.x0 + s.x1) / 2, (s.z0 + s.z1) / 2, Math.hypot(s.x1 - s.x0, s.z1 - s.z0) / 2 + s.r);
    this.obbs = obbs.map((b) => ({ ...b, c: Math.cos(b.rot), s: Math.sin(b.rot) }));
    this.q = {};
    this.boundary = 192;
  }

  insert(o, x, z, r) {
    const i0 = Math.floor((x - r) / CELL), i1 = Math.floor((x + r) / CELL);
    const j0 = Math.floor((z - r) / CELL), j1 = Math.floor((z + r) / CELL);
    for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) {
      const k = i * 4096 + j;
      if (!this.grid.has(k)) this.grid.set(k, []);
      this.grid.get(k).push(o);
    }
  }

  nearby(x, z) {
    const out = new Set();
    const i = Math.floor(x / CELL), j = Math.floor(z / CELL);
    for (let a = i - 1; a <= i + 1; a++) for (let b = j - 1; b <= j + 1; b++) {
      const l = this.grid.get(a * 4096 + b);
      if (l) for (const o of l) out.add(o);
    }
    return out;
  }

  surfaceAt(x, z) {
    let best = null;
    for (const s of this.surfaces) { const y = s.test(x, z); if (y !== null && (best === null || y > best)) best = y; }
    return best;
  }

  ground(x, z) {
    const t = this.hf.sample(x, z);
    const s = this.surfaceAt(x, z);
    return s !== null ? Math.max(s, t) : t;
  }

  // Push a circle (player) out of solids; returns corrected [x, z].
  resolve(x, z, r, y) {
    for (let iter = 0; iter < 3; iter++) {
      for (const o of this.nearby(x, z)) {
        if (o.type === 'c') {
          const dx = x - o.x, dz = z - o.z, d = Math.hypot(dx, dz), m = o.r + r;
          if (d < m && d > 1e-5) { x = o.x + (dx / d) * m; z = o.z + (dz / d) * m; }
        } else if (o.type === 'b') {
          if (y !== undefined && (y > o.y1 || y + 1.6 < o.y0)) continue;
          const dx = x - o.x, dz = z - o.z;
          const lx = dx * o.c - dz * o.s, lz = dx * o.s + dz * o.c;
          const cx = Math.max(-o.hx, Math.min(o.hx, lx)), cz = Math.max(-o.hz, Math.min(o.hz, lz));
          let px = lx - cx, pz = lz - cz;
          let d = Math.hypot(px, pz);
          let nlx, nlz;
          if (d < 1e-5) {
            // centre inside the box: push out along the shallowest axis
            const ex = o.hx - Math.abs(lx), ez = o.hz - Math.abs(lz);
            if (ex < ez) { nlx = Math.sign(lx) * (o.hx + r); nlz = lz; } else { nlx = lx; nlz = Math.sign(lz) * (o.hz + r); }
          } else if (d < r) {
            nlx = cx + (px / d) * r; nlz = cz + (pz / d) * r;
          } else continue;
          x = o.x + nlx * o.c + nlz * o.s;
          z = o.z - nlx * o.s + nlz * o.c;
        } else {
          const vx = o.x1 - o.x0, vz = o.z1 - o.z0;
          const t = Math.max(0, Math.min(1, ((x - o.x0) * vx + (z - o.z0) * vz) / (vx * vx + vz * vz)));
          const qx = o.x0 + vx * t, qz = o.z0 + vz * t;
          const dx = x - qx, dz = z - qz, d = Math.hypot(dx, dz), m = o.r + r;
          if (d < m && d > 1e-5) { x = qx + (dx / d) * m; z = qz + (dz / d) * m; }
        }
      }
      // river: water is not walkable except over a bridge
      if (this.surfaceAt(x, z) === null) {
        const q = riverQuery(x, z, this.q);
        const lim = halfWidth(q.z) + 0.35;
        if (q.d < lim) {
          const d = q.d || 1e-3;
          x = q.x + ((x - q.x) / d) * lim; z = q.z + ((z - q.z) / d) * lim;
        }
      }
      const R = Math.hypot(x, z);
      if (R > this.boundary) { x *= this.boundary / R; z *= this.boundary / R; }
    }
    return [x, z];
  }

  // Ray march from a to b (THREE.Vector3s); returns hit distance or Infinity.
  raycast(a, b, pad = 0.3) {
    const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
    const len = Math.hypot(dx, dy, dz);
    let best = Infinity;
    // oriented boxes (houses) via slab test in local space
    for (const o of this.obbs) {
      if (Math.hypot(o.x - a.x, o.z - a.z) > len + Math.hypot(o.hx, o.hz) + 1) continue;
      const ox = a.x - o.x, oz = a.z - o.z;
      const lox = ox * o.c - oz * o.s, loz = ox * o.s + oz * o.c;
      const ldx = dx * o.c - dz * o.s, ldz = dx * o.s + dz * o.c;
      let t0 = 0, t1 = 1;
      const slab = (p, d, mn, mx) => {
        if (Math.abs(d) < 1e-8) return p >= mn && p <= mx;
        let ta = (mn - p) / d, tb = (mx - p) / d;
        if (ta > tb) [ta, tb] = [tb, ta];
        t0 = Math.max(t0, ta); t1 = Math.min(t1, tb);
        return t0 <= t1;
      };
      if (slab(lox, ldx, -o.hx - pad, o.hx + pad) && slab(a.y, dy, o.y0, o.y1 + pad) && slab(loz, ldz, -o.hz - pad, o.hz + pad)) {
        best = Math.min(best, t0 * len);
      }
    }
    // terrain
    const steps = Math.ceil(len / 0.4);
    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      const x = a.x + dx * t, y = a.y + dy * t, z = a.z + dz * t;
      if (y < this.ground(x, z) + pad) { best = Math.min(best, t * len); break; }
    }
    return best;
  }
}
