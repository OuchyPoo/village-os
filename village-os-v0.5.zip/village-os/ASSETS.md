# Asset register

Every third-party asset shipped with Village OS. All are CC0 (public domain dedication): free for
personal and commercial use, no attribution required. Kenney is credited anyway.

| Runtime file | Used for | Source (exact file) | Creator | Licence | Local source copy |
|---|---|---|---|---|---|
| `public/assets/models/character.glb` | Player character (idle, walk, jump clips) | [KenneyNL/Starter-Kit-3D-Platformer](https://github.com/KenneyNL/Starter-Kit-3D-Platformer) `models/character.glb` @ `3fa8a04` | Kenney (kenney.nl) | CC0 1.0 (models), repo code MIT | `assets-src/kenney/platformer/character.glb` |
| `public/assets/models/grass.glb` | Lawn and riverbank grass tufts (recoloured) | same repo, `models/grass.glb` | Kenney | CC0 1.0 | `assets-src/kenney/platformer/grass.glb` |
| `public/assets/models/grass-small.glb` | Small grass tufts (recoloured) | same repo, `models/grass-small.glb` | Kenney | CC0 1.0 | `assets-src/kenney/platformer/grass-small.glb` |
| `public/assets/models/pine.glb` | Conifers in the forests and on the mountains (normals smoothed, palette warmed) | [KenneyNL/Starter-Kit-Basic-Scene](https://github.com/KenneyNL/Starter-Kit-Basic-Scene) `sample/Mini Arena/Models/GLB format/tree.glb` @ `a6927e6` (Mini Arena pack, credit: Kenney, Tony Schär) | Kenney | CC0 1.0 (see `assets-src/kenney/mini-arena/License.txt`) | `assets-src/kenney/mini-arena/tree.glb` |
| `public/assets/models/fountain.glb` | Fountain on the village square (paving tile stripped at load, recoloured) | [KenneyNL/Starter-Kit-City-Builder](https://github.com/KenneyNL/Starter-Kit-City-Builder) `models/pavement-fountain.glb` @ `4535092` | Kenney | CC0 1.0 | `assets-src/kenney/city/pavement-fountain.glb` |

Each source GLB references `Textures/colormap.png`; `npm run assets` (tools/build-assets.mjs) embeds the
texture and runs gltf-transform dedup / weld / prune so every runtime model is one small self-contained GLB.

## Downloaded packs (CC0), curated and regraded

57 models from four packs supplied as downloads, processed by `tools/build-packs.mjs` into
`public/assets/models/packs/` (regraded to pastel, normal/ORM maps removed, textures downsized).
Full review and the list of picks: `docs/asset-packs.md`; per-model catalogue: `docs/asset-catalogue.csv`.

| Pack | Creator | Licence | Files used |
|---|---|---|---|
| Fantasy Town Kit 2.0 | Kenney (kenney.nl) | CC0 1.0 | `k-*.glb` (19) |
| Stylized Nature MegaKit, Standard | Quaternius (quaternius.com) | CC0 1.0 | `n-*.glb` (24) |
| Fantasy Props MegaKit, Standard | Quaternius | CC0 1.0 | `p-*.glb` (8) |
| Medieval Village MegaKit, Standard | Quaternius | CC0 1.0 | `v-*.glb` (6) |

Rebuild after changing the picks: unzip the packs into one folder, then `npm run packs -- <folder>`.

## Textures (v0.4)

| Texture | Source | Creator | Licence | Used for |
|---|---|---|---|---|
| `T_UnevenBrick_BaseColor` | Medieval Village MegaKit, Standard (supplied download) | Quaternius | CC0 1.0 | rubble stone: house plinths, garden walls, gate piers, chimneys |
| `T_Plaster_BaseColor` | Medieval Village MegaKit, Standard (supplied download) | Quaternius | CC0 1.0 | lime plaster walls |

Both are hand painted, so they suit the handcrafted cottagecore look. `tools/build-textures.py` downsizes
them to 512 px, regrades them into light, low contrast multiply maps (so the pastel material colours stay
in charge) and embeds them in `src/world/textures-data.js`. Append `?tex=canvas` to the URL to compare
against the earlier procedural canvas textures. Timber, dressed stone and roof tiles keep the procedural
canvas textures: the painted alternatives (`T_WoodTrim`, `T_RoundTiles`) were too saturated or too busy
at village scale and did not clearly improve on them.

Reviewed but not used: hand painted stone and wall sets on OpenGameArt
([8 handpainted style textures 2](https://opengameart.org/content/8-handpainted-style-textures-2),
[handpainted stone texture](https://opengameart.org/content/handpainted-stone-texture),
[handpainted stone tile textures](https://opengameart.org/content/handpainted-stone-tile-textures),
[wall texture 1](https://opengameart.org/content/wall-texture-1)). Licences vary per upload on
OpenGameArt (CC0, CC BY, CC BY-SA, GPL), so each would need its page checked and attribution recorded;
the CC0 Quaternius set already in the project matched the style better, so none were imported.

## Garden plants, trees and insects (v0.5)

All built in code (`src/world/plants.js`, `src/world/vegetation.js`, `src/world/assets.js`,
`src/world/insects.js`); no third party files, so no licence obligations.

- Garden plants are made of folded leaf cards and real flower shapes: mophead hydrangeas of small
  four petal florets, cupped roses, layered peonies, lavender and salvia spikes on slender stems,
  daisies, cosmos and alliums. They replace the earlier ball cluster plants.
- Trees grow from a branching skeleton (bent trunk, limbs at varied heights, secondary limbs) with
  irregular leaf clumps at the limb ends: maple, ash, apple, oak, linden, poplar, birch, cherry and
  orchard trees. Firs have jagged, drooping branch skirts. The willow has arching limbs and long
  tapered streamers that fall from the crown.
- Butterflies have rounded fore and hind wings and bodies; dragonflies over the calm river margins have
  four glassy wings, hover and dart.

Sourcing note: OpenGameArt, Kenney and Quaternius could not be reached from the build environment (the
network proxy refuses those hosts), so no new downloads were possible. The CC0 Quaternius Stylized Nature
pack already in the project (flower groups, bushes, plants) stays in use alongside the new plants.

## Built in code (no suitable downloadable asset)

Everything else is generated procedurally to match the reference art direction:

- Houses (cottage, townhouse, alpine chalet, contemporary): walls, cross gables, roofs with white
  bargeboards, dormers, chimneys, windows, shutters, flower boxes, porches, doors (`src/world/buildings.js`)
- Stone arch bridges, generated wherever a lane crosses the river (`src/world/bridges.js`)
- Terrain, river valley, mountains and snow (`src/world/heightfield.js`, `src/world/terrain.js`)
- River water, rapids, cascades, foam and spray shaders (`src/world/water.js`)
- Soft stacked trees, round trees, bushes, flowers (`src/world/vegetation.js`), rocks (`src/world/rocks.js`)
- Fences, lamp posts, hanging domain signs, benches, mailboxes, noticeboard (`src/world/props.js`)
- Paving, cobble, trail and masonry textures drawn on canvas (`src/world/textures.js`), sky and clouds (`src/world/sky.js`)

- Environment kit (`src/world/assets.js`, 50 asset factories with variants): birch, willow, blossom
  and fruit trees, hedges, topiaries, lavender, roses, hydrangeas, ferns, tall grasses, clover,
  daisies, poppies, cornflowers, foxgloves, buttercups, flowering shrubs, undergrowth, fallen logs,
  stumps, mushrooms, reeds and cattails, irises, lily pads, pebbles, driftwood, a jetty and rowboat,
  hay bales, beehives, barrels, crates, baskets, market stalls, hand carts, signposts, a well, bunting,
  laundry lines, bistro sets, parasols, planters, garden arches, birdbaths, wheelbarrows, watering
  cans, lantern posts, flowerbeds, benches, milk churns and woodpiles
- House details: tiled roofs, striped awnings, half-timbering, Juliet balconies, weathervanes,
  finials, chimney pots, round gable windows, wisteria, ivy, pastel doors and shutters
- Watermill house and windmill tower (with the Kenney wheel and sails), butterflies

## Why not Poly Haven or Sketchfab

The build environment could only reach GitHub and npm, so Poly Haven, Kenney.nl, Sketchfab, Quaternius
and Poly Pizza downloads were not possible. Poly Haven's models are also photoreal and would clash with the
stylised reference. Good candidates for a later pass (all CC0): Kenney *Fantasy Town Kit* and *Nature Kit*,
Quaternius *Stylized Nature MegaKit* and *Medieval Village* packs. Drop GLBs into `assets-src/`, add them
to `tools/build-assets.mjs`, run `npm run assets`.
