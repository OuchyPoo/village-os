# Village OS

A cosy European mountain village in Three.js that will become the interface to real life
domains, projects and tasks. Walk the lanes, cross the bridges, knock on doors.

## Run it

```bash
npm install
npm run dev        # http://localhost:5173
```

Asset packs: the curated models are already in `public/assets/models/packs/`. To rebuild them from
the original zips, unzip the four packs into one folder and run `npm run packs -- <folder>`.

Production build: `npm run build`, then `npm run preview` (or serve `dist/` from any static host).
Append `?quality=low` for older laptops (no ambient occlusion, 1k shadows).

Self-contained page (models embedded, used for the hosted artifact): `npm run build && node tools/make-page.mjs`,
then open `dist/page.html`.

## World integrity checks (v0.4)

Headless checks run against `?manual` with `node tools/shot.mjs "<url>?manual" out.png 1280 720 100 <script>`:

- `tools/audit.js`: path surfaces against the terrain (sunk or floating), solid objects on lanes, gates on
  walkways, and a 0.4 m flood fill of everywhere the player can reach (doors, interactables, every lane).
- `tools/overlap.js`: finds solid objects whose footprints intersect (props, trees, walls, houses).
- `tools/walktest.js`: drives the real player controller along every walkway (lane to gate to door),
  across every bridge and down every lane, and reports anywhere it gets stuck.

Rules the world now follows: front gardens attach to the house corners and only exist where the walkway
passes through a gate on the door axis; solid props are never placed on a lane, walkway or bridge (and
neither are their colliders); every visible solid (trunks, large shrubs, porch posts, gate posts, piers)
has a matching collider; lane surfaces follow the terrain vertex by vertex and run onto bridge decks.

v0.5 adds: every placed object is checked against the footprints of everything placed before it
(`src/world/placement.js`) and rests on the lowest ground under its footprint; lanes meet at round
junction nodes; walkways curve smoothly to the lane at an even gradient and houses are levelled so no
walkway is steeper than about 1 in 4; the square is a raised dais; door steps and the home porch are
walkable surfaces; gates open outwards and fold flat against the fence.

## Controls

| Input | Action |
|---|---|
| W A S D | Move, relative to the camera |
| Hold right mouse + move | Rotate the camera |
| Mouse wheel | Zoom |
| Shift | Sprint |
| Space | Jump |
| E | Interact (doors, noticeboard, fountain, benches) |
| Esc | Close a panel, stand up, release the mouse |

## Where things are

- The square (west bank): fountain, noticeboard, Work (workshop), Finances (town hall), Taxes (records office)
- Across the main bridge: Home (your cottage, where you start) and Health (apothecary)
- Up the river path: Sleepover by the Yarra (guesthouse) and the first falls
- East forest trail: the Village OS workshop. Other trails lead to empty cottages in clearings
- Market row and café by the square, the well, a watermill on the river below the second falls,
  a windmill out in the meadows, an orchard with beehives, a hay field and a jetty with a rowboat

## Project layout

```
src/
  main.js                 bootstrap, lighting, loop
  core/                   maths/noise, post-processing (N8AO, SMAA, tilt-shift)
  data/domains.js         life domains shown in each building  <- edit me
  world/
    layout.js             lanes, square, key buildings, clearings, filler house placement
    river.js              river path, width, water levels, cascades, rapids
    heightfield.js        valley terrain shaped by house pads and lanes
    terrain.js            valley and mountain meshes with painted colours
    paths.js              lane ribbons, kerbs, walkways, bridge detection
    buildings.js bridges.js props.js vegetation.js rocks.js water.js sky.js
    index.js              assembles the world, colliders and interactables
  player/                 character (Kenney), movement controller, follow camera
  systems/                input, collision, interactions
  ui/hud.js               prompt, panel, toast, controls hint
tools/                    asset pipeline, texture grading, page embedding, audit and walk tests
assets-src/               original CC0 source models (see ASSETS.md)
```

## Connecting real data later

Buildings read from `src/data/domains.js`. Each domain has a title, a short description and
sections of items. Replacing that static object with live data (Claude, calendar, tasks) is the
seam for the next step; the world and interactions don't need to change.
