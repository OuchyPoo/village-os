// Curated picks from the four CC0 asset packs in ~/Downloads (see docs/asset-packs.md).
// Each pick is regraded to the Village OS pastel palette, textures are downsized and quantised,
// normal/ORM maps are dropped (the world uses soft, flat shading), and every model ships as one GLB.
// Usage: node tools/build-packs.mjs <packs root>   (root holds the unzipped packs)
import { NodeIO } from '@gltf-transform/core';
import { ALL_EXTENSIONS } from '@gltf-transform/extensions';
import { dedup, prune, weld } from '@gltf-transform/functions';
import sharp from 'sharp';
import fs from 'node:fs'; import path from 'node:path';

const ROOT = process.argv[2] || '/home/claude/packs';
const K = path.join(ROOT, 'kenney_fantasy-town-kit_2.0/Models/GLB format');
const N = path.join(ROOT, 'Stylized_Nature_MegaKitStandard/glTF');
const P = path.join(ROOT, 'Fantasy_Props_MegaKitStandard/Exports/glTF');
const V = path.join(ROOT, 'Medieval_Village_MegaKitStandard/Medieval Village MegaKit[Standard]/glTF');
const OUT = 'public/assets/models/packs';

const picks = {
  // Kenney Fantasy Town Kit 2.0
  'k-watermill': [K, 'watermill.glb'], 'k-windmill': [K, 'windmill.glb'], 'k-cart': [K, 'cart.glb'], 'k-cart-high': [K, 'cart-high.glb'],
  'k-stall-green': [K, 'stall-green.glb'], 'k-stall-red': [K, 'stall-red.glb'], 'k-stall-bench': [K, 'stall-bench.glb'], 'k-stall-stool': [K, 'stall-stool.glb'],
  'k-hedge': [K, 'hedge.glb'], 'k-hedge-curved': [K, 'hedge-curved.glb'], 'k-hedge-gate': [K, 'hedge-gate.glb'], 'k-hedge-large': [K, 'hedge-large.glb'],
  'k-fence-gate': [K, 'fence-gate.glb'], 'k-lantern': [K, 'lantern.glb'], 'k-banner-green': [K, 'banner-green.glb'], 'k-banner-red': [K, 'banner-red.glb'],
  'k-rock-large': [K, 'rock-large.glb'], 'k-rock-wide': [K, 'rock-wide.glb'], 'k-stairs-stone': [K, 'stairs-stone.glb'],
  // Quaternius Stylized Nature MegaKit
  'n-pebble-1': [N, 'Pebble_Round_1.gltf'], 'n-pebble-2': [N, 'Pebble_Round_2.gltf'], 'n-pebble-3': [N, 'Pebble_Round_3.gltf'], 'n-pebble-4': [N, 'Pebble_Round_4.gltf'], 'n-pebble-5': [N, 'Pebble_Round_5.gltf'],
  'n-rockpath-1': [N, 'RockPath_Round_Small_1.gltf'], 'n-rockpath-2': [N, 'RockPath_Round_Small_2.gltf'], 'n-rockpath-3': [N, 'RockPath_Round_Small_3.gltf'], 'n-rockpath-thin': [N, 'RockPath_Round_Thin.gltf'],
  'n-rock-1': [N, 'Rock_Medium_1.gltf'], 'n-rock-2': [N, 'Rock_Medium_2.gltf'], 'n-rock-3': [N, 'Rock_Medium_3.gltf'],
  'n-mushroom': [N, 'Mushroom_Common.gltf'], 'n-mushroom-shelf': [N, 'Mushroom_Laetiporus.gltf'],
  'n-flower-3': [N, 'Flower_3_Group.gltf'], 'n-flower-4': [N, 'Flower_4_Group.gltf'], 'n-plant-7': [N, 'Plant_7_Big.gltf'], 'n-plant-1': [N, 'Plant_1_Big.gltf'],
  'n-clover-1': [N, 'Clover_1.gltf'], 'n-clover-2': [N, 'Clover_2.gltf'], 'n-fern': [N, 'Fern_1.gltf'], 'n-bush-flowers': [N, 'Bush_Common_Flowers.gltf'],
  'n-tree-1': [N, 'CommonTree_1.gltf'], 'n-tree-3': [N, 'CommonTree_3.gltf'],
  // Quaternius Fantasy Props MegaKit
  'p-barrel-apples': [P, 'Barrel_Apples.gltf'], 'p-crate-apple': [P, 'FarmCrate_Apple.gltf'], 'p-crate-carrot': [P, 'FarmCrate_Carrot.gltf'], 'p-bucket': [P, 'Bucket_Wooden_1.gltf'],
  'p-stall-cart': [P, 'Stall_Cart_Empty.gltf'], 'p-vase-2': [P, 'Vase_2.gltf'], 'p-vase-4': [P, 'Vase_4.gltf'], 'p-bag': [P, 'Bag.gltf'],
  // Quaternius Medieval Village MegaKit
  'v-vine-1': [V, 'Prop_Vine1.gltf'], 'v-vine-2': [V, 'Prop_Vine2.gltf'], 'v-vine-4': [V, 'Prop_Vine4.gltf'], 'v-vine-5': [V, 'Prop_Vine5.gltf'],
  'v-wagon': [V, 'Prop_Wagon.gltf'], 'v-metal-fence': [V, 'Prop_MetalFence_Ornament.gltf'],
};

const io = new NodeIO().registerExtensions(ALL_EXTENSIONS);
const cache = new Map();
function rgb2hsl(r, g, b) {
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
  if (mx === mn) return [0, 0, l];
  const d = mx - mn, s = d / (1 - Math.abs(2 * l - 1));
  let h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  h /= 6; if (h < 0) h += 1;
  return [h, s, l];
}
function hsl2rgb(h, s, l) {
  const q = (1 - Math.abs(2 * l - 1)) * s, x = q * (1 - Math.abs(((h * 6) % 2) - 1)), m = l - q / 2;
  const [r, g, b] = h < 1 / 6 ? [q, x, 0] : h < 2 / 6 ? [x, q, 0] : h < 3 / 6 ? [0, q, x] : h < 4 / 6 ? [0, x, q] : h < 5 / 6 ? [x, 0, q] : [q, 0, x];
  return [r + m, g + m, b + m];
}
// Pastel grade applied per pixel (sRGB 0..1).
const MODES = {
  kenney: (r, g, b) => { const [h, s, l] = rgb2hsl(r, g, b); return hsl2rgb(h, s * 0.72, 0.1 + l * 0.9); },
  props: (r, g, b) => { const [h, s, l] = rgb2hsl(r, g, b); return hsl2rgb(h, s * 0.62, 0.2 + l * 0.82); },
};
const DARK = [112, 152, 104], LIGHT = [206, 230, 190]; // foliage ramp: sage to mint

async function grade(buf, uri, kenney) {
  const key = uri + (kenney ? 'k' : '');
  if (cache.has(key)) return cache.get(key);
  const name = (uri || '').toLowerCase();
  const foliage = /leaf|leaves|vine|grass/.test(name);
  let img = sharp(buf).ensureAlpha();
  const meta = await sharp(buf).metadata();
  // Kenney atlases are flat colour swatches: never resample them or the swatches bleed
  const max = foliage || name.includes('flower') ? 512 : 256;
  if (!kenney && meta.width > max) img = img.resize(max, max, { fit: 'inside' });
  const { data, info } = await img.raw().toBuffer({ resolveWithObject: true });
  const n = info.width * info.height;
  if (foliage) {
    // luminance → sage/mint ramp, with the range normalised over visible (non-transparent) texels
    const lums = [];
    for (let i = 0; i < n; i++) if (data[i * 4 + 3] > 40) lums.push(0.299 * data[i * 4] + 0.587 * data[i * 4 + 1] + 0.114 * data[i * 4 + 2]);
    lums.sort((a, b) => a - b);
    const lo = lums[Math.floor(lums.length * 0.03)] ?? 0, hi = lums[Math.floor(lums.length * 0.97)] ?? 255;
    for (let i = 0; i < n; i++) {
      const L = 0.299 * data[i * 4] + 0.587 * data[i * 4 + 1] + 0.114 * data[i * 4 + 2];
      const t = Math.min(1, Math.max(0, (L - lo) / (hi - lo || 1)));
      for (let k = 0; k < 3; k++) data[i * 4 + k] = Math.round(DARK[k] + (LIGHT[k] - DARK[k]) * (0.15 + 0.85 * t));
    }
  } else {
    const f = kenney ? MODES.kenney : MODES.props;
    for (let i = 0; i < n; i++) {
      const [r, g, b] = f(data[i * 4] / 255, data[i * 4 + 1] / 255, data[i * 4 + 2] / 255);
      data[i * 4] = Math.round(r * 255); data[i * 4 + 1] = Math.round(g * 255); data[i * 4 + 2] = Math.round(b * 255);
    }
  }
  const enc = sharp(data, { raw: { width: info.width, height: info.height, channels: 4 } });
  const out = await (kenney ? enc.png({ compressionLevel: 9 }) : enc.png({ palette: true, colours: 160, quality: 92 })).toBuffer();
  cache.set(key, out);
  return out;
}

fs.mkdirSync(OUT, { recursive: true });
let total = 0;
for (const [out, [dir, file]] of Object.entries(picks)) {
  const doc = await io.read(path.join(dir, file));
  const root = doc.getRoot();
  const kenney = dir === K;
  for (const m of root.listMaterials()) {
    m.setNormalTexture(null); m.setOcclusionTexture(null); m.setMetallicRoughnessTexture(null); m.setEmissiveTexture(null);
    m.setMetallicFactor(0); m.setRoughnessFactor(0.88);
    const bc = m.getBaseColorFactor();
    if (m.getName() === 'MI_Vine') m.setBaseColorFactor([1, 1, 1, bc[3]]);
  }
  // vertex colours: keep their hue but pull them into the pastel range (Quaternius uses them for tint/AO)
  for (const mesh of root.listMeshes()) for (const prim of mesh.listPrimitives()) {
    const c = prim.getAttribute('COLOR_0');
    if (!c) continue;
    const v = [];
    for (let i = 0; i < c.getCount(); i++) {
      c.getElement(i, v);
      const [r, g, b] = v;
      const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
      let l = (mx + mn) / 2, sat = mx === mn ? 0 : (mx - mn) / (1 - Math.abs(2 * l - 1) || 1);
      let h = 0;
      if (mx !== mn) { const d = mx - mn; h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; if (h < 0) h += 1; }
      l = 0.42 + l * 0.55; sat = Math.min(sat * 0.85, 0.6);
      const q = (1 - Math.abs(2 * l - 1)) * sat, x = q * (1 - Math.abs(((h * 6) % 2) - 1)), m0 = l - q / 2;
      const [rr, gg, bb] = h < 1 / 6 ? [q, x, 0] : h < 2 / 6 ? [x, q, 0] : h < 3 / 6 ? [0, q, x] : h < 4 / 6 ? [0, x, q] : h < 5 / 6 ? [x, 0, q] : [q, 0, x];
      v[0] = rr + m0; v[1] = gg + m0; v[2] = bb + m0;
      c.setElement(i, v);
    }
  }
  for (const t of root.listTextures()) {
    const used = t.listParents().some((p) => p.propertyType === 'Material' && p.getBaseColorTexture() === t);
    if (!used) { t.dispose(); continue; }
    t.setImage(await grade(Buffer.from(t.getImage()), t.getURI() || t.getName(), kenney));
    t.setMimeType('image/png');
    t.setURI(path.basename(t.getURI() || t.getName() || 'tex').replace(/\.\w+$/, '') + '.png');
  }
  await doc.transform(dedup(), weld(), prune());
  const dest = path.join(OUT, out + '.glb');
  await io.write(dest, doc);
  const sz = fs.statSync(dest).size; total += sz;
  console.log(out.padEnd(18), (sz / 1024).toFixed(0).padStart(5), 'KB');
}
console.log('TOTAL', (total / 1024 / 1024).toFixed(2), 'MB', Object.keys(picks).length, 'models');
