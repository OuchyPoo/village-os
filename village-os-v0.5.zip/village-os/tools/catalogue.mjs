// Catalogue glTF/GLB models: triangles, size, materials, textures. Usage: node tools/catalogue.mjs <dir> <out.json>
import { NodeIO } from '@gltf-transform/core';
import { ALL_EXTENSIONS } from '@gltf-transform/extensions';
import { getBounds } from '@gltf-transform/core';
import fs from 'node:fs'; import path from 'node:path';
const io = new NodeIO().registerExtensions(ALL_EXTENSIONS);
const [dir, out] = process.argv.slice(2);
const files = fs.readdirSync(dir).filter((f) => /\.(gltf|glb)$/i.test(f)).sort();
const rows = [];
for (const f of files) {
  try {
    const doc = await io.read(path.join(dir, f));
    const root = doc.getRoot();
    let tris = 0;
    for (const m of root.listMeshes()) for (const p of m.listPrimitives()) { const i = p.getIndices(); const c = i ? i.getCount() : p.getAttribute('POSITION').getCount(); tris += c / 3; }
    const b = getBounds(root.listScenes()[0]);
    const size = b.max.map((v, i) => +(v - b.min[i]).toFixed(2));
    const mats = root.listMaterials().map((m) => ({ name: m.getName(), color: m.getBaseColorFactor().slice(0, 3).map((v) => +v.toFixed(2)), tex: m.getBaseColorTexture()?.getURI() || m.getBaseColorTexture()?.getName() || null }));
    const tex = [...new Set(root.listTextures().map((t) => (t.getURI() || t.getName()) + ':' + (t.getSize() || []).join('x')))];
    rows.push({ name: f.replace(/\.(gltf|glb)$/i, ''), tris, size, mats, tex, anims: root.listAnimations().length });
  } catch (e) { rows.push({ name: f, error: e.message.slice(0, 120) }); }
}
fs.writeFileSync(out, JSON.stringify(rows, null, 1));
console.log(dir, rows.length, 'models', rows.filter((r) => r.error).length, 'errors');
