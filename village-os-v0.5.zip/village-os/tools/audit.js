// In-page world audit. Run via: node tools/shot.mjs "<url>?manual" out.png 1280 720 100 tools/audit.js
(() => {
  const v = window.VOS, W = v.world, hf = W.hf, col = v.collision, THREE = v.THREE;
  const R = {};
  // 1. path surface vs terrain (raycast the rendered meshes)
  const terrain = W.root.getObjectByName('terrain'), lanesG = W.root.getObjectByName('lanes');
  const ray = new THREE.Raycaster(); const down = new THREE.Vector3(0, -1, 0);
  let pts = 0, sunk = 0, floating = 0; const sunkAt = [], floatAt = [];
  for (const l of W.lanes) {
    for (let i = 1; i < l.samples.length - 1; i += 2) {
      const s = l.samples[i]; if (s.bridge || s.plaza || s.nx === undefined) continue;
      for (const f of [-0.38, 0, 0.38]) {
        const x = s.x + s.nx * f * l.w, z = s.z + s.nz * f * l.w;
        ray.set(new THREE.Vector3(x, s.y + 6, z), down);
        const hits = ray.intersectObjects([terrain, lanesG], true);
        if (!hits.length) continue;
        pts++;
        const first = hits[0];
        const isLane = first.object !== terrain;
        if (!isLane) { sunk++; if (sunkAt.length < 12) sunkAt.push([+x.toFixed(1), +z.toFixed(1), l.id]); continue; }
        const th = hits.find((h) => h.object === terrain);
        if (th && first.point.y - th.point.y > 0.14) { floating++; if (floatAt.length < 12) floatAt.push([+x.toFixed(1), +z.toFixed(1), l.id, +(first.point.y - th.point.y).toFixed(2)]); }
      }
    }
  }
  R.path = { points: pts, sunkPct: +(100 * sunk / pts).toFixed(2), floatingPct: +(100 * floating / pts).toFixed(2), sunkAt, floatAt };
  // 2. solid obstructions on walkable path surface (colliders overlapping lane centrelines)
  let obst = 0; const obstAt = []; const FT = (W.interactables.find((i) => i.id === 'fountain') || {}).target;
  for (const l of W.lanes) for (let i = 0; i < l.samples.length; i += 1) {
    const s = l.samples[i]; if (s.bridge) continue;
    if (FT && Math.hypot(s.x - FT.x, s.z - FT.z) < 3.3) continue; // lanes end at the fountain
    const [x, z] = col.resolve(s.x, s.z, 0.3, s.y);
    if (Math.hypot(x - s.x, z - s.z) > 0.25) { obst++; if (obstAt.length < 15) obstAt.push([+s.x.toFixed(1), +s.z.toFixed(1), l.id + (l.walk ? '(walk)' : '')]); }
  }
  R.obstructedPathSamples = obst; R.obstructedAt = obstAt;
  // 3. gates and fences
  R.gates = W.audit ? W.audit.gates : null;
  // 4. accessibility flood fill (player rules) from spawn over the inner valley
  const STEP = 0.4, MIN = -175, N = Math.ceil(350 / STEP);
  const ok = new Int8Array(N * N).fill(-1); // -1 unknown, 0 blocked, 1 reachable
  const idx = (x, z) => { const i = Math.round((x - MIN) / STEP), j = Math.round((z - MIN) / STEP); return i < 0 || j < 0 || i >= N || j >= N ? -1 : j * N + i; };
  const walkable = (x, z, y) => { if (Math.hypot(x, z) > 190) return false; const [rx, rz] = col.resolve(x, z, 0.4, y); return Math.hypot(rx - x, rz - z) < 0.05; };
  const p0 = v.player.pos; const start = idx(p0.x, p0.z);
  const q = [start]; ok[start] = 1; const gy = new Float32Array(N * N); gy[start] = col.ground(p0.x, p0.z);
  let head = 0;
  while (head < q.length) {
    const k = q[head++]; const i = k % N, j = (k - i) / N; const x = MIN + i * STEP, z = MIN + j * STEP;
    for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const ni = i + di, nj = j + dj; if (ni < 0 || nj < 0 || ni >= N || nj >= N) continue;
      const nk = nj * N + ni; if (ok[nk] !== -1) continue;
      const nx = MIN + ni * STEP, nz = MIN + nj * STEP; const ny = col.ground(nx, nz);
      const rise = ny - gy[k];
      if (rise / STEP > 1.05 && col.surfaceAt(nx, nz) === null) { continue; } // too steep to climb (may be reachable another way)
      if (!walkable(nx, nz, ny)) { ok[nk] = 0; continue; }
      ok[nk] = 1; gy[nk] = ny; q.push(nk);
    }
  }
  R.reachableCells = q.length;
  const reach = (x, z) => { for (const [dx, dz] of [[0, 0], [STEP, 0], [-STEP, 0], [0, STEP], [0, -STEP], [STEP, STEP], [-STEP, -STEP], [STEP, -STEP], [-STEP, STEP]]) { const k = idx(x + dx, z + dz); if (k >= 0 && ok[k] === 1) return true; } return false; };
  const badI = W.interactables.filter((it) => !reach(it.x, it.z)).map((it) => it.id);
  R.unreachableInteractables = badI;
  let lp = 0, lbad = 0; const lbadAt = [];
  for (const l of W.lanes) for (let i = 0; i < l.samples.length; i += 3) { const s = l.samples[i]; if (FT && Math.hypot(s.x - FT.x, s.z - FT.z) < 3.3) continue; lp++; if (!reach(s.x, s.z)) { lbad++; if (lbadAt.length < 15) lbadAt.push([+s.x.toFixed(1), +s.z.toFixed(1), l.id + (l.walk ? '(walk)' : '')]); } }
  R.unreachablePathPct = +(100 * lbad / lp).toFixed(2); R.unreachablePathAt = lbadAt;
  // 5. render cost
  v.renderer.info.autoReset = false; v.renderer.info.reset(); v.step(1, 1 / 30); R.render = { ...v.renderer.info.render };
  return R;
})()
