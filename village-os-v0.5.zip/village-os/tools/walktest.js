// Walks the real player controller along every house walkway (lane end -> gate -> door) and across
// every bridge, steering with the W key, and reports any route where the player gets stuck.
// Run via: node tools/shot.mjs "<url>?manual" out.png 640 360 100 tools/walktest.js
(() => {
  const v = window.VOS, P = v.player, W = v.world;
  const key = (code, down) => window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code }));
  const walk = (pts, label) => {
    const [sx, sz] = pts[0];
    P.teleport(sx, sz, 0); v.step(5, 1 / 60, false);
    key('KeyW', true);
    let i = 1, t = 0, best = 1e9, stuckT = 0;
    while (i < pts.length && t < 40 + pts.length) {
      const [tx, tz] = pts[i];
      const dx = tx - P.pos.x, dz = tz - P.pos.z, d = Math.hypot(dx, dz);
      if (d < 0.6) { i++; best = 1e9; stuckT = 0; continue; }
      v.follow.yaw = Math.atan2(-dx, -dz);
      v.step(6, 1 / 60, false); t += 0.1;
      if (d < best - 0.05) { best = d; stuckT = 0; } else if ((stuckT += 0.1) > 3) break;
    }
    key('KeyW', false); v.step(2, 1 / 60, false);
    return i >= pts.length ? null : { route: label, at: [+P.pos.x.toFixed(1), +P.pos.z.toFixed(1)], target: pts[i].map((x) => +x.toFixed(1)) };
  };
  const fails = []; let routes = 0;
  for (const l of W.lanes) {
    if (!l.walk || !l.house) continue;
    const pts = l.samples.map((s) => [s.x, s.z]).reverse(); // lane end -> door
    const it = W.interactables.find((q) => q.kind === 'door' && Math.hypot(q.x - pts[pts.length - 1][0], q.z - pts[pts.length - 1][1]) < 3);
    routes++;
    const f = walk(pts, 'walk:' + (l.house.domain || l.house.x + ',' + l.house.z));
    if (f) fails.push(f);
    else if (it && !(v.interactions.active && v.interactions.active.kind === 'door')) { v.step(4, 1 / 60, false); }
  }
  for (const l of W.lanes) {
    const S = l.samples; let a = -1;
    for (let i = 0; i < S.length; i++) {
      if (S[i].bridge && a < 0) a = i;
      if (!S[i].bridge && a >= 0) {
        const pts = S.slice(Math.max(0, a - 4), Math.min(S.length, i + 4)).map((s) => [s.x, s.z]);
        routes++; const f = walk(pts, 'bridge:' + l.id); if (f) fails.push(f); a = -1;
      }
    }
  }
  // every lane end to end
  for (const l of W.lanes) {
    if (l.walk) continue;
    const FT = (W.interactables.find((q) => q.id === 'fountain') || {}).target;
    const pts = l.samples.filter((s, k) => k % 3 === 0 && !(FT && Math.hypot(s.x - FT.x, s.z - FT.z) < 3.4)).map((s) => [s.x, s.z]);
    routes++; const f = walk(pts, 'lane:' + l.id); if (f) fails.push(f);
  }
  return { routes, failures: fails.length, fails: fails.slice(0, 20) };
})()
