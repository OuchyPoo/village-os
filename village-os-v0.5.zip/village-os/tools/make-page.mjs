// Builds the self-contained artifact page after `vite build`: embeds every GLB as base64 in
// dist/assets/models.js (the artifact host does not serve .glb) and writes dist/page.html.
import fs from 'node:fs';
import path from 'node:path';
const root = 'dist/assets/models';
const data = {};
const walk = (d) => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else if (f.endsWith('.glb')) data[path.relative(root, p).split(path.sep).join('/')] = fs.readFileSync(p).toString('base64'); } };
walk(root);
fs.writeFileSync('dist/assets/models.js', 'window.VOS_MODEL_DATA = ' + JSON.stringify(data) + ';\n');
const html = fs.readFileSync('dist/index.html', 'utf8');
const css = html.match(/href="(?:\.\/|\/)?(assets\/index-[^"]+\.css)"/)[1];
const js = html.match(/src="(?:\.\/|\/)?(assets\/index-[^"]+\.js)"/)[1];
const body = html.slice(html.indexOf('<body>') + 6, html.indexOf('</body>')).replace(/<script[^>]*><\/script>/g, '').trim();
fs.writeFileSync('dist/page.html', `<title>Village OS</title>\n<link rel="stylesheet" href="${css}">\n<style>html, body { background: #dde3ee; }</style>\n${body}\n<script src="assets/models.js"></script>\n<script type="module" src="${js}"></script>\n`);
console.log('models', Object.keys(data).length, 'page ->', js);
