// Finds solid objects that intersect each other, using their colliders as footprints: circle/circle,
// circle/box and box/box overlaps deeper than 5 cm. Fence and wall runs (segments) are excluded.
// Run via: node tools/shot.mjs "<url>?manual" out.png 640 360 100 tools/overlap.js
(() => {
  const W = window.VOS.world, C = W.colliders;
  const items = [];
  // river boulders are meant to pile together; skip them
  C.circles.forEach((c) => { if (c.r > 0.6 && W.hf.riverDist(c.x, c.z) < 5) return; items.push({ t: 'c', x: c.x, z: c.z, r: c.r, src: c }); });
  C.obbs.forEach((o) => items.push({ t: 'b', x: o.x, z: o.z, hx: o.hx, hz: o.hz, rot: o.rot, c: Math.cos(o.rot), s: Math.sin(o.rot), house: o.house, r: Math.hypot(o.hx, o.hz), src: o }));
  const grid = new Map(), CELL = 8;
  items.forEach((it, i) => { const k = Math.floor(it.x / CELL) + ',' + Math.floor(it.z / CELL); (grid.get(k) || grid.set(k, []).get(k)).push(i); });
  const local = (b, x, z) => { const dx = x - b.x, dz = z - b.z; return [dx * b.c - dz * b.s, dx * b.s + dz * b.c]; };
  const circBox = (c, b) => { const [lx, lz] = local(b, c.x, c.z); const qx = Math.max(-b.hx, Math.min(b.hx, lx)), qz = Math.max(-b.hz, Math.min(b.hz, lz)); return c.r - Math.hypot(lx - qx, lz - qz); };
  const boxBox = (a, b) => { // SAT penetration depth (min over axes)
    let best = 1e9;
    for (const [ax, az] of [[a.c, -a.s], [a.s, a.c], [b.c, -b.s], [b.s, b.c]]) {
      const proj = (o) => Math.abs(o.hx * (o.c * ax - o.s * az)) + Math.abs(o.hz * (o.s * ax + o.c * az));
      const d = Math.abs((b.x - a.x) * ax + (b.z - a.z) * az);
      best = Math.min(best, proj(a) + proj(b) - d);
    }
    return best;
  };
  const out = [];
  items.forEach((a, i) => {
    const gx = Math.floor(a.x / CELL), gz = Math.floor(a.z / CELL);
    for (let u = -1; u <= 1; u++) for (let v = -1; v <= 1; v++) for (const j of grid.get(gx + u + ',' + (gz + v)) || []) {
      if (j <= i) continue;
      const b = items[j];
      if (a.house && b.house && a.house === b.house) continue;
      if (Math.hypot(a.x - b.x, a.z - b.z) > a.r + b.r) continue;
      let pen = 0;
      if (a.t === 'c' && b.t === 'c') pen = a.r + b.r - Math.hypot(a.x - b.x, a.z - b.z);
      else if (a.t === 'c') pen = circBox(a, b); else if (b.t === 'c') pen = circBox(b, a); else pen = boxBox(a, b);
      if (pen > 0.05) out.push([+a.x.toFixed(1), +a.z.toFixed(1), a.t + (a.r ? +a.r.toFixed(2) : ''), +b.x.toFixed(1), +b.z.toFixed(1), b.t + (b.r ? +b.r.toFixed(2) : ''), +pen.toFixed(2)]);
    }
  });
  return { checked: items.length, overlaps: out.length, list: out.slice(0, 60) };
})()
