// node tools/shot.mjs url out.png [w h] [waitMs] [script.js]  (script runs in page; may return value)
import { createRequire } from 'module';
const { chromium } = createRequire(import.meta.url)('/opt/npm-tools/node_modules/playwright/index.js');
const [url, out, w = '1500', h = '600', wait = '500', scriptFile] = process.argv.slice(2);
const b = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const p = await b.newPage({ viewport: { width: +w, height: +h } });
const logs = [];
p.on('console', (m) => logs.push(m.type() + ': ' + m.text()));
p.on('pageerror', (e) => logs.push('PAGEERROR: ' + e.message));
try {
  await p.goto(url);
  await p.waitForFunction('window.DONE===true', null, { timeout: 240000 });
  await p.waitForTimeout(+wait);
  if (scriptFile) {
    const fs = await import('fs');
    const res = await p.evaluate(fs.readFileSync(scriptFile, 'utf8'));
    if (res !== undefined) console.log('SCRIPT:', JSON.stringify(res));
  }
  await p.screenshot({ path: out, timeout: 120000 });
} catch (e) { console.log('ERR', e.message.split('\n')[0]); }
console.log(logs.slice(0, 40).join('\n'));
await b.close();
