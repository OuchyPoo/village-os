// Copies the curated CC0 source models from assets-src/ into public/assets/models/,
// embedding external textures and running dedup/weld/prune so each ships as one small GLB.
import { NodeIO } from '@gltf-transform/core';
import { ALL_EXTENSIONS } from '@gltf-transform/extensions';
import { dedup, prune, weld } from '@gltf-transform/functions';
import fs from 'node:fs';
const io = new NodeIO().registerExtensions(ALL_EXTENSIONS);
const list = {
  'character.glb': 'assets-src/kenney/platformer/character.glb',
  'grass.glb': 'assets-src/kenney/platformer/grass.glb',
  'grass-small.glb': 'assets-src/kenney/platformer/grass-small.glb',
  'pine.glb': 'assets-src/kenney/mini-arena/tree.glb',
  'fountain.glb': 'assets-src/kenney/city/pavement-fountain.glb',
};
fs.mkdirSync('public/assets/models', { recursive: true });
for (const [out, src] of Object.entries(list)) {
  const doc = await io.read(src);
  await doc.transform(dedup(), weld(), prune());
  await io.write('public/assets/models/' + out, doc);
  console.log(out, fs.statSync('public/assets/models/' + out).size, 'bytes');
}
