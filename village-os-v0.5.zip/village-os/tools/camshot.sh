#!/bin/bash
# usage: tools/camshot.sh name '{x:..,z:..,yaw:..,pitch:..,dist:..}' [extra js] [w h]
S=/tmp/claude-0/-home-claude/03492ccd-8269-5709-b98e-11cfef0ce347/scratchpad
cat > $S/p_$1.js <<JS
(() => { const v = window.VOS; const P = $2;
v.player.teleport(P.x, P.z, P.f||0); v.follow.yaw = P.yaw; v.follow.pitch = P.pitch;
v.follow.dist = v.follow.targetDist = v.follow.curDist = P.dist; v.follow.inited = false;
v.step(20, 1/30, false); ${3:-v.step(1, 1/30)};
return {x:+v.player.pos.x.toFixed(1), y:+v.player.pos.y.toFixed(1), z:+v.player.pos.z.toFixed(1)}; })()
JS
node tools/shot.mjs "http://localhost:5173/?manual" $S/$1.png ${4:-1280} ${5:-720} 100 $S/p_$1.js | grep -v -E "vite|built in"
