# Asset packs review (Downloads, 30 Oct 2026)

Four CC0 packs were inspected model by model: each one was loaded, measured (triangles, size,
materials, textures) and rendered under the Village OS pastel lighting. The full per-model listing,
with a style-fit rating and notes, is in `asset-catalogue.csv` (505 models).

| Pack | Models | Formats | Textures | Typical tris | Style fit |
|---|---|---|---|---|---|
| Kenney Fantasy Town Kit 2.0 | 167 | GLB, FBX, OBJ | one 512 px colour atlas | 50 to 1,600 | Best. Flat colour, low poly, same family as the Kenney models already in the world |
| Quaternius Stylized Nature MegaKit (Standard, 68 of 116) | 68 | glTF, FBX, OBJ | 2k bark, leaf and rock maps, alpha-cut foliage | 50 to 10,000 | Good for ground detail (stones, flowers, ferns, mushrooms); trees are detailed and heavy |
| Quaternius Medieval Village MegaKit (Standard) | 176 | glTF, FBX, OBJ | 2k plaster, brick, tile and wood trim sheets | 30 to 6,400 | Mixed. Mostly modular wall and roof pieces; the props and details are useful now |
| Quaternius Fantasy Props MegaKit (Standard) | 94 | glTF, FBX, OBJ | 2k trim sheets, dark wood and metal | 100 to 5,700 | Weakest. Mostly interior and adventure items; a handful of market and farm props fit |

All four are CC0 1.0. The Quaternius packs are the free Standard editions (the Pro editions add more models).

## What fits the existing look

The world is soft, rounded and flat-shaded with a pastel palette. Assets fit best when they are
low poly with simple colour, or when their textures survive a pastel regrade.

1. **Kenney Fantasy Town Kit** is the closest match. Its single colour atlas can be regraded once
   and every model follows. Strongest picks: watermill wheel, windmill sails, carts, market stalls,
   stools and benches, hedges (straight, curved, gate), fence gate, lanterns, banners, rocks.
   Modular walls, roofs and stairs (120 models) are rated Medium: usable later if houses move to a
   modular kit. Road tiles are rated Low because the village has no roads.
2. **Stylized Nature MegaKit** adds the natural detail the procedural kit is weakest at: rounded
   pebbles, stepping-stone paths, mossy rocks, painted flower groups, ferns, ground plants, shelf
   fungus. Foliage arrives red or dark green and needs a sage/mint regrade. CommonTree and Pine are
   6 to 10k triangles each, so they work as a few hero trees, not as forest fill. Dead trees clash
   with the summer mood.
3. **Medieval Village MegaKit** is a modular house-building system with textured plaster, brick and
   round roof tiles. Rebuilding the houses with it would shift the village towards a textured
   medieval look, so it is not recommended yet. Its ivy vines, wagon, iron railings, round windows,
   shutters, balconies, dormers and exterior steps are good detail pieces.
4. **Fantasy Props MegaKit** is mostly books, potions, weapons and candles (Low). Apple barrels,
   farm crates, buckets, the stall cart, vases and sacks fit after lightening.

## Integrated in this pass (57 models)

`tools/build-packs.mjs` copies each pick into `public/assets/models/packs/`, regrades textures and
vertex colours to the pastel palette, drops normal and ORM maps, downsizes and quantises textures,
and writes one GLB per model (about 5 MB in total).

- Kenney (19): watermill, windmill, cart, cart-high, stall-green, stall-red, stall-bench, stall-stool,
  hedge, hedge-curved, hedge-gate, hedge-large, fence-gate, lantern, banner-green, banner-red,
  rock-large, rock-wide, stairs-stone
- Stylized Nature (24): Pebble_Round 1 to 5, RockPath_Round_Small 1 to 3, RockPath_Round_Thin,
  Rock_Medium 1 to 3, Mushroom_Common, Mushroom_Laetiporus, Flower_3_Group, Flower_4_Group,
  Plant_7_Big, Plant_1_Big, Clover 1 and 2, Fern_1, Bush_Common_Flowers, CommonTree 1 and 3
- Fantasy Props (8): Barrel_Apples, FarmCrate_Apple, FarmCrate_Carrot, Bucket_Wooden_1,
  Stall_Cart_Empty, Vase_2, Vase_4, Bag
- Medieval Village (6): Prop_Vine 1, 2, 4, 5, Prop_Wagon, Prop_MetalFence_Ornament

Where they appear: watermill and windmill landmarks (both animated), a market row by the square,
lanterns and banners, carts by the lanes, ivy on house walls, town hall railings, stepping stones to
back gardens, hero trees in the meadows, wildflower groups, ferns, fungi and rocks in the woods,
pebbles and waterside plants along the river.

## Good next candidates

- Kenney `fence`, `fence-curved`, `hedge-large-curved`, `hedge-large-gate` for a formal garden
- Kenney `fountain-round-detail` as a second fountain or a garden pond
- Medieval Village `Window_Wide_Round1`, `WindowShutters_*`, `Balcony_Simple_*`, `Roof_Dormer_RoundTile`
  as optional details on the procedural houses
- Medieval Village `Stairs_Exterior_Straight` for terraces on steeper plots
- Fantasy Props `Anvil`, `Workbench`, `Whetstone` for a blacksmith or the Work domain workshop
- Stylized Nature `Grass_Wispy_Short` and `Grass_Wispy_Tall` (regraded) for meadow edges
